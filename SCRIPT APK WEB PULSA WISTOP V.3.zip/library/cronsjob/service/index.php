<?php
set_time_limit(240);
require '../../../connect.php';
require '../helper.php';

$prov = $call->query("SELECT * FROM provider WHERE code = 'PST'");
$shows = isset($_GET['cjorg']) ? false : true;
if($prov->num_rows == 1) {
    $prov = $prov->fetch_assoc();
    $try  = $PUSATPPOB->Service();
    
    // header('Content-Type: application/json');
    // die(json_encode($try, JSON_PRETTY_PRINT));
    
    if(isset($try['result'])) {
        if($try['result'] == true) {
            if(count($try['data']) > 0) {
                for($i = 0; $i <= count($try['data'])-1; $i++) {
                    $data = $try['data'][$i];
                    $code = $data['code'];
                    $name = $data['name'];
                    $note = $data['note'];
                    $type = $data['type'];
                    $brand = $data['brand'];
                    $price = $data['price'];
                    $priceb = 350;
                    $status = $data['status'];
                    $varian = $data['varian'];
                    
                    $check_category = $call->query("SELECT * FROM category WHERE code = '$brand' AND type = '$type'");
                    $check_service = $call->query("SELECT * FROM services WHERE code = '$code' AND provider = 'PST'");

                    if($check_category->num_rows == 0)
                        $call->query("INSERT INTO category VALUES ('','$brand','$brand','1','$type','$type','prepaid')");
                            
                    if($check_service->num_rows == 0) {
                        $call->query("INSERT INTO services VALUES ('','$type','$code','$name','$varian','$note','$price','$priceb','$status','$brand','PST','$date $time')");
                        if($shows == true) print '<font color="green"><pre>';
                        if($shows == true) print "[+] $name {Berhasil ditambahkan}<br>";
                        if($shows == true) print "Type: $type<br>";
                        if($shows == true) print "Status: $status<br>";
                        if($shows == true) print "Harga Modal: $price<br>";
                        if($shows == true) print "Harga Jual: ".($price+$priceb);          
                        if($shows == true) print '</pre></font><hr>';
                    } else {
                        $data_service = $check_service->fetch_assoc();
                        if($data_service['price'] <> $price || $data_service['basic'] <> $priceb || $data_service['status'] <> $status) {
                            $call->query("UPDATE services SET price = '$price', basic = '$priceb', status = '$status', date_up = '$date $time' WHERE code = '$code' AND provider = 'PST'");
                            if($shows == true) print '<font color="green"><pre>';
                            if($shows == true) print "[+] $name {Berhasil diupdate}<br>";
                            if($shows == true) print "Type: $type<br>";
                            if($shows == true) print "Status: ".$data_service['status']." -> $status<br>";
                            if($shows == true) print "Harga Modal: ".$data_service['price']." -> $price<br>";
                            if($shows == true) print "Harga Jual: ".($data_service['price']+$data_service['basic'])." -> ".($price+$data_service['basic']);
                            if($shows == true) print '</pre></font><hr>';
                        } else {
                            if($shows == true) print '<font color="red"><pre>[!] '.$name.' {Data masih sama}</pre></font><hr>';
                        }
                    }
                }
            } else {
                print '<font color="red"><pre>[!] No Service</pre></font>';
            }
        } else {
            print '<font color="red"><pre>[!] '.$try['message'].'</pre></font>';
        }
    } else {
        print '<font color="red"><pre>[!] Connection Failed</pre></font>';
    }
} else {
    print '<font color="red"><pre>[!] Provider not found</pre></font>';
}
?>