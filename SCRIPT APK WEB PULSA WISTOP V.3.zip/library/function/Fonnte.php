<?php
class Fonnte {
    private $base = 'https://api.fonnte.com/';
    private $token;
    
    public function __construct($token) {      
        $this->token = $token;
    }
    
    public function sendMessage($phone,$msg) {
        $data = $this->Request($this->base.'send',['Authorization: '.$this->token],array(
           'target' => $phone,
           'message' => $msg
        ));
        
        if($data->status == true) {
            return ['result' => true,'message' => $data->detail];           
        } else {
            return ['result' => false,'message' => $data->reason];
        }        
    }
    
    public function getDevice() {
        $data = $this->Request($this->base.'device',['Authorization: '.$this->token],false);
        if($data->status == true) {
            return ['result' => true,'data' => $data,'message' => 'Successfully got your device details'];
        } else {
            return ['result' => false,'message' => $data->reason];
        }
    }
           
    private function Request($end_point,$header,$postdata) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $end_point);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_POST, 1);
        
        if($postdata == false) {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        } else {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        }
        
        $chresult = curl_exec($ch);
        return json_decode($chresult);
    }
}
         