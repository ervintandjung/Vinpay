<?php
/*
.---------------------------------------------------------------------------.
|   Script: Pusat PPOB Integrasi                                            |    
|   Version: 1.0                                                            |
|   Release: Januari 20, 2026 (00:47 WIB)                                   |
|                                                                           |
|                     Pasal 57 ayat (1) UU 28 Tahun 2014                    |
|      Copyright © 2020, Muhammad Maulana. All Rights Reserved.             |
| ------------------------------------------------------------------------- |
| Hubungi Saya:                                                             |
| - WhatsApp    - 0857 1643 2179            - 0838 7941 5954                |
'---------------------------------------------------------------------------'
*/

class PusatPPOB
{
    private $base = 'https://pusatppob.com/api/';
    private $userid;
    private $apikey;
    private $sign;
    
    public function __construct($punten) {
        $this->userid = $punten['userid'];
        $this->apikey = $punten['apikey'];
        $this->sign = md5($punten['userid'].$punten['apikey']);
    }
    
    public function checkProfile() {
        $connect = $this->connect($this->base.'profile', []);
        return $connect;
    }
    
    public function Order($x) {
        $connect = $this->connect($this->base.'prepaid', ['type' => 'order', 'service' => $x['service'], 'data_no' => $x['data_no']]);
        if($connect['result']) {
            return [
                'result' => true,
                'data' => [
                    '_LannOutput' => $connect['data']['trxid']
                ], 'message' => 'success'
            ];
        } else {
            return ['result' => false, 'data' => null, 'message' => isset($connect['message']) ? $connect['message'] : 'Connection Failed'];
        }
    }
    
    public function Status($x) {
        $connect = $this->connect($this->base.'prepaid', ['type' => 'status', 'trxid' => $x['_LannOutput']]);
        if($connect['result']) {
            return [
                'result' => true,
                'data' => [
                    '_LannOutput' => $connect['data'][0]['trxid'],
                    '_LannStatus' => $connect['data'][0]['status'],
                    '_LannSerial' => $connect['data'][0]['note']
                ], 'message' => 'success'
            ];
        } else {
            return ['result' => false, 'data' => null, 'message' => isset($connect['message']) ? $connect['message'] : 'Connection Failed'];
        }
    }
    
    public function Service() {
        $connect = $this->connect($this->base.'prepaid', ['type' => 'services']);
        return $connect;
    }
    
    public function connect($end_point, $postdata = [], $reqout = 'decode') {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $end_point);
        curl_setopt($ch, CURLOPT_POST, 1);
        $postdata['key'] = $this->apikey;
        $postdata['sign'] = md5($this->userid.$this->apikey);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $chresult = curl_exec($ch);
        curl_close($ch);
        return ($reqout == 'decode') ? json_decode($chresult, true) : $chresult;
    }
}