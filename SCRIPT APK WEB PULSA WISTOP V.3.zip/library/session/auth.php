<?php
if(isset($_SESSION['user'])) {
    redirect(0,base_url('user/'));
} else {
    if(isset($_COOKIE['token']) && isset($_COOKIE['ssid'])) {
        $LannUID = preg_replace('/[^\d]+/i','',$_COOKIE['ssid']) + 0;
        $LannKey = filter($_COOKIE['token']);
        $LannSSO = sha1(sha1(strtotime(date('Y-m-d H:i:s'))));
        $LannUser = $call->query("SELECT * FROM users WHERE id = '$LannUID'")->fetch_assoc();
        if(is_array($LannUser)) {
            $LannCheck = $call->query("SELECT * FROM users_cookie WHERE cookie = '$LannKey' AND username = '".$LannUser['username']."'");
            if($LannCheck->num_rows == 1) {
                $check_lock = check_lock($LannUser['username']);
                if($LannUser['level'] <> 'Admin' && $_CONFIG['mt']['web'] == 'true') {
                    exit(redirect(0,base_url('auth/logout')));
                } else {
                    $_SESSION['sso'] = $LannSSO;
                    $_SESSION['user'] = $LannUser;
                    redirect(0,visited());
                    $call->query("UPDATE users SET sso = '$LannSSO' WHERE id = ".$LannUser['id']."");
                    $call->query("UPDATE users_cookie SET active = '$date $time', ua = '$user_agent', ip = '$client_ip' WHERE cookie = '$LannKey'");
                }
            } else {
                exit(redirect(0,base_url('auth/logout')));
            }
        } else {
            exit(redirect(0,base_url('auth/logout')));
        }
    }
}