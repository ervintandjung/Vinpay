<?php 
if(isset($_SESSION['result'])) { 
    $type = strtolower($_SESSION['result']['type']);
    if($type == true) {
        $session_alert = 'bg-blue-200';
        $session_text = 'text-text-500';
    } else {
        $session_alert = 'bg-red-200';
        $session_text = 'text-red-500';
    }
?>
<div class="<?= $session_alert ?> px-4 py-3 rounded-xl mb-4">
    <span class="<?= $session_text ?> text-md"><?= $_SESSION['result']['message'] ?></span>
</div>
<?php unset($_SESSION['result']); } ?>