<?php
if(!isset($_SESSION['user'])) {
    if(isset($_COOKIE['token']) && isset($_COOKIE['ssid'])) {
        $LannUID = preg_replace('/[^\d]+/i','',$_COOKIE['ssid']) + 0;
        $LannKey = filter($_COOKIE['token']);
        $LannSSO = sha1(sha1(strtotime(date('Y-m-d H:i:s'))));
        $LannUser = $call->query("SELECT * FROM users WHERE id = '$LannUID'")->fetch_assoc();
        if(is_array($LannUser)) {
            $LannCheck = $call->query("SELECT * FROM users_cookie WHERE cookie = '$LannKey' AND username = '".$LannUser['username']."'");
            if($LannCheck->num_rows == 1) {
                $check_lock = check_lock($LannUser['username']);
                if($LannUser['level'] <> 'Admin' && $_CONFIG['mt']['web'] == 'true') {
                    exit(redirect(0,base_url('auth/logout')));
                } else {
                    $_SESSION['sso'] = $LannSSO;
                    $_SESSION['user'] = $LannUser;
                    redirect(0,visited());
                    $call->query("UPDATE users SET sso = '$LannSSO' WHERE id = ".$LannUser['id']."");
                    $call->query("UPDATE users_cookie SET active = '$date $time', ua = '$user_agent', ip = '$client_ip' WHERE cookie = '$LannKey'");
                }
            } else {
                exit(redirect(0,base_url('auth/logout')));
            }
        } else {
            exit(redirect(0,base_url('auth/logout')));
        }
    } else {
        LannXit(['type' => false,'message' => 'Authentication required, please log in first.'],base_url('auth/login'));
    }
}

if(isset($_SESSION['user'])) {
    $sess_username = $_SESSION['user']['username'];
    if($call->query("SELECT * FROM users WHERE username = '$sess_username'")->num_rows == 0) exit(redirect(0,base_url('auth/logout')));
    $data_user = $call->query("SELECT * FROM users WHERE username = '$sess_username'")->fetch_assoc();
    
    $sess_cookie = isset($_COOKIE['token']) ? filter($_COOKIE['token']) : '';
    $data_usercookie = $call->query("SELECT * FROM users_cookie WHERE cookie = '$sess_cookie' AND username = '$sess_username'");
    if($data_usercookie->num_rows == 1) $data_usercookie = $data_usercookie->fetch_assoc();
    $data_usercookie = (is_array($data_usercookie)) ? $data_usercookie : exit(redirect(0,base_url('auth/logout')));
    
    $sess_username = $data_user['username'];
    $avatar = gravatar($data_user['email']);
    if($data_user['status'] <> 'active') {
        exit(redirect(0,base_url('auth/logout')));
    } else if($data_user['level'] <> 'Admin' && $_CONFIG['mt']['web'] == 'true') {
        exit(redirect(0,base_url('auth/logout')));
    } else if($_CONFIG['lock']['status'] == true && $_CONFIG['mt']['web'] == 'true') {
        exit(redirect(0,base_url('auth/logout')));
    } else if(conf('xtra-fitur',5) == 'true' && $data_user['sso'] <> $_SESSION['sso']) {
        exit(redirect(0,base_url('auth/logout')));
    } else if($_SESSION['user']['password'] <> $data_user['password']) {
        LannXit(['type' => false,'message' => 'Password has been changed, please log back in.'],base_url('auth/logout'));
    }
}