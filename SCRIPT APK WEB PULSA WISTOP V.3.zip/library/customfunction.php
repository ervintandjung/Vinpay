<?php
function conf($code,$number) {
    global $call;
    $code=strtolower($code);$number=strtolower($number);
    $query = (stristr($number,'c')) ? "SELECT $number FROM conf WHERE code = '$code'" : "SELECT c$number FROM conf WHERE code = '$code'";
    $data = (stristr($number,'c')) ? $number : "c$number";
    return ($call->query($query)->num_rows == 1) ? $call->query($query)->fetch_assoc()[$data] : '';
}

function sessResult($sts,$msg) {
    $alert = ($sts == true) ? 'gradient-success' : 'gradient-danger';
    $status = ($sts == true) ? 'Success!' : 'Failed!';
    return '<div class="alert bg-'.$alert.' text-white border-0" role="alert"><font style="font-size: 0.9rem;"><strong>Response:</strong> '.$status.'</font><br><font style="font-size: 0.9rem;"><strong>Message:</strong> '.$msg.'</font></div>';
}

function select_opt($select,$opt_val,$opt_name) {
    $selected = ($select == $opt_val) ? ' class="text-primary" style="font-weight:600" selected' : '';
    return '<option value="'.$opt_val.'"'.$selected.'>'.$opt_name.'</option>';
}

function data_user($u, $r = '') {
    $s = squery("SELECT * FROM users WHERE username = '$u'");
    if($s->num_rows == 0) return false; $fa = $s->fetch_assoc();
    if(!empty($r) && !isset($fa[$r])) return false;
    return (!empty($r)) ? $fa[$r] : $fa;
}

function getFCMtoken($u) {
    $search = squery("SELECT token FROM users_cookie WHERE token != '' AND username = '$u'");
    if($search->num_rows > 0) {
        while($row = $search->fetch_assoc()) $token[] = $row['token'];
        return $token;
    }
    return '';
}

function gravatar($email,$s = 80,$d = 'mp',$r = 'x',$img = false,$atts = []) { // default (mail,80,mp,g,false,[])
    $url = 'https://www.gravatar.com/avatar/'.md5(strtolower(trim($email)))."?s=$s&d=$d&r=$r";
    if($img) {
        $url = '<img src="'.$url.'"';
        foreach($atts as $key => $val) $url .= ' ' . $key . '="' . $val . '"';
        $url .= ' />';
    }
    return $url;
}

function LannXit($x = false,$y = 'PT Lann Niaga Mandiri') {
    $z = ($y == 'PT Lann Niaga Mandiri') ? visited() : $y;
    if(is_array($x)) $_SESSION['result'] = $x;
    exit(redirect(0,$z));
}

function LannDie($x = []) {
    exit(json_encode($x, JSON_PRETTY_PRINT));
}

function delCookie($name) {
    global $_SERVER;
    setcookie($name, '', 1);
    setcookie($name, '', 1, '/');
    setcookie($name, '', 1, '/', '');
    setcookie($name, '', 1, '/', $_SERVER['HTTP_HOST']);
}