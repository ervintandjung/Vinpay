<?php
/*
.---------------------------------------------------------------------------.
|   Script: User Auth Login                                                 |    
|   Version: 1.0                                                            |
|   Release: Januari 15, 2026 (21:20 WIB)                                   |
|                                                                           |
|                     Pasal 57 ayat (1) UU 28 Tahun 2014                    |
|      Copyright © 2020, Muhammad Maulana. All Rights Reserved.             |
| ------------------------------------------------------------------------- |
| Hubungi Saya:                                                             |
| - WhatsApp    - 0857 1643 2179            - 0838 7941 5954                |
'---------------------------------------------------------------------------'
*/

class AuthLogin {
    protected $db;
    protected $config;
    protected $date;
    protected $time;
    protected $ip;
    protected $iploc;
    protected $agent;

    public function __construct($db, $config, $client_ip, $client_iploc, $user_agent, $date, $time) {
        $this->db     = $db;
        $this->config = $config;
        $this->ip     = $client_ip;
        $this->iploc  = $client_iploc;
        $this->agent  = $user_agent;
        $this->date   = $date;
        $this->time   = $time;
    }

    public function handlePost($post, $csrf_status) {

        if($csrf_status == false) {
            LannXit(['type'=>false,'message'=>'System Error, Please try again later.']);
        }

        $username = filter($post['user'] ?? '');
        $password = filter($post['pass'] ?? '');
        $remember = isset($post['remember']) ? filter_entities($post['remember']) : false;

        if(!$username || !$password) {
            LannXit(['type'=>false,'message'=>'There is still a blank form.']);
        }

        $stmt = $this->db->prepare("SELECT * FROM users WHERE email = ? OR phone = ? LIMIT 1");
        $stmt->bind_param("ss",$username, $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if($result->num_rows == 0) {
            LannXit(['type'=>false,'message'=>'Account not registered.']);
        }

        $user = $result->fetch_assoc();

        if($user['status'] == 'suspend') {
            LannXit(['type'=>false,'message'=>'Akun suspended, please contact Admin.']);
        }

        if($user['status'] !== 'active') {
            LannXit(['type'=>false,'message'=>'Your account is inactive, please contact Admin.']);
        }

        if(check_bcrypt($password, $user['password']) == false) {
            LannXit(['type'=>false,'message'=>'Account not registered.']);
        }

        if($user['level'] <> 'Admin' && $this->config['mt']['web'] == 'true') {
            LannXit(['type'=>false,'message'=>'There is a website system maintenance, please try again later.']);
        }

        if($lock['status'] == true && $this->config['mt']['web'] == 'true') {
            LannXit(['type'=>false,'message'=>'There is a website system maintenance, please try again later.']);
        }

        $cookie_time = ($remember == 'true') ? time() + (86400 * 90) : time() + 10800;
        $cookie_expr = date('Y-m-d H:i:s', $cookie_time);
        $token       = random(86);
        $sso         = sha1(sha1(time()));

        setcookie('ssid','LANN-'.$user['id'].'NIAGA',$cookie_time,'/','');
        setcookie('token',$token,$cookie_time,'/','');

        $this->db->query("INSERT INTO users_cookie VALUES (
            '$token','',
            '".$user['username']."',
            '".$this->date." ".$this->time."',
            '$cookie_expr',
            '".$this->agent."',
            'unknown',
            '".$this->ip."',
            '".$this->iploc."',
            'unknown','-','unknown'
        )");

        $this->db->query("UPDATE users SET sso='$sso' WHERE id = ".$user['id']);

        $_SESSION['sso']  = $sso;
        $_SESSION['user'] = $user;

        $this->db->query("INSERT INTO logs VALUES (
            null,
            '".$user['username']."',
            'login',
            'Welcome back.',
            '".$this->ip."',
            '".$this->iploc."',
            '".$this->date." ".$this->time."'
        )");

        LannXit(['type'=>true,'message'=>'Welcome, '.ucwords(strtolower($user['name'])).'.'], base_url('user/'));
    }
}
