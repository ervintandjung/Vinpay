<?php
class AuthReset {

    private $db;
    private $config;
    private $fonnte;
    private $dtme;

    public function __construct($db,$config,$curl,$fonnte,$ip,$iploc,$dtme){
        $this->db     = $db;
        $this->config = $config;
        $this->fonnte = $fonnte;
        $this->dtme   = $dtme;
    }

    /* ================= SEND OTP ================= */
    public function sendOTP($post,$csrf){

        if(empty($post['user']))
            return LannXit(['type'=>false,'message'=>'Email / No HP wajib diisi']);

        $user = mysqli_real_escape_string($this->db,$post['user']);

        $q = mysqli_query($this->db,"
            SELECT id, phone, email
            FROM users
            WHERE email='$user' OR phone='$user'
            LIMIT 1
        ");

        if(mysqli_num_rows($q)==0)
            return LannXit(['type'=>false,'message'=>'Akun tidak ditemukan']);

        $u = mysqli_fetch_assoc($q);

        $otp = rand(100000,999999);

        $_SESSION['temp_reset'] = [
            'uid' => $u['id'],
            'otp' => $otp,
            'exp' => time()+300,
            'verified'=>false
        ];

        /* kirim OTP WA */
        $pesan = "Kode OTP Reset Password: $otp\nBerlaku 5 menit.\nJangan berikan kode ini ke siapapun.";

        $this->fonnte->sendMessage($u['phone'], $pesan);

        return LannXit(['type'=>true,'message'=>'OTP dikirim ke WhatsApp']);
    }

    /* ================= CONFIRM OTP ================= */
    public function confirmOTP($post,$csrf){

        if(!isset($_SESSION['temp_reset']))
            return LannXit(['type'=>false,'message'=>'Session tidak valid']);

        if(time() > $_SESSION['temp_reset']['exp']){
            unset($_SESSION['temp_reset']);
            return LannXit(['type'=>false,'message'=>'OTP kadaluarsa']);
        }

        if($post['otp'] != $_SESSION['temp_reset']['otp'])
            return LannXit(['type'=>false,'message'=>'OTP salah']);

        $_SESSION['temp_reset']['verified'] = true;

        return LannXit(['type'=>true,'message'=>'OTP berhasil diverifikasi']);
    }

    /* ================= RESET PASSWORD ================= */
    public function resetPassword($post,$csrf){

        if(!isset($_SESSION['temp_reset']['verified']))
            return LannXit(['type'=>false,'message'=>'OTP belum diverifikasi']);

        if(empty($post['pass1']) || empty($post['pass2']))
            return LannXit(['type'=>false,'message'=>'Password wajib diisi']);

        if($post['pass1'] !== $post['pass2'])
            return LannXit(['type'=>false,'message'=>'Konfirmasi password tidak sama']);

        $uid = intval($_SESSION['temp_reset']['uid']);
        $pass= password_hash($post['pass1'], PASSWORD_DEFAULT);

        mysqli_query($this->db,"UPDATE users SET password='$pass' WHERE id='$uid'");

        unset($_SESSION['temp_reset']);

        return LannXit(['type'=>true,'message'=>'Password berhasil diubah']);
    }
}