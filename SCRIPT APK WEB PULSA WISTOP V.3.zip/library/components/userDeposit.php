<?php

class Deposit {

    protected $db;

    public function __construct($db){
        $this->db = $db;
    }

    private function generateWid(){
        return 'DEP'.date('YmdHis').rand(100,999);
    }

    private function generateUniq(){
        return rand(1,999);
    }

    public function create($user, $methodId, $nominal){

        // ambil method
        $methodId = $this->db->real_escape_string($methodId);
        $nominal  = (int)$nominal;

        $m = $this->db->query("SELECT * FROM method WHERE id = '$methodId'")->fetch_assoc();
        if(!$m){
            return ['status'=>false,'msg'=>'Method tidak ditemukan'];
        }

        // cek minimal
        if($nominal < $m['minimal']){
            return ['status'=>false,'msg'=>'Minimal deposit Rp '.number_format($m['minimal'],0,',','.')];
        }

        // hitung fee
        if($m['fee_type'] == '+'){
            $fee = (int)$m['fee'];
        }else{
            $fee = ceil($nominal * $m['fee'] / 100);
        }

        // generate
        $uniq = $this->generateUniq();
        $wid  = date('YmdHis').rand(100,999);
        $date = date('Y-m-d H:i:s');

        // note tujuan transfer
        $note = 'Transfer ke '.$m['owner'].' - '.$m['rekening'];

        // escape
        $user = $this->db->real_escape_string($user);
        $note = $this->db->real_escape_string($note);

        // insert
        $insert = $this->db->query("
            INSERT INTO deposit 
            (wid,user,payment,method,note,sender,uniq,fee,amount,status,date)
            VALUES
            ('$wid','$user','".$m['id']."','".$m['nama']."','$note','','$uniq','$fee','$nominal','unpaid','$date')
        ");

        if($insert == true){
            // ambil wid asli dari database
            $id = $this->db->insert_id;
            
            $get = $this->db->query("SELECT wid FROM deposit WHERE id = '$id'");
            $data = $get->fetch_assoc();
            
            return [
                'status' => true,
                'wid'    => $data['wid']
            ];
        } else {
            return [
                'status' => false,
                'msg'    => $this->db->error
            ];
        }
    }
}