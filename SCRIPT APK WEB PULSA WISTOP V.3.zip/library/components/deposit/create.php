<?php
header('Content-type: application/json');
require '../../../connect.php';
require _DIR_('library/session/user');
require _DIR_('library/components/userDeposit');

// pastikan user login
if(!isset($_SESSION['user'])){
    echo json_encode([
        'status'=>false,
        'msg'=>'Silakan login'
    ]);
    exit;
}

$method = $_POST['method'] ?? '';
$nominal= $_POST['nominal'] ?? 0;

$deposit = new Deposit($call);
$result  = $deposit->create($sess_username, $method, $nominal);

echo json_encode($result);