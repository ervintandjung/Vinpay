<?php
/*
.---------------------------------------------------------------------------.
|   Script: User Auth Register                                              |    
|   Version: 1.0                                                            |
|   Release: Januari 15, 2026 (21:20 WIB)                                   |
|                                                                           |
|                     Pasal 57 ayat (1) UU 28 Tahun 2014                    |
|      Copyright © 2020, Muhammad Maulana. All Rights Reserved.             |
| ------------------------------------------------------------------------- |
| Hubungi Saya:                                                             |
| - WhatsApp    - 0857 1643 2179            - 0838 7941 5954                |
'---------------------------------------------------------------------------'
*/

class AuthRegister {

    protected $db,$config,$curl,$fonnte;
    protected $ip,$iploc,$agent,$dtme;

    public function __construct($db,$config,$curl,$fonnte,$ip,$iploc,$dtme){
        $this->db     = $db;
        $this->config = $config;
        $this->curl   = $curl;
        $this->fonnte = $fonnte;
        $this->ip     = $ip;
        $this->iploc  = $iploc;
        $this->dtme   = $dtme;
    }

    /* ================= SEND OTP ================= */

    public function sendOTP($post,$csrf){
        $mail  = trim((string)($_POST['mail'] ?? ''));
        $name  = trim((string)($_POST['name'] ?? '')); // username
        $phone = trim((string)($_POST['phone'] ?? ''));
        $pas1  = trim((string)($_POST['pas1'] ?? ''));
        $pas2  = trim((string)($_POST['pas2'] ?? ''));

        $exp = explode('@',$mail);
        $allow = ['gmail.com','yahoo.com','outlook.com','icloud.com'];

        if($csrf == false) LannXit(['type'=>false,'message'=>'System Error, please try again later.']);
        if($this->config['mt']['web']=='true') LannXit(['type'=>false,'message'=>'Maintenance mode.']);
        if($mail=='' || $name=='' || $phone=='' || $pas1=='' || $pas2=='')
            LannXit(['type'=>false,'message'=>'There is still a blank form.']);
        if(!in_array($exp[1],$allow))
            LannXit(['type'=>false,'message'=>'You cannot register using this email.']);
        if($pas1<>$pas2)
            LannXit(['type'=>false,'message'=>'Password confirmation does not match.']);
        
        $mail  = filter($mail);
        $name  = ucwords(strtolower(filter($name)));
        $phone = filter_phone('62',$phone);
        $pas1  = filter($pas1);
        $pas2  = filter($pas2);

        $_SESSION['temp']['whatsapp'] = random_number(6);
        $_SESSION['temp']['data'] = [
            'name'=>$name,'email'=>$mail,'phone'=>$phone,
            'password'=>bcrypt($pas1)
        ];

        $send = $this->fonnte->sendMessage($phone,
            'Kode OTP : '.$_SESSION['temp']['whatsapp'].' Jangan bagikan kode ini kepada siapapun.'
        );

        if($send['result']==true){
            LannXit(['type'=>true,'message'=>'OTP sent via WhatsApp.']);
        } else {
            unset($_SESSION['temp']);
            LannXit(['type'=>false,'message'=>'Failed to send OTP.']);
        }
    }

    /* ================= CONFIRM OTP ================= */

    public function confirmOTP($post,$csrf){

        if(!$csrf) LannXit(['type'=>false,'message'=>'System Error.']);
        if(!isset($_SESSION['temp'])) LannXit(['type'=>false,'message'=>'Session expired.']);
        if(!$post['otpwa']) LannXit(['type'=>false,'message'=>'OTP required.']);
        if($_SESSION['temp']['whatsapp'] <> $post['otpwa'])
            LannXit(['type'=>false,'message'=>'OTP invalid.']);

        $d = $_SESSION['temp']['data'];
        
        $stmt = $this->db->prepare("
            INSERT INTO users 
            (name,email,phone,username,password,balance,level,status,date,sso)
            VALUES (?,?,?,?,?,0,'Basic','active',?,?)
        ");
        
        if(!$stmt){
            LannXit(['type'=>false,'message'=>'Database error: '.$this->db->error]);
        }

        $sso = sha1(sha1(time()));
        
        $stmt->bind_param(
            "sssssss",
            $d['name'],
            $d['email'],
            $d['phone'],
            $d['name'],
            $d['password'],
            $this->dtme,
            $sso
        );
        
        if($stmt->execute()) {
            $this->db->query("INSERT INTO logs VALUES (
                null,
                '".$d['name']."',
                'register',
                'Welcome.',
                '".$this->ip."',
                '".$this->iploc."',
                '".$this->dtme."'
            )");
            unset($_SESSION['temp']);
            LannXit(['type'=>true,'message'=>'Registration successful, please login.']);
        } else {
            LannXit(['type'=>false,'message'=>'Server error, try again later.:: '.$stmt->error]);
        }
    }
}
