<!-- ================= OVERLAY ================= -->
<div id="sidebarOverlay"
     class="fixed top-16 left-0 right-0 bottom-0
            bg-black/40 backdrop-blur-sm
            hidden z-30 md:hidden"></div>

<!-- ================= SIDEBAR ================= -->
<aside id="sidebar"
       class="fixed md:static
              top-16 left-0
              h-[calc(100vh-4rem)]
              w-72
              bg-white/80 backdrop-blur-xl
              border-r border-slate-200
              transform -translate-x-full md:translate-x-0
              transition-transform duration-300
              z-40 flex flex-col">

    <!-- BRAND -->
    <div class="px-6 py-5 border-b border-slate-200">
        <h1 class="text-xl font-bold tracking-tight text-slate-800">
            Admin Dashboard
        </h1>
        <p class="text-center text-xs text-slate-400 mt-6">
        © <?= date('Y') ?> <?= htmlspecialchars($_CONFIG['title']) ?>
    </p>
    </div>

    <!-- NAV -->
    <nav class="flex-1 px-4 py-4 space-y-1 text-sm overflow-y-auto">

        <?php
        $menus = [
            ['Beranda','/'],
            ['Dashboard','/admin'],
            ['User','/admin/user'],
            ['Transaksi','/admin/transaksi'],
            ['Deposit','/admin/deposit'],
            ['Metode Deposit','/admin/depositmetode'],
            ['Kategory','/admin/kategory'],
            ['Produk','/admin/produk'],
            ['Bantuan','/admin/bantuan'],
            ['Info Banner','/admin/info_banner'],
            ['Konfig','/admin/konfig'],
            ['Provider','/admin/provider'],
            ['Fonnte','/admin/fonnte'],
        ];
        foreach ($menus as $m):
        ?>
        <a href="<?= $m[1] ?>"
           class="flex items-center gap-3 px-4 py-3 rounded-xl
                  text-slate-700 hover:bg-blue-50 transition">

            <span class="w-2 h-2 rounded-full bg-blue-500 opacity-70"></span>
            <span class="font-medium"><?= $m[0] ?></span>
        </a>
        <?php endforeach ?>

        <!-- LOGOUT -->
        <a href="/auth/logout.php"
           class="mt-4 flex items-center gap-3 px-4 py-3 rounded-xl
                  text-rose-500 hover:bg-rose-50 transition">
            <span class="w-2 h-2 rounded-full bg-rose-500"></span>
            Logout
        </a>

    </nav>

    <!-- FOOTER -->
    <div class="px-6 py-4 text-xs text-slate-400 border-t border-slate-200">
        © <?= date('Y') ?> Wisno Andu
    </div>

</aside>
