<?php
/* ================= USER DATA ================= */
$idUser = isset($_SESSION['id']) ? intval($_SESSION['id']) : 0;

$name  = 'User';
$email = '-';
$level = 'Member';
$initial = 'U';

if($idUser > 0){
    $stmt = mysqli_prepare($call,"SELECT name,email,level FROM users WHERE id=? LIMIT 1");
    mysqli_stmt_bind_param($stmt,'i',$idUser);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);

    if($row = mysqli_fetch_assoc($res)){
        $name  = $row['name']  ?: 'User';
        $email = $row['email'] ?: '-';
        $level = $row['level'] ?: 'Member';
        $initial = strtoupper(substr($name,0,1));
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($_CONFIG['title'], ENT_QUOTES, 'UTF-8') ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { background:#f1f5f9 }
    </style>
    
    <!-- Logo -->
    <link rel="icon" href="<?= $_CONFIG['icon'] ?>">
    
</head>
<body>

<div class="flex min-h-screen">

<!-- ================= HEADER ================= -->
<header class="fixed top-0 left-0 right-0 h-16
               bg-white/80 backdrop-blur-xl
               border-b border-slate-200
               flex items-center justify-between
               px-6 z-50">

    <!-- TOGGLE -->
    <button id="toggleSidebar"
            class="p-2 rounded-xl hover:bg-slate-100 transition">
        <svg xmlns="http://www.w3.org/2000/svg"
             class="w-6 h-6 text-slate-700"
             fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round"
                  stroke-width="2"
                  d="M4 6h16M4 12h16M4 18h16" />
        </svg>
    </button>

    <!-- USER INFO -->
    <div class="flex items-center gap-3">
        <div class="text-right leading-tight">
            <p class="text-sm font-semibold text-slate-700">
                <?= htmlspecialchars($level) ?>
            </p>
            <p class="text-xs text-slate-500">
                <?= htmlspecialchars($email) ?>
            </p>
        </div>

        <div class="w-9 h-9 rounded-full bg-gradient-to-br
                    from-blue-500 to-indigo-600
                    flex items-center justify-center
                    text-white font-bold shadow-sm">
            <?= htmlspecialchars($initial) ?>
        </div>
    </div>

</header>

<!-- CONTENT WRAPPER -->
<div class="flex w-full pt-16">