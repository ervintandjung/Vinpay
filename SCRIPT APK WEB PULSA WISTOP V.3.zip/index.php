<?php
require 'connect.php';
require _DIR_('library/session/auth');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($_CONFIG['title'], ENT_QUOTES, 'UTF-8') ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Logo -->
    <link rel="icon" href="<?= $_CONFIG['icon'] ?>">
    
    <style>
        body { background:#f1f5f9 }
        .slide { display: none; }
        .slide.active { display: block; }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center">

<div class="w-full max-w-md bg-white min-h-screen flex flex-col justify-between">

    <!-- ================= SLIDES ================= -->
    <div class="flex-1 flex items-center justify-center px-6">

        <!-- SLIDE 1 -->
        <div class="slide active text-center" data-slide="0">
            <img src="<?= htmlspecialchars($_CONFIG['icon_nav'], ENT_QUOTES, 'UTF-8') ?>"
                 class="h-16 mx-auto mb-6">
            <h1 class="text-xl font-bold mb-2">Dompet Digital Modern</h1>
            <p class="text-sm text-slate-500">
                Kelola saldo, transaksi, dan pembayaran dalam satu aplikasi
            </p>
        </div>

        <!-- SLIDE 2 -->
        <div class="slide text-center" data-slide="1">
            <img src="/library/wisno/image/rewards.png" class="h-16 mx-auto mb-6">
            <h1 class="text-xl font-bold mb-2">Transaksi Cepat & Aman</h1>
            <p class="text-sm text-slate-500">
                Sistem keamanan berlapis untuk setiap transaksi Anda
            </p>
        </div>

        <!-- SLIDE 3 -->
        <div class="slide text-center" data-slide="2">
            <img src="/library/wisno/image/play.png" class="h-16 mx-auto mb-6">
            <h1 class="text-xl font-bold mb-2">Semua Kebutuhan Digital</h1>
            <p class="text-sm text-slate-500">
                Pulsa, game, tagihan, hingga top up saldo
            </p>
        </div>

    </div>

    <!-- ================= INDICATOR ================= -->
    <div class="flex justify-center gap-2 mb-4">
        <span class="dot w-2 h-2 rounded-full bg-blue-500"></span>
        <span class="dot w-2 h-2 rounded-full bg-slate-300"></span>
        <span class="dot w-2 h-2 rounded-full bg-slate-300"></span>
    </div>

    <!-- ================= ACTION ================= -->
    <div class="px-6 pb-6 space-y-3">

        <button
            id="nextBtn"
            class="w-full bg-blue-500 hover:bg-blue-600 text-white
                   py-4 rounded-xl font-semibold transition">
            Lanjut
        </button>

        <div class="grid grid-cols-2 gap-3">
            <a href="/auth/login"
               class="text-center py-3 rounded-xl border font-semibold">
                Login
            </a>
            <a href="/auth/register"
               class="text-center py-3 rounded-xl bg-blue-50 text-blue-600 font-semibold">
                Daftar
            </a>
        </div>

    </div>

</div>

<!-- ================= JS SLIDER ================= -->
<script>
let currentSlide = 0;
const slides = document.querySelectorAll('.slide');
const dots = document.querySelectorAll('.dot');
const nextBtn = document.getElementById('nextBtn');

function showSlide(index) {
    slides.forEach((s, i) => {
        s.classList.toggle('active', i === index);
        dots[i].classList.toggle('bg-blue-500', i === index);
        dots[i].classList.toggle('bg-slate-300', i !== index);
    });

    nextBtn.textContent = index === slides.length - 1
        ? 'Mulai'
        : 'Lanjut';
}

nextBtn.addEventListener('click', () => {
    if (currentSlide < slides.length - 1) {
        currentSlide++;
        showSlide(currentSlide);
    } else {
        window.location.href = 'auth/login';
    }
});

showSlide(currentSlide);
</script>

</body>
</html>