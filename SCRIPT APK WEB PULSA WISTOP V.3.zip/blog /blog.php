<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Blog</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { background:#f1f5f9 }
    </style>
</head>
<body class="min-h-screen flex justify-center">

<div class="w-full max-w-md md:max-w-lg lg:max-w-xl bg-slate-100 relative">

<!-- ================= PAGE HEADER ================= -->
<section class="bg-white px-4 py-5 shadow-sm">
    <h1 class="text-lg font-semibold text-slate-800">Blog</h1>
    <p class="text-xs text-slate-500 mt-1">
        Artikel & informasi terbaru
    </p>
</section>

<!-- ================= CATEGORY ================= -->
<section class="px-4 mt-4 flex gap-2 overflow-x-auto">
    <?php
    $categories = ['Semua','Tips','Promo','Keamanan','Update'];
    foreach ($categories as $c):
    ?>
    <span
        class="px-4 py-2 rounded-full text-xs font-semibold
               <?= $c === 'Semua'
                    ? 'bg-blue-500 text-white'
                    : 'bg-white text-slate-600 shadow-sm' ?>">
        <?= $c ?>
    </span>
    <?php endforeach ?>
</section>

<!-- ================= BLOG LIST ================= -->
<section class="px-4 mt-4 space-y-4 pb-28">

    <?php
    // Dummy data (siap dari DB)
    $posts = [
        [
            'title' => 'Cara Aman Menggunakan Dompet Digital',
            'excerpt' => 'Pelajari tips penting untuk menjaga keamanan akun dan transaksi digital Anda.',
            'date' => '21 Jan 2026',
            'category' => 'Keamanan',
            'link' => 'detail.php?id=1'
        ],
        [
            'title' => 'Promo Cashback Bulan Ini',
            'excerpt' => 'Nikmati berbagai promo cashback menarik untuk setiap transaksi.',
            'date' => '18 Jan 2026',
            'category' => 'Promo',
            'link' => 'detail.php?id=2'
        ],
        [
            'title' => 'Update Fitur Terbaru WisnoPay',
            'excerpt' => 'Kenali fitur-fitur baru yang memudahkan transaksi Anda.',
            'date' => '15 Jan 2026',
            'category' => 'Update',
            'link' => 'detail.php?id=3'
        ],
    ];

    foreach ($posts as $p):
    ?>

    <a href="<?= $p['link'] ?>"
       class="block bg-white rounded-2xl shadow-sm p-4 hover:shadow transition">

        <span class="inline-block text-xs font-semibold text-blue-600 mb-2">
            <?= $p['category'] ?>
        </span>

        <h2 class="text-base font-semibold text-slate-800 mb-1">
            <?= $p['title'] ?>
        </h2>

        <p class="text-sm text-slate-600 line-clamp-2">
            <?= $p['excerpt'] ?>
        </p>

        <div class="mt-3 text-xs text-slate-400">
            <?= $p['date'] ?>
        </div>

    </a>

    <?php endforeach ?>

</section>

<?php include __DIR__ . '/../layout/user/footer.php'; ?>

</div>
</body>
</html>