<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Detail Artikel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { background:#f1f5f9 }
    </style>
</head>
<body class="min-h-screen flex justify-center">

<div class="w-full max-w-md md:max-w-lg lg:max-w-xl bg-slate-100 relative">

<!-- ================= PAGE HEADER ================= -->
<section class="bg-white px-4 py-5 shadow-sm">
    <a href="blog.php" class="text-xs text-blue-500 font-semibold">
        ← Kembali ke Blog
    </a>
    <h1 class="text-lg font-semibold text-slate-800 mt-2">
        Cara Aman Menggunakan Dompet Digital
    </h1>
    <div class="mt-1 flex items-center gap-2 text-xs text-slate-500">
        <span class="bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full">
            Keamanan
        </span>
        <span>21 Jan 2026</span>
    </div>
</section>

<!-- ================= CONTENT ================= -->
<section class="px-4 mt-4 pb-28">
    <article class="bg-white rounded-2xl shadow-sm p-4 text-sm text-slate-700 leading-relaxed space-y-4">

        <p>
            Dompet digital kini menjadi bagian penting dalam kehidupan sehari-hari.
            Namun, penggunaan yang tidak bijak dapat meningkatkan risiko keamanan.
            Oleh karena itu, penting bagi pengguna untuk memahami cara menggunakan
            dompet digital dengan aman.
        </p>

        <p>
            Pastikan Anda selalu menjaga kerahasiaan data pribadi, seperti PIN dan
            password akun. Jangan pernah membagikan informasi sensitif kepada siapa
            pun, termasuk pihak yang mengaku sebagai layanan resmi.
        </p>

        <p>
            Selain itu, aktifkan fitur keamanan tambahan seperti verifikasi dua
            langkah (2FA) untuk memberikan perlindungan ekstra pada akun Anda.
            Selalu periksa riwayat transaksi secara berkala untuk memastikan tidak
            ada aktivitas mencurigakan.
        </p>

        <p>
            Dengan menerapkan langkah-langkah tersebut, Anda dapat menggunakan
            dompet digital dengan lebih aman dan nyaman.
        </p>

    </article>
</section>

<?php include __DIR__ . '/../layout/user/footer.php'; ?>

</div>
</body>
</html>