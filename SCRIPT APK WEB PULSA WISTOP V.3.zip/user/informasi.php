<?php
require '../connect.php';
require _DIR_('library/session/user');
include __DIR__ . '/layout/user/header.php';

/* ================= LOAD BANNER ================= */
$qBanner = mysqli_query($call,"
    SELECT title, highlight, icon_color
    FROM info_banner
    WHERE status='ON'
    ORDER BY id DESC
");
?>

<div class="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">

    <!-- HEADER -->
    <section class="bg-white/80 backdrop-blur sticky top-0 z-10 border-b">
        <div class="px-4 py-5">
            <h1 class="text-xl font-bold text-slate-800 tracking-tight">
                Pusat Informasi
            </h1>
            <p class="text-sm text-slate-500 mt-1">
                Update terbaru & pengumuman penting
            </p>
        </div>
    </section>

    <!-- CONTENT -->
    <section class="px-4 py-6 space-y-4 pb-24">

    <?php if(mysqli_num_rows($qBanner) > 0): ?>
        <?php while($b = mysqli_fetch_assoc($qBanner)): ?>

            <div class="group bg-white rounded-3xl p-5 shadow-sm hover:shadow-md transition-all duration-300 border border-slate-100">

                <div class="flex items-start gap-4">

                    <!-- ICON -->
                    <div class="flex-shrink-0">
                        <div class="w-12 h-12 rounded-2xl flex items-center justify-center
                                    bg-<?= htmlspecialchars($b['icon_color']) ?>-100">

                            <!-- DOT DECORATION -->
                            <div class="w-5 h-5 rounded-full
                                        bg-<?= htmlspecialchars($b['icon_color']) ?>-500
                                        group-hover:scale-110 transition">
                            </div>

                        </div>
                    </div>

                    <!-- TEXT -->
                    <div class="flex-1 min-w-0">

                        <p class="text-sm text-slate-700 leading-relaxed">
                            <?= htmlspecialchars($b['title']) ?>
                            <span class="font-semibold text-<?= htmlspecialchars($b['icon_color']) ?>-600 ml-1">
                                <?= htmlspecialchars($b['highlight']) ?>
                            </span>
                        </p>

                        <!-- META -->
                        <div class="flex items-center gap-2 mt-3">
                            <span class="text-[11px] px-2 py-1 rounded-full bg-slate-100 text-slate-500">
                                Informasi
                            </span>
                            <span class="text-[11px] text-slate-400">
                                Sistem
                            </span>
                        </div>

                    </div>

                </div>

            </div>

        <?php endwhile; ?>

    <?php else: ?>

        <!-- EMPTY STATE -->
        <div class="flex flex-col items-center justify-center py-20 text-center">

            <div class="w-20 h-20 rounded-full bg-slate-200 flex items-center justify-center mb-6">
                <div class="w-10 h-10 rounded-full bg-slate-400 opacity-40"></div>
            </div>

            <h3 class="font-semibold text-slate-700 text-lg">
                Belum Ada Informasi
            </h3>

            <p class="text-sm text-slate-500 mt-2 max-w-xs">
                Informasi terbaru akan muncul di halaman ini.
                Silakan cek kembali nanti.
            </p>

        </div>

    <?php endif; ?>

    </section>

</div>

<?php include __DIR__ . '/layout/user/footer.php'; ?>