<?php
header('Content-type: application/json');
require '../../../connect.php';

// ================= AMBIL JSON =================
$json = file_get_contents('php://input');
$data = json_decode($json, true);

if(!$data){
    echo json_encode(['status'=>false,'msg'=>'Invalid data']);
    exit;
}


// ================= AMBIL DATA =================
$trxid  = $data['trxid']  ?? '';
$status = strtolower($data['status'] ?? '');
$note   = $data['note']   ?? '';

if(!$trxid){
    echo json_encode(['status'=>false,'msg'=>'No trxid']);
    exit;
}


// ================= CARI TRANSAKSI =================
$trx = $call->query("SELECT * FROM transaction WHERE tid='$trxid'");

if($trx->num_rows == 0){
    echo json_encode(['status'=>false,'msg'=>'Transaction not found']);
    exit;
}

$t = $trx->fetch_assoc();


// ================= CEK SUDAH FINAL BELUM =================
if($t['status'] == 'success'){
    echo json_encode(['status'=>true,'msg'=>'Already success']);
    exit;
}


// ================= SUCCESS =================
if($status == 'success'){

    $call->query("UPDATE transaction 
                  SET status='success',
                      note='$note',
                      date_up=NOW()
                  WHERE tid='$trxid'");

    echo json_encode(['status'=>true]);
    exit;
}


// ================= ERROR =================
if($status == 'error'){

    // refund saldo
    if($t['trxtype'] == 'prepaid'){
        $call->query("UPDATE users 
                      SET balance = balance + '".$t['price']."' 
                      WHERE username='".$t['user']."'");

        $call->query("INSERT INTO mutation 
                      VALUES (null,'".$t['user']."','+','".$t['price']."','Refund',NOW())");
    }

    $call->query("UPDATE transaction 
                  SET status='error',
                      note='$note',
                      refund='1',
                      date_up=NOW()
                  WHERE tid='$trxid'");

    echo json_encode(['status'=>true]);
    exit;
}

echo json_encode(['status'=>false,'msg'=>'Unknown status']);
