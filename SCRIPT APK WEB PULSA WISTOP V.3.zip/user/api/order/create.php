<?php
header('Content-type: application/json');
require '../../../connect.php';
require _DIR_('library/session/user');

// ================= VALIDASI INPUT =================
$target  = trim($_POST['target'] ?? '');
$service = intval($_POST['service'] ?? 0);

if(!$target || !$service){
    echo json_encode(['status'=>false,'msg'=>'Data tidak lengkap']);
    exit;
}

// ================= AMBIL SERVICE =================
$s = $call->query("SELECT * FROM services WHERE id='$service' AND status='available'");
if($s->num_rows == 0){
    echo json_encode(['status'=>false,'msg'=>'Service tidak ditemukan']);
    exit;
}
$sv = $s->fetch_assoc();
$price = $sv['price'];
$total_price = $sv['price'] + $sv['basic'];

// ================= LOCK USER & CEK SALDO =================
$u = $call->query("SELECT balance FROM users WHERE username='$sess_username' FOR UPDATE")->fetch_assoc();

if($u['balance'] < $total_price){
    echo json_encode(['status'=>false,'msg'=>'Saldo tidak cukup']);
    exit;
}


// ================= GENERATE WID =================
$wid = 'TRX'.date('YmdHis').rand(100,999);


// ================= POTONG SALDO =================
$cut = $call->query("UPDATE users SET balance = balance - $total_price WHERE username='$sess_username'");
if(!$cut){
    echo json_encode(['status'=>false,'msg'=>'Gagal potong saldo']);
    exit;
}


// ================= INSERT TRANSAKSI =================
$insert = $call->query("INSERT INTO transaction
(wid, user, code, name, data, price, profit, status, trxtype, date_cr, date_up, provider)
VALUES
(
    '$wid',
    '$sess_username',
    '".$sv['code']."',
    '".$sv['name']."',
    '$target',
    '$total_price',
    '".$sv['basic']."',
    'waiting',
    'prepaid',
    NOW(),
    NOW(),
    '".$sv['provider']."'
)");

if(!$insert){

    // kalau insert gagal → refund
    $call->query("UPDATE users SET balance = balance + $total_price WHERE username='$sess_username'");

    echo json_encode(['status'=>false,'msg'=>'Gagal membuat transaksi']);
    exit;
}


// ================= KIRIM KE PROVIDER =================

$po = $PUSATPPOB->Order([
    'service' => $sv['code'],
    'data_no' => $target
]);

if($po['result'] == true) {

    $trx_provider = $po['data']['_LannOutput'];

    $call->query("
        UPDATE transaction 
        SET tid='$trx_provider', date_up=NOW()
        WHERE user='$sess_username'
        ORDER BY date_cr DESC
        LIMIT 1
    ");

    // catat mutasi
    $call->query("INSERT INTO mutation 
                  VALUES (null,'$sess_username','-','$total_price','Prepaid Order :: $wid',NOW())");

} else {

    // ================= REFUND =================
    $refund = $call->query("UPDATE users 
                            SET balance = balance + $total_price 
                            WHERE username='$sess_username'");

    if($refund){
        $call->query("
            DELETE FROM transaction 
            WHERE user='$sess_username' 
            ORDER BY date_cr DESC 
            LIMIT 1
        ");
    }

    echo json_encode([
        'status'=>false,
        'msg'=> $po['message']
    ]);
    exit;
}


// ================= AMBIL WID FINAL =================
$q = $call->query("
    SELECT wid FROM transaction 
    WHERE user='$sess_username'
    ORDER BY date_cr DESC
    LIMIT 1
");

$d = $q->fetch_assoc();

echo json_encode([
    'status' => true,
    'trx'    => $d['wid']
]);