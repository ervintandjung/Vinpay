<?php
header('Content-type: application/json');
require '../../../connect.php';

$brand = $_GET['brand'] ?? '';
$type  = $_GET['type'] ?? '';

$brand = $call->real_escape_string($brand);
$type  = $call->real_escape_string($type);

$q = $call->query("
    SELECT DISTINCT varian
    FROM services
    WHERE brand='$brand'
    AND type='$type'
    AND status='available'
    ORDER BY varian ASC
");

$data = [];
while($r = $q->fetch_assoc()){
    if($r['varian'] != ''){
        $data[] = $r['varian'];
    }
}

echo json_encode($data);