<?php
header('Content-type: application/json');
require '../../../connect.php';

$category = $_GET['category'] ?? '';
$varian   = $_GET['varian'] ?? '';

$category = $call->real_escape_string($category);
$varian   = $call->real_escape_string($varian);

$sql = "SELECT id,name,price,basic
        FROM services
        WHERE brand='$category'
        AND status='available'";

if(!empty($varian)){
    $sql .= " AND varian='$varian'";
}

$sql .= " ORDER BY price ASC";

$q = $call->query($sql);

$data = [];

while($r = $q->fetch_assoc()){
    $data[] = $r;
}

echo json_encode($data);