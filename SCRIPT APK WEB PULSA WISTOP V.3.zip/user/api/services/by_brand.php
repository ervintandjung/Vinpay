<?php
header('Content-type: application/json');
require '../../../connect.php';

$brand   = $_GET['brand'] ?? '';
$type    = $_GET['type'] ?? '';
$varian  = $_GET['varian'] ?? '';

$brand  = $call->real_escape_string($brand);
$type   = $call->real_escape_string($type);
$varian = $call->real_escape_string($varian);

$sql = "SELECT id, name, price, basic
        FROM services
        WHERE brand='$brand'
        AND type='$type'
        AND status='available'";

if(!empty($varian)){
    $sql .= " AND varian='$varian'";
}

$sql .= " ORDER BY price ASC";

$q = $call->query($sql);

$data = [];
while($r = $q->fetch_assoc()){
    $data[] = $r;
}

echo json_encode($data);