<?php
header('Content-type: application/json');
require '../../../connect.php';

$category = $_GET['category'] ?? '';
$category = $call->real_escape_string($category);

$q = $call->query("
    SELECT DISTINCT varian
    FROM services
    WHERE brand='$category'
    AND status='available'
    AND varian IS NOT NULL
    AND varian != ''
    ORDER BY varian ASC
");

$data = [];

while($r = $q->fetch_assoc()){
    $data[] = $r['varian'];
}

echo json_encode($data);