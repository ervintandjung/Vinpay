<?php 
require '../connect.php';
require _DIR_('library/session/user');

$get_s = isset($_GET['s']) ? strtolower(filter($_GET['s'])) : '';
if($get_s == 'pulsa-reguler') $title = 'Pulsa Reguler';
else if($get_s == 'pulsa-transfer') $title = 'Pulsa Transfer';
else if($get_s == 'paket-internet') $title = 'Paket Internet';
else if($get_s == 'paket-telepon') $title = 'Paket SMS & Telepon';
else exit(redirect(0,base_url()));
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>
    <?= htmlspecialchars($_CONFIG['title'], ENT_QUOTES, 'UTF-8') ?>
    <?= !empty($title) ? ' - ' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') : '' ?>
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.tailwindcss.com"></script>
    
    <link rel="icon" href="<?= htmlspecialchars($_CONFIG['icon'], ENT_QUOTES, 'UTF-8') ?>">
    
    <style>
        body { background:#f1f5f9 }
    </style>
</head>
<body class="min-h-screen flex justify-center">

<div class="w-full max-w-md md:max-w-lg lg:max-w-xl bg-slate-100 relative">

<!-- ================= PAGE HEADER ================= -->
<section class="bg-white px-4 py-5 shadow-sm">
    <h1 class="text-lg font-semibold text-slate-800"><?= $title ?></h1>
    <p class="text-xs text-slate-500 mt-1">
        Beli <?= $title ?>
    </p>
</section>

<!-- ================= INPUT NOMOR ================= -->
<section class="px-4 mt-4">
    <label class="text-sm font-semibold text-slate-700">
        Target
    </label>
    <input
        id="phoneInput"
        type="tel"
        placeholder="Masukan data tujuan"
        class="mt-2 w-full bg-white rounded-xl px-4 py-3
               text-sm outline-none shadow-sm
               focus:ring-2 focus:ring-blue-500"
        oninput="detectProvider()">
</section>

<!-- ================= PROVIDER INFO ================= -->
<section class="px-4 mt-3">
    <div class="bg-white rounded-xl p-4 shadow-sm flex justify-between items-center">
        <span class="text-sm text-slate-600">Provider</span>
        <span id="providerText" class="text-sm font-semibold text-slate-700">
            -
        </span>
    </div>
</section>

<!-- ================= KATEGORI ================= -->
<section class="px-4 mt-5">
    <p class="text-sm font-semibold text-slate-700 mb-2">
        Pilih Kategori
    </p>

    <div id="categoryList" class="flex gap-2 overflow-x-auto pb-2"></div>
</section>

<!-- ================= NOMINAL ================= -->
<section class="px-4 mt-5">
    <p class="text-sm font-semibold text-slate-700 mb-2">
        Pilih Nominal
    </p>

    <div id="serviceList" class="grid grid-cols-3 gap-3"></div>
</section>

<!-- ================= SUBMIT ================= -->
<section class="px-4 mt-6 pb-28">
    <button
        id="btnOrder"
        class="w-full bg-blue-500 hover:bg-blue-600 text-white
               py-4 rounded-xl font-semibold transition">
        Lanjutkan Pembayaran
    </button>
</section>

<?php include __DIR__ . '/layout/user/footer.php'; ?>

</div>

<!-- ================= JS PROVIDER DETECTION ================= -->
<script>
let selectedService = null;
let selectedVarian = null;
let typingTimer;
const doneTypingInterval = 500;


// ================= DETECT PROVIDER =================
function detectProvider() {

    clearTimeout(typingTimer);

    typingTimer = setTimeout(() => {

        const input = document.getElementById('phoneInput').value;
        const providerText = document.getElementById('providerText');

        const number = input.replace(/\D/g,'');

        selectedService = null;
        selectedVarian = null;

        document.getElementById('serviceList').innerHTML = '';
        document.getElementById('categoryList').innerHTML = '';

        disableOrder();

        if(number.length < 10){
            providerText.textContent = '-';
            return;
        }

        let provider = '-';

        if (/^(0811|0812|0813|0821|0822|0823|0851|0852|0853)/.test(number)) {
            provider = 'Telkomsel';
        } else if (/^(0814|0815|0816|0855|0856|0857|0858)/.test(number)) {
            provider = 'Indosat';
        } else if (/^(0817|0818|0819|0859|0877|0878)/.test(number)) {
            provider = 'XL / Axis';
        } else if (/^(0895|0896|0897|0898|0899)/.test(number)) {
            provider = 'Tri (3)';
        } else if (/^(0881|0882|0883|0884|0885|0886|0887|0888|0889)/.test(number)) {
            provider = 'Smartfren';
        }

        providerText.textContent = provider;

        if(provider !== '-'){
            loadVarians(provider);
        }

    }, doneTypingInterval);
}


// ================= LOAD VARIAN =================
function loadVarians(brand){

    const wrap = document.getElementById('categoryList');

    fetch('<?= base_url('user/api/services/by_varian') ?>?brand='+brand+'&type=<?= $get_s ?>')
    .then(r=>r.json())
    .then(res=>{

        if(res.length === 0){
            wrap.innerHTML = '<div class="text-sm text-slate-500">Varian tidak tersedia</div>';
            return;
        }

        wrap.innerHTML = res.map(v=>`
            <button onclick="selectVarian(this,'${v}')"
                class="bg-white px-4 py-2 rounded-xl text-sm shadow-sm whitespace-nowrap">
                ${v}
            </button>
        `).join('');
    });
}


// ================= PILIH VARIAN =================
function selectVarian(el, varian){

    selectedVarian = varian;

    document.querySelectorAll('#categoryList button')
        .forEach(b=>b.classList.remove('ring-2','ring-blue-500'));

    el.classList.add('ring-2','ring-blue-500');

    const provider = document.getElementById('providerText').textContent;

    loadServices(provider, varian);
}


// ================= LOAD SERVICE =================
function loadServices(brand, varian=''){

    let url = '<?= base_url('user/api/services/by_brand') ?>?brand='
        + brand +
        '&type=<?= $get_s ?>';

    if(varian){
        url += '&varian=' + encodeURIComponent(varian);
    }

    fetch(url)
    .then(r=>r.json())
    .then(res=>{

        const wrap = document.getElementById('serviceList');

        if(res.length === 0){
            wrap.innerHTML =
            '<div class="col-span-3 text-center text-sm text-slate-500">Produk tidak tersedia</div>';
            return;
        }

        wrap.innerHTML = res.map(s=>`
            <button onclick="selectService(this,'${s.id}')"
                class="bg-white rounded-xl py-3 text-sm font-semibold shadow-sm hover:bg-blue-50 transition">
                ${s.name}
                <div class="text-xs text-slate-500 mt-1">
                    Rp ${Number(Number(s.price)+Number(s.basic)).toLocaleString()}
                </div>
            </button>
        `).join('');
    });
}


// ================= PILIH SERVICE =================
function selectService(el,id){

    selectedService = id;

    document.querySelectorAll('#serviceList button')
        .forEach(b=>b.classList.remove('ring-2','ring-blue-500'));

    el.classList.add('ring-2','ring-blue-500');

    enableOrder();
}


// ================= BUTTON CONTROL =================
function disableOrder(){
    const btn = document.getElementById('btnOrder');
    btn.disabled = true;
    btn.classList.add('opacity-50','cursor-not-allowed');
}

function enableOrder(){
    const btn = document.getElementById('btnOrder');
    btn.disabled = false;
    btn.classList.remove('opacity-50','cursor-not-allowed');
}

disableOrder();


// ================= ORDER =================
document.getElementById('btnOrder').addEventListener('click',()=>{

    const target = document.getElementById('phoneInput').value;

    if(!target) return alert('Masukkan tujuan');
    if(!selectedService) return alert('Pilih nominal');

    disableOrder();

    fetch('<?= base_url('user/api/order/create') ?>',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:new URLSearchParams({
            target:target,
            service:selectedService
        })
    })
    .then(r=>r.json())
    .then(r=>{
        if(!r.status){
            enableOrder();
            return alert(r.msg);
        }

        window.location='<?= base_url('user/invoice?trx=') ?>'+r.trx;
    });
});
</script>

</body>
</html>
