<?php 
require '../connect.php';
require _DIR_('library/session/user');

$get_s = isset($_GET['s']) ? strtolower(filter($_GET['s'])) : '';

if($get_s == 'token-pln') $title = 'Token Listrik (PLN)';
else if($get_s == 'saldo-emoney') $title = 'Saldo E-Money';
else if($get_s == 'voucher-game') $title = 'Voucher Game';
else if($get_s == 'streaming-tv') $title = 'Streaming & TV';
else if($get_s == 'paket-lainnya') $title = 'Paket Lainnya';
else exit(redirect(0,base_url()));
?>

<!DOCTYPE html>
<html lang="id">
<head>

<meta charset="UTF-8">
<title>
<?= htmlspecialchars($_CONFIG['title'], ENT_QUOTES, 'UTF-8') ?>
<?= !empty($title) ? ' - ' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') : '' ?>
</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<script src="https://cdn.tailwindcss.com"></script>

<link rel="icon" href="<?= htmlspecialchars($_CONFIG['icon'], ENT_QUOTES, 'UTF-8') ?>">

<style>

body{
background:#f1f5f9;
font-family:system-ui;
}

/* hide scrollbar */
.scrollbar-hide::-webkit-scrollbar{
display:none;
}

/* toast animation */
@keyframes toastIn{
from{
opacity:0;
transform:translateY(-15px);
}
to{
opacity:1;
transform:translateY(0);
}
}

@keyframes toastOut{
from{
opacity:1;
transform:translateY(0);
}
to{
opacity:0;
transform:translateY(-10px);
}
}

</style>

</head>


<body class="min-h-screen flex justify-center">


<div class="w-full max-w-md md:max-w-lg lg:max-w-xl bg-white min-h-screen relative">


<!-- HEADER -->
<header class="sticky top-0 bg-white border-b z-20">

<div class="px-4 py-4 flex items-center gap-3">

<a href="<?= base_url('user') ?>" 
class="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center hover:bg-slate-200 transition">

<svg xmlns="http://www.w3.org/2000/svg" 
class="h-5 w-5 text-slate-700" 
fill="none" viewBox="0 0 24 24" stroke="currentColor">

<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
d="M15 19l-7-7 7-7"/>

</svg>

</a>

<div>

<h1 class="font-semibold text-slate-800 text-lg">
<?= $title ?>
</h1>

<p class="text-xs text-slate-500">
Beli <?= $title ?>
</p>

</div>

</div>

</header>



<!-- CONTENT -->
<div class="px-4 pb-10 space-y-6 mt-4">



<!-- CATEGORY -->
<section class="bg-white border rounded-2xl p-4 shadow-sm">

<label class="text-sm font-semibold text-slate-700">
Pilih Kategori
</label>

<select 
id="gameSelect"
class="mt-2 w-full bg-slate-50 border rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-blue-500">

<option value="">Pilih kategori</option>

<?php
$cat = $call->query("SELECT code,name FROM category WHERE type='$get_s' ORDER BY name ASC");
while($c = $cat->fetch_assoc()){
echo '<option value="'.$c['code'].'">'.$c['name'].'</option>';
}
?>

</select>

</section>



<!-- TARGET -->
<section class="bg-white border rounded-2xl p-4 shadow-sm">

<label class="text-sm font-semibold text-slate-700">
User ID / Target
</label>

<input
id="targetInput"
type="text"
placeholder="Contoh: 12345678 (1234)"
class="mt-2 w-full bg-slate-50 border rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-blue-500">

</section>



<!-- VARIAN -->
<section>

<p class="text-sm font-semibold text-slate-700 mb-2">
Pilih Varian
</p>

<div id="varianList" class="flex gap-2 overflow-x-auto pb-2 scrollbar-hide"></div>

</section>



<!-- NOMINAL -->
<section>

<p class="text-sm font-semibold text-slate-700 mb-2">
Pilih Nominal
</p>

<div id="serviceList" class="grid grid-cols-2 gap-3"></div>

</section>



<!-- CHECKOUT BUTTON -->
<section class="mt-6 pb-8">

<button
id="btnOrder"
class="w-full bg-blue-600 hover:bg-blue-700 active:scale-[0.98] transition text-white py-4 rounded-xl font-semibold">

Lanjutkan Pembayaran

</button>

</section>



</div>


<?php include __DIR__ . '/layout/user/footer.php'; ?>



<!-- TOAST CONTAINER -->
<div id="toastContainer"
class="fixed top-6 left-1/2 -translate-x-1/2 z-[9999] w-[92%] max-w-sm space-y-2">
</div>



<script>


let selectedService = null;
let selectedVarian = null;



/* ================= CATEGORY CHANGE ================= */

document.getElementById('gameSelect').addEventListener('change', function(){

const category = this.value;

selectedService = null;
selectedVarian = null;

disableOrder();

document.getElementById('serviceList').innerHTML='';
document.getElementById('varianList').innerHTML='';

if(!category) return;

loadVarians(category);

});



/* ================= LOAD VARIANS ================= */

function loadVarians(category){

const wrap=document.getElementById('varianList');

wrap.innerHTML='<div class="text-sm text-slate-400">Memuat varian...</div>';

fetch('<?= base_url('user/api/services/varians_by_category') ?>?category='+encodeURIComponent(category))
.then(r=>r.json())
.then(res=>{

if(res.length===0){

wrap.innerHTML='<div class="text-sm text-slate-500">Varian tidak tersedia</div>';
return;

}

wrap.innerHTML=res.map(v=>`

<button onclick="selectVarian(this,'${v}')"
class="bg-white border px-4 py-2 rounded-full text-sm hover:bg-blue-50 transition whitespace-nowrap">

${v}

</button>

`).join('');

});

}



/* ================= SELECT VARIAN ================= */

function selectVarian(el,varian){

selectedVarian=varian;
selectedService=null;

disableOrder();

document.querySelectorAll('#varianList button')
.forEach(b=>b.classList.remove('ring-2','ring-blue-500'));

el.classList.add('ring-2','ring-blue-500');

const category=document.getElementById('gameSelect').value;

loadServices(category,varian);

}



/* ================= LOAD SERVICES ================= */

function loadServices(category,varian){

const wrap=document.getElementById('serviceList');

wrap.innerHTML='<div class="col-span-2 text-center text-sm text-slate-400">Memuat produk...</div>';

fetch('<?= base_url('user/api/services/by_category') ?>?category='+encodeURIComponent(category)+'&varian='+encodeURIComponent(varian))
.then(r=>r.json())
.then(res=>{

if(res.length===0){

wrap.innerHTML='<div class="col-span-2 text-center text-sm text-slate-500">Produk tidak tersedia</div>';
return;

}

wrap.innerHTML=res.map(s=>`

<button onclick="selectService(this,'${s.id}')"
class="bg-white border rounded-xl p-3 text-left hover:border-blue-500 hover:bg-blue-50 transition">

<div class="text-sm font-semibold text-slate-700">
${s.name}
</div>

<div class="text-xs text-slate-500 mt-1">
Rp ${(Number(s.price||0)+Number(s.basic||0)).toLocaleString()}
</div>

</button>

`).join('');

});

}



/* ================= SELECT SERVICE ================= */

function selectService(el,id){

selectedService=id;

document.querySelectorAll('#serviceList button')
.forEach(b=>b.classList.remove('ring-2','ring-blue-500'));

el.classList.add('ring-2','ring-blue-500');

enableOrder();

}



/* ================= BUTTON CONTROL ================= */

function disableOrder(){

const btn=document.getElementById('btnOrder');

btn.disabled=true;

btn.classList.add('opacity-50','cursor-not-allowed');

}

function enableOrder(){

const btn=document.getElementById('btnOrder');

btn.disabled=false;

btn.classList.remove('opacity-50','cursor-not-allowed');

}

disableOrder();



/* ================= TOAST SYSTEM ================= */

function toast(message,type='info',duration=3500){

const container=document.getElementById('toastContainer');

let bg='bg-blue-600';
let icon='';

if(type==='success'){
bg='bg-emerald-600';
icon='✔';
}

if(type==='error'){
bg='bg-red-600';
icon='✖';
}

if(type==='warning'){
bg='bg-amber-500';
icon='⚠';
}

const el=document.createElement('div');

el.className=`${bg} text-white px-4 py-3 rounded-xl shadow-xl flex items-center gap-3 text-sm font-medium animate-[toastIn_.25s_ease]`;

el.innerHTML=`
<div>${icon}</div>
<div class="flex-1">${message}</div>
<button onclick="this.parentElement.remove()" class="opacity-70 hover:opacity-100">✕</button>
`;

container.appendChild(el);

setTimeout(()=>{
el.style.animation="toastOut .25s ease";
setTimeout(()=>el.remove(),250);
},duration);

}



/* ================= ORDER ================= */

document.getElementById('btnOrder').addEventListener('click',()=>{

const target=document.getElementById('targetInput').value.trim();

if(!target){
toast('Masukkan tujuan','error');
return;
}

if(!selectedService){
toast('Pilih nominal','error');
return;
}

disableOrder();

fetch('<?= base_url('user/api/order/create') ?>',{

method:'POST',

headers:{'Content-Type':'application/x-www-form-urlencoded'},

body:new URLSearchParams({
target:target,
service:selectedService
})

})
.then(r=>r.json())
.then(r=>{

if(!r.status){

enableOrder();
toast(r.msg,'error');
return;

}

toast('Pesanan berhasil dibuat','success');

setTimeout(()=>{
window.location='<?= base_url('user/invoice?trx=') ?>'+r.trx;
},900);

});

});

</script>


</body>
</html>