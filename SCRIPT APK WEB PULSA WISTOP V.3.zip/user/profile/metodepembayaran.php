<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Metode Pembayaran</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { background:#f1f5f9 }
    </style>
</head>
<body class="min-h-screen flex justify-center">

<div class="w-full max-w-md md:max-w-lg lg:max-w-xl bg-slate-100 relative">

<!-- ================= PAGE HEADER ================= -->
<section class="bg-white px-4 py-5 shadow-sm">
    <h1 class="text-lg font-semibold text-slate-800">Metode Pembayaran</h1>
    <p class="text-xs text-slate-500 mt-1">
        Kelola metode pembayaran Anda
    </p>
</section>

<!-- ================= SALDO ================= -->
<section class="px-4 mt-4">
    <div class="bg-blue-50 border border-blue-200 rounded-2xl p-4 flex justify-between items-center">
        <div>
            <p class="text-xs text-blue-600">Saldo</p>
            <p class="text-lg font-bold text-blue-700">Rp 144.000</p>
        </div>
        <span class="text-xs bg-blue-500 text-white px-3 py-1 rounded-full font-semibold">
            Utama
        </span>
    </div>
</section>

<!-- ================= PAYMENT LIST ================= -->
<section class="px-4 mt-5 space-y-3 pb-28">

    <!-- TRANSFER BANK -->
    <div class="bg-white rounded-2xl shadow-sm p-4 flex justify-between items-center">
        <div>
            <p class="text-sm font-semibold text-slate-700">Transfer Bank</p>
            <p class="text-xs text-slate-500">BCA, BRI, Mandiri, BNI</p>
        </div>
        <span class="text-slate-400">›</span>
    </div>

    <!-- VIRTUAL ACCOUNT -->
    <div class="bg-white rounded-2xl shadow-sm p-4 flex justify-between items-center">
        <div>
            <p class="text-sm font-semibold text-slate-700">Virtual Account</p>
            <p class="text-xs text-slate-500">VA Otomatis</p>
        </div>
        <span class="text-slate-400">›</span>
    </div>

    <!-- E-WALLET -->
    <div class="bg-white rounded-2xl shadow-sm p-4 flex justify-between items-center">
        <div>
            <p class="text-sm font-semibold text-slate-700">E-Wallet</p>
            <p class="text-xs text-slate-500">OVO, DANA, GoPay, ShopeePay</p>
        </div>
        <span class="text-slate-400">›</span>
    </div>

    <!-- KARTU -->
    <div class="bg-white rounded-2xl shadow-sm p-4 flex justify-between items-center">
        <div>
            <p class="text-sm font-semibold text-slate-700">Kartu Debit / Kredit</p>
            <p class="text-xs text-slate-500">Visa & Mastercard</p>
        </div>
        <span class="text-slate-400">›</span>
    </div>

</section>

<?php include __DIR__ . '/layout/user/footer.php'; ?>

</div>
</body>
</html>