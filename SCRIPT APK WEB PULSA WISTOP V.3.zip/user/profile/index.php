<?php
require '../../connect.php';
require _DIR_('library/session/user');

$userId = (int) $data_user['id'];

/* ================= HANDLE UPDATE ================= */

if(isset($_POST['saved'])) {

    $post_name    = trim($_POST['name']);
    $post_contact = trim($_POST['contact']);

    if($result_csrf == false) {
        LannXit(['type'=>false,'message'=>'System Error, Please try again later.']);
    }

    if(!$post_name || !$post_contact) {
        LannXit(['type'=>false,'message'=>'There is still a blank form.']);
    }

    if(!preg_match('/^[0-9]{8,15}$/', $post_contact)) {
        LannXit(['type'=>false,'message'=>'Invalid phone number format.']);
    }

    /* ===== HANDLE IMAGE UPLOAD ===== */
    $imageName = $data_user['image'];

    if(isset($_FILES['avatar']) && $_FILES['avatar']['error'] === 0) {

        $allowed = ['image/jpeg','image/png','image/webp'];

        if(!in_array($_FILES['avatar']['type'], $allowed)) {
            LannXit(['type'=>false,'message'=>'Invalid image format.']);
        }

        if($_FILES['avatar']['size'] > 2 * 1024 * 1024) {
            LannXit(['type'=>false,'message'=>'Image max size 2MB.']);
        }

        $ext = pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION);
        $imageName = 'profile_'.$userId.'_'.time().'.'.$ext;
        $uploadPath = __DIR__.'/../../uploads/profile/'.$imageName;

        if(move_uploaded_file($_FILES['avatar']['tmp_name'], $uploadPath)) {

            // delete old image
            if(!empty($data_user['image']) && file_exists(__DIR__.'/../../uploads/profile/'.$data_user['image'])) {
                unlink(__DIR__.'/../../uploads/profile/'.$data_user['image']);
            }

        } else {
            LannXit(['type'=>false,'message'=>'Upload failed.']);
        }
    }

    /* ===== UPDATE DATABASE (SAFE) ===== */

    $stmt = $call->prepare("UPDATE users SET name = ?, phone = ?, image = ? WHERE id = ?");
    $stmt->bind_param("sssi", $post_name, $post_contact, $imageName, $userId);

    if($stmt->execute()) {

        $_SESSION['user']['name']  = $post_name;
        $_SESSION['user']['phone'] = $post_contact;
        $_SESSION['user']['image'] = $imageName;

        LannXit(['type'=>true,'message'=>'Account has been updated.']);

    } else {
        LannXit(['type'=>false,'message'=>'Server error.']);
    }
}

/* ===== PROFILE IMAGE PATH ===== */

$profileImage = (!empty($data_user['image']) && file_exists(__DIR__.'/../../uploads/profile/'.$data_user['image']))
    ? '/uploads/profile/'.$data_user['image']
    : null;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Akun</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>body{background:#f1f5f9}</style>
</head>
<body class="min-h-screen flex justify-center">

<div class="w-full max-w-md md:max-w-lg lg:max-w-xl bg-slate-100 relative">

<section class="bg-white px-4 py-5 shadow-sm">
    <h1 class="text-lg font-semibold text-slate-800">Edit Akun</h1>
    <p class="text-xs text-slate-500 mt-1">
        Perbarui informasi akun Anda
    </p>
</section>

<section class="px-4 mt-4 pb-28">
<form method="POST" enctype="multipart/form-data" class="space-y-5">

<?php require _DIR_('library/session/result'); ?>
<input type="hidden" name="csrf_token" value="<?= $csrf_string ?>">

<!-- FOTO PROFIL -->
<div class="flex flex-col items-center">

    <div class="relative">

        <div class="w-24 h-24 rounded-full overflow-hidden bg-slate-200">
            <?php if($profileImage): ?>
                <img src="<?= $profileImage ?>" class="w-full h-full object-cover">
            <?php else: ?>
                <div class="w-full h-full flex items-center justify-center text-slate-400">
                    <svg class="w-10 h-10" fill="none" stroke="currentColor"
                         stroke-width="2" viewBox="0 0 24 24">
                        <path d="M5.121 17.804A9 9 0 1118.88 17.8"/>
                        <circle cx="12" cy="7" r="4"/>
                    </svg>
                </div>
            <?php endif; ?>
        </div>

        <!-- ICON PLUS -->
        <label class="absolute bottom-0 right-0 bg-blue-600 w-7 h-7 rounded-full flex items-center justify-center cursor-pointer border-2 border-white shadow-md">
            <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor"
                 stroke-width="3" viewBox="0 0 24 24">
                <path d="M12 5v14m7-7H5"/>
            </svg>
            <input type="file" name="avatar" class="hidden" accept="image/*">
        </label>

    </div>

</div>

<!-- NAMA -->
<div>
    <label class="text-sm font-semibold text-slate-700">Nama</label>
    <input type="text"
           name="name"
           value="<?= htmlspecialchars($data_user['name']) ?>"
           class="mt-2 w-full bg-white rounded-xl px-4 py-3 text-sm shadow-sm focus:ring-2 focus:ring-blue-500 outline-none">
</div>

<!-- NOMOR HP -->
<div>
    <label class="text-sm font-semibold text-slate-700">Nomor HP</label>
    <input type="text"
           name="contact"
           value="<?= htmlspecialchars($data_user['phone']) ?>"
           class="mt-2 w-full bg-white rounded-xl px-4 py-3 text-sm shadow-sm focus:ring-2 focus:ring-blue-500 outline-none">
</div>

<button type="submit" name="saved"
        class="w-full bg-blue-500 hover:bg-blue-600 text-white py-4 rounded-xl font-semibold transition">
    Simpan Perubahan
</button>

</form>
</section>

<?php include __DIR__ . '/../layout/user/footer.php'; ?>

</div>
</body>
</html>