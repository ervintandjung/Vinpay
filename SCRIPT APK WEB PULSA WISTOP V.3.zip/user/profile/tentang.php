<?php
require __DIR__ . '/../../connect.php';
require __DIR__ . '/../../library/session/user.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($_CONFIG['title'], ENT_QUOTES, 'UTF-8') ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.tailwindcss.com"></script>
    
    <link rel="icon" href="<?= $_CONFIG['icon'] ?>">
    
    <style>
        body { background:#f1f5f9 }
    </style>
</head>
<body class="min-h-screen flex justify-center">

<div class="w-full max-w-md md:max-w-lg lg:max-w-xl bg-slate-100 relative">

<!-- ================= PAGE HEADER ================= -->
<section class="bg-white px-4 py-5 shadow-sm">
    <h1 class="text-lg font-semibold text-slate-800">Tentang Aplikasi</h1>
    <p class="text-xs text-slate-500 mt-1">
        Informasi aplikasi & versi
    </p>
</section>

<!-- ================= APP INFO ================= -->
<section class="px-4 mt-4">
    <div class="bg-white rounded-2xl shadow-sm p-5 text-center">
        <img src="<?= htmlspecialchars($_CONFIG['icon_nav'], ENT_QUOTES, 'UTF-8') ?>"
                 class="h-10 mx-auto mb-4 object-contain"
                 alt="logo">

        <h2 class="text-center text-xs text-slate-400 mt-6 font-normal">
    © <?= date('Y') ?> <?= htmlspecialchars($_CONFIG['title']) ?>
</h2>
        <p class="text-sm text-slate-500 mt-1">
            Solusi pembayaran digital modern
        </p>

        <div class="mt-4 text-xs text-slate-500">
            Versi Aplikasi <span class="font-semibold text-slate-700">1.0.0</span>
        </div>
    </div>
</section>

<!-- ================= DESCRIPTION ================= -->
<section class="px-4 mt-4">
    <div class="bg-white rounded-2xl shadow-sm p-4 space-y-3 text-sm text-slate-600 leading-relaxed">

        <p class="font-semibold text-slate-700">
            <?= htmlspecialchars($_CONFIG['description'], ENT_QUOTES, 'UTF-8') ?>
        </p>

        <p>
            Aplikasi ini dikembangkan dengan fokus pada <b>keamanan</b>,
            <b>kecepatan</b>, dan <b>kemudahan penggunaan</b>, sehingga pengguna
            dapat bertransaksi dengan nyaman kapan saja dan di mana saja.
        </p>

    </div>
</section>

<!-- ================= FEATURE LIST ================= -->
<section class="px-4 mt-4">
    <div class="bg-white rounded-2xl shadow-sm p-4">
        <p class="text-sm font-semibold text-slate-700 mb-3">
            Fitur Utama
        </p>

        <ul class="space-y-2 text-sm text-slate-600">
            <li>• Top up & kelola saldo</li>
            <li>• Pembelian pulsa & paket data</li>
            <li>• Top up game & voucher digital</li>
            <li>• Riwayat transaksi lengkap</li>
            <li>• Keamanan akun berlapis</li>
        </ul>
    </div>
</section>

<!-- ================= FOOTER INFO ================= -->
<section class="px-4 mt-4 pb-28">
    <div class="text-center text-xs text-slate-400 mt-6">
        © <?= date('Y') ?> <?= htmlspecialchars($_CONFIG['title']) ?><br>
        All rights reserved.
    </div>
</section>

<?php include __DIR__ . '/layout/user/footer.php'; ?>

</div>
</body>
</html>