<?php
require __DIR__ . '/../../connect.php';
require __DIR__ . '/../../library/session/user.php';

/* ================= VALIDASI KONEKSI ================= */

if (!isset($call) || !$call) {
    die('Database connection error.');
}

/* ================= LOAD CATEGORY ================= */

$categories = [];
$faqGrouped = [];

$catQuery = mysqli_query($call, "
    SELECT id, title, subtitle, slug
    FROM help_categories
    WHERE status='ON'
    ORDER BY sort_order ASC
");

if ($catQuery) {
    while ($row = mysqli_fetch_assoc($catQuery)) {
        $categories[$row['id']] = $row;
        $faqGrouped[$row['id']] = [];
    }
}

/* ================= LOAD FAQ SEKALIGUS ================= */

if (!empty($categories)) {

    $ids = implode(',', array_map('intval', array_keys($categories)));

    $faqQuery = mysqli_query($call, "
        SELECT category_id, question, answer
        FROM help_faq
        WHERE status='ON'
        AND category_id IN ($ids)
        ORDER BY sort_order ASC
    ");

    if ($faqQuery) {
        while ($faq = mysqli_fetch_assoc($faqQuery)) {
            if (isset($faqGrouped[$faq['category_id']])) {
                $faqGrouped[$faq['category_id']][] = $faq;
            }
        }
    }
}

/* ================= LOAD SETTINGS ================= */

$settings = [
    'support_email' => '',
    'support_whatsapp' => ''
];

$setQuery = mysqli_query($call, "
    SELECT support_email, support_whatsapp
    FROM help_settings
    LIMIT 1
");

if ($setQuery && mysqli_num_rows($setQuery) > 0) {
    $settings = mysqli_fetch_assoc($setQuery);
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Bantuan</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { background:#f1f5f9 }
    </style>
</head>
<body class="min-h-screen flex justify-center">

<div class="w-full max-w-md md:max-w-lg lg:max-w-xl bg-slate-100 relative">

<!-- ================= HEADER ================= -->
<section class="bg-white px-4 py-5 shadow-sm">
    <h1 class="text-lg font-semibold text-slate-800">Bantuan</h1>
    <p class="text-xs text-slate-500 mt-1">
        Pusat bantuan & pertanyaan umum
    </p>
</section>

<!-- ================= QUICK CATEGORY ================= -->
<section class="px-4 mt-4 grid grid-cols-2 gap-3">

<?php if (!empty($categories)): ?>
    <?php foreach ($categories as $cat): ?>
        <a href="#<?= htmlspecialchars($cat['slug']) ?>"
           class="bg-white rounded-2xl p-4 shadow-sm text-center hover:bg-slate-50 transition">
            <p class="text-sm font-semibold">
                <?= htmlspecialchars($cat['title']) ?>
            </p>
            <p class="text-xs text-slate-500 mt-1">
                <?= htmlspecialchars($cat['subtitle']) ?>
            </p>
        </a>
    <?php endforeach; ?>
<?php else: ?>
    <div class="col-span-2 text-center text-sm text-slate-500">
        Belum ada kategori bantuan.
    </div>
<?php endif; ?>

</section>

<!-- ================= FAQ SECTION ================= -->
<section class="px-4 mt-6 space-y-6 pb-28">

<?php foreach ($categories as $cat): ?>

    <?php if (!empty($faqGrouped[$cat['id']])): ?>
    <div id="<?= htmlspecialchars($cat['slug']) ?>"
         class="bg-white rounded-2xl shadow-sm p-4">

        <p class="font-semibold text-slate-700 mb-3">
            <?= htmlspecialchars($cat['title']) ?>
        </p>

        <?php foreach ($faqGrouped[$cat['id']] as $faq): ?>
            <div class="mb-4">
                <p class="text-sm font-semibold text-slate-700">
                    <?= htmlspecialchars($faq['question']) ?>
                </p>
                <p class="text-sm text-slate-600 mt-1">
                    <?= nl2br(htmlspecialchars($faq['answer'])) ?>
                </p>
            </div>
        <?php endforeach; ?>

    </div>
    <?php endif; ?>

<?php endforeach; ?>

<!-- ================= CONTACT SECTION ================= -->
<div class="bg-blue-50 border border-blue-200 rounded-2xl p-4 text-center">
    <p class="text-sm font-semibold text-blue-700">
        Butuh Bantuan Lanjutan?
    </p>
    <p class="text-xs text-blue-600 mt-1">
        Hubungi tim support kami
    </p>

    <div class="mt-3 space-y-2">

        <?php if (!empty($settings['support_email'])): ?>
            <a href="mailto:<?= htmlspecialchars($settings['support_email']) ?>"
               class="block text-sm font-semibold text-blue-600">
                <?= htmlspecialchars($settings['support_email']) ?>
            </a>
        <?php endif; ?>

        <?php if (!empty($settings['support_whatsapp'])): ?>
            <a href="https://wa.me/<?= htmlspecialchars($settings['support_whatsapp']) ?>"
               class="block text-sm font-semibold text-blue-600">
                WhatsApp Support
            </a>
        <?php endif; ?>

    </div>
</div>

</section>

<?php include __DIR__ . '/../layout/user/footer.php'; ?>

</div>
</body>
</html>