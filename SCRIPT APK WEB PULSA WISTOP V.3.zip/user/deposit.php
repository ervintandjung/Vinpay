<?php
require '../connect.php';
require _DIR_('library/session/user');
$q = $call->query("SELECT * FROM method ORDER BY id ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($_CONFIG['title'], ENT_QUOTES, 'UTF-8') ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.tailwindcss.com"></script>
    
    <link rel="icon" href="<?= htmlspecialchars($_CONFIG['icon'], ENT_QUOTES, 'UTF-8') ?>">
    
    <style>
        body { background:#f1f5f9 }
    </style>
</head>
<body class="min-h-screen flex justify-center">

<div class="w-full max-w-md md:max-w-lg lg:max-w-xl bg-slate-100 relative">

<!-- ================= PAGE HEADER ================= -->
<section class="bg-white px-4 py-5 shadow-sm">
    <h1 class="text-lg font-semibold text-slate-800">Deposit</h1>
    <p class="text-xs text-slate-500 mt-1">
        Tambah saldo ke akun Anda
    </p>
</section>

<!-- ================= SALDO INFO ================= -->
<section class="px-4 mt-4">
    <div class="bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl p-4 text-white">
        <p class="text-xs opacity-80">Saldo Saat Ini</p>
        <h2 class="text-2xl font-bold mt-1">Rp <?= currency($data_user['balance']) ?></h2>
    </div>
</section>

<!-- ================= NOMINAL ================= -->
<section class="px-4 mt-5">
    <p class="text-sm font-semibold text-slate-700 mb-2">Pilih Nominal</p>

    <div class="grid grid-cols-3 gap-3">
        <?php
        $nominals = [
            50000,
            100000,
            200000,
            300000,
            500000,
            1000000
        ];
        foreach ($nominals as $n):
        ?>
        <button
            type="button"
            data-value="<?= $n ?>"
            class="nominal-btn bg-white rounded-xl py-3 text-sm font-semibold shadow-sm hover:bg-blue-50 transition">
            Rp <?= number_format($n,0,',','.') ?>
        </button>
        <?php endforeach ?>
    </div>
</section>

<!-- ================= CUSTOM NOMINAL ================= -->
<section class="px-4 mt-5">
    <label class="text-sm font-semibold text-slate-700">
        Nominal Lainnya
    </label>
    <input
        id="customNominal"
        type="number"
        placeholder="Masukkan nominal"
        class="mt-2 w-full bg-white rounded-xl px-4 py-3
               text-sm outline-none shadow-sm focus:ring-2 focus:ring-blue-500">
</section>

<!-- ================= PAYMENT METHOD ================= -->
<section class="px-4 mt-6">
    <p class="text-sm font-semibold text-slate-700 mb-2">
        Metode Pembayaran
    </p>

    <div class="space-y-3">
        <?php while($m = $q->fetch_assoc()): ?>
        <label
            class="bg-white rounded-xl p-4 flex justify-between items-center
                   shadow-sm cursor-pointer hover:bg-slate-50 transition">

            <div>
                <p class="text-sm font-medium text-slate-700">
                    <?= htmlspecialchars($m['nama']) ?>
                </p>

                <p class="text-xs text-slate-500">
                    Minimal: Rp <?= number_format($m['minimal'],0,',','.') ?>
                    • Fee: <?= $m['fee_type'] == '+' ? $m['fee']  : $m['fee'].'%' ?>
                </p>
            </div>

            <input 
                type="radio" 
                name="payment"
                value="<?= $m['id']; ?>"
                class="accent-blue-500">
        </label>
        <?php endwhile; ?>
    </div>
</section>

<!-- ================= SUBMIT ================= -->
<section class="px-4 mt-6 pb-28">
    <button
        id="btnDeposit"
        class="w-full bg-blue-500 hover:bg-blue-600 text-white
               py-4 rounded-xl font-semibold transition">
        Lanjutkan Deposit
    </button>
</section>

<script>
    const buttons = document.querySelectorAll('.nominal-btn');
    const input   = document.getElementById('customNominal');
    
    buttons.forEach(btn=>{
        btn.addEventListener('click', ()=>{
    
            // isi input
            input.value = btn.dataset.value;
    
            // reset warna
            buttons.forEach(b=>b.classList.remove('ring-2','ring-blue-500'));
    
            // highlight terpilih
            btn.classList.add('ring-2','ring-blue-500');
        });
    });
</script>

<script>
document.getElementById('btnDeposit').addEventListener('click', ()=>{

    const nominal = document.getElementById('customNominal').value;
    const method  = document.querySelector('input[name=payment]:checked');

    if(!nominal) return alert('Masukkan nominal');
    if(!method)  return alert('Pilih metode');

    fetch('<?= base_url('library/components/deposit/create') ?>', {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:new URLSearchParams({
            method:method.value,
            nominal:nominal
        })
    })
    .then(r=>r.json())
    .then(r=>{
        console.log(r);

        if(!r.status) return alert(r.msg);

        window.location = '<?= base_url('user/invoice-deposit?') ?>wid=' + r.wid;
    });

});
</script>

<?php include __DIR__ . '/layout/user/footer.php'; ?>

</div>
</body>
</html>