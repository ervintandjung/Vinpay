<?php
require '../connect.php';
require _DIR_('library/session/user');

$userId = (int)$data_user['id'];

/* ================= HANDLE UPLOAD ================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_image'])) {

    $allowed = ['image/jpeg','image/png','image/webp'];

    if (in_array($_FILES['profile_image']['type'], $allowed)) {

        if ($_FILES['profile_image']['size'] <= 2 * 1024 * 1024) {

            $ext = pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION);
            $newName = 'profile_' . $userId . '_' . time() . '.' . $ext;
            $destination = __DIR__ . '/../uploads/profile/' . $newName;

            if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $destination)) {

                $call->query("UPDATE users SET image = '$newName' WHERE id = $userId");

                $_SESSION['user']['image'] = $newName;

                header("Location: ".$_SERVER['REQUEST_URI']);
                exit;
            }
        }
    }
}

/* ================= IMAGE PATH ================= */

$profileImage = !empty($data_user['image']) && file_exists(__DIR__.'/../uploads/profile/'.$data_user['image'])
    ? '/uploads/profile/'.$data_user['image']
    : null;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($_CONFIG['title'], ENT_QUOTES, 'UTF-8') ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.tailwindcss.com"></script>
    
    <link rel="icon" href="<?= htmlspecialchars($_CONFIG['icon'], ENT_QUOTES, 'UTF-8') ?>">
    
    <style>
        body { background:#f1f5f9 }
    </style>
</head>
<body class="min-h-screen flex justify-center">

<div class="w-full max-w-md md:max-w-lg lg:max-w-xl bg-slate-100 relative">

<!-- ================= PROFILE HEADER ================= -->
<section class="bg-white px-4 py-6 shadow-sm">
    <div class="flex items-center gap-4">

        <!-- AVATAR -->
        <div class="relative">

            <form method="POST" enctype="multipart/form-data">
                <input type="file" name="profile_image" id="profileInput"
                       class="hidden"
                       accept="image/jpeg,image/png,image/webp"
                       onchange="this.form.submit()">

                <div onclick="document.getElementById('profileInput').click()"
                     class="w-20 h-20 rounded-full overflow-hidden bg-slate-200 cursor-pointer relative group">

                    <?php if ($profileImage): ?>
                        <img src="<?= $profileImage ?>"
                             class="w-full h-full object-cover">
                    <?php else: ?>
                        <div class="w-full h-full flex items-center justify-center text-slate-400">
                            <!-- Default User SVG -->
                            <svg class="w-10 h-10" fill="none" stroke="currentColor"
                                 stroke-width="2" viewBox="0 0 24 24">
                                <path d="M5.121 17.804A9 9 0 1118.88 17.8"/>
                                <circle cx="12" cy="7" r="4"/>
                            </svg>
                        </div>
                    <?php endif; ?>

                    <!-- PLUS ICON -->
                    <div class="absolute bottom-0 right-0 bg-blue-600 rounded-full w-6 h-6 flex items-center justify-center border-2 border-white shadow-md">
                        <svg class="w-3 h-3 text-white" fill="none" stroke="currentColor"
                             stroke-width="3" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                  d="M12 5v14m7-7H5"/>
                        </svg>
                    </div>

                </div>
            </form>

        </div>

        <div>
            <h1 class="text-lg font-semibold"><?= htmlspecialchars($data_user['name']) ?></h1>
            <p class="text-sm text-slate-500"><?= htmlspecialchars($data_user['phone']) ?></p>
        </div>

    </div>
</section>

<!-- ================= PROFILE MENU ================= -->
<section class="px-4 mt-4 space-y-3 pb-28">

<?php
$menus = [
    ['Akun Saya','/user/profile'],
    ['Bantuan','/user/profile/bantuan.php'],
    ['Tentang Aplikasi','/user/profile/tentang.php'],
];
foreach ($menus as $m):
?>
    <a href="<?= $m[1] ?>"
       class="bg-white rounded-xl p-4 flex justify-between items-center shadow-sm hover:shadow transition">
        <span class="text-sm font-medium text-slate-700"><?= $m[0] ?></span>
        <span class="text-slate-400">›</span>
    </a>
<?php endforeach ?>

    <a href="<?= base_url('auth/logout') ?>"
       class="bg-white rounded-xl p-4 flex justify-center items-center shadow-sm text-red-500 font-semibold hover:bg-red-50 transition">
        Logout
    </a>

</section>

<?php include __DIR__ . '/layout/user/footer.php'; ?>

</div>
</body>
</html>