<?php
require '../connect.php';

if(!isset($_SESSION['user'])) {
    if(isset($_COOKIE['token']) && isset($_COOKIE['ssid'])) {

        $call->query("DELETE FROM users_cookie WHERE DATEDIFF(expired,'$date') < 0");

        $LannUID = preg_replace('/[^\d]+/i','',$_COOKIE['ssid']) + 0;
        $LannKey = $_COOKIE['token'];
        $LannSSO = sha1(sha1(strtotime(date('Y-m-d H:i:s'))));

        $LannUser = $call->query("SELECT * FROM users WHERE id = '$LannUID'")->fetch_assoc();

        if(is_array($LannUser)) {

            $LannCheck = $call->query("SELECT * FROM users_cookie WHERE cookie = '$LannKey' AND username = '".$LannUser['username']."'");

            if($LannCheck->num_rows == 1) {

                if($LannUser['level'] <> 'Admin' && $_CONFIG['mt']['web'] == 'true') {
                    exit(redirect(0,base_url('auth/logout')));
                }

                $_SESSION['sso']  = $LannSSO;
                $_SESSION['user'] = $LannUser;

                $call->query("UPDATE users SET sso = '$LannSSO' WHERE id = ".$LannUser['id']);
                $call->query("UPDATE users_cookie SET active = '$date $time', ua = '$user_agent', ip = '$client_ip' WHERE cookie = '$LannKey'");

                redirect(0,visited());

            } else {
                exit(redirect(0,base_url('auth/logout')));
            }

        } else {
            exit(redirect(0,base_url('auth/logout')));
        }
    }
}

$infoBanner = $call->query("SELECT * FROM info_banner WHERE status='ON' ORDER BY id DESC");

if(!isset($_SESSION['user'])) {
    redirect(0, base_url('auth/login'));
}

require _DIR_('library/session/user');
include __DIR__ . '/layout/user/header.php';


/* ================= ICON HELPER ================= */

function appIcon($type, $class = 'w-6 h-6 text-indigo-600') {

    switch($type) {

        case 'plus':
            return '<svg class="'.$class.'" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
                    </svg>';

        case 'wallet':
            return '<svg class="'.$class.'" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <rect x="2" y="7" width="20" height="14" rx="2"/>
                        <path d="M16 12h2"/>
                    </svg>';

        /* ===== PULSA (SIM CARD) ===== */
        case 'phone':
            return '<svg class="'.$class.'" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <rect x="6" y="3" width="12" height="18" rx="2"/>
                        <path d="M9 7h6M9 11h6M9 15h4"/>
                    </svg>';

        /* ===== INTERNET (SIGNAL) ===== */
        case 'wifi':
            return '<svg class="'.$class.'" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round"
                        d="M2 8a20 20 0 0120 0"/>
                        <path stroke-linecap="round" stroke-linejoin="round"
                        d="M5 12a15 15 0 0114 0"/>
                        <path stroke-linecap="round" stroke-linejoin="round"
                        d="M8 16a10 10 0 018 0"/>
                        <circle cx="12" cy="20" r="1"/>
                    </svg>';

        /* ===== GAME (CONTROLLER DETAIL) ===== */
        case 'game':
            return '<svg class="'.$class.'" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round"
                        d="M6 10h12a4 4 0 014 4v1a3 3 0 01-3 3l-2-1-2 1-2-1-2 1-2-1-2 1-2-1a3 3 0 01-3-3v-1a4 4 0 014-4z"/>
                        <path d="M9 13h2m-1-1v2"/>
                        <circle cx="16.5" cy="13.5" r="1"/>
                        <circle cx="18.5" cy="11.5" r="1"/>
                    </svg>';

        case 'chat':
            return '<svg class="'.$class.'" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path d="M8 10h8M8 14h5"/>
                        <path d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>';

        case 'bolt':
            return '<svg class="'.$class.'" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M13 2L3 14h7v8l10-12h-7z"/>
                    </svg>';

        case 'tv':
            return '<svg class="'.$class.'" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <rect x="2" y="7" width="20" height="15" rx="2"/>
                        <path d="M8 3h8"/>
                    </svg>';

        case 'grid':
            return '<svg class="'.$class.'" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <rect x="3" y="3" width="7" height="7"/>
                        <rect x="14" y="3" width="7" height="7"/>
                        <rect x="3" y="14" width="7" height="7"/>
                        <rect x="14" y="14" width="7" height="7"/>
                    </svg>';
    }
}
?>

<!-- QUICK ACTION -->
<section class="px-4 mt-6">
    <div class="grid grid-cols-4 gap-4 text-center text-xs text-white">
        <?php
        $actions = [
            ['Isi Saldo','/user/deposit','plus'],
            ['Emoney','/order/saldo-emoney','wallet'],
            ['Pulsa','/order/pulsa-reguler','phone'],
            ['Game','/order/voucher-game','game'],
        ];

        foreach ($actions as $a):
        ?>
        <a href="<?= $a[1] ?>"
           class="flex flex-col items-center bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl py-4 shadow-lg active:scale-95 transition hover:shadow-xl">
            <div class="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center mb-2">
                <?= appIcon($a[2], 'w-5 h-5 text-white') ?>
            </div>
            <span class="font-semibold"><?= $a[0] ?></span>
        </a>
        <?php endforeach ?>
    </div>
</section>

<!-- PROMO -->
<section class="px-4 mt-6">
    <div class="bg-gradient-to-r from-indigo-500 to-cyan-500 rounded-3xl shadow-xl p-5 flex justify-between items-center text-white">
        <div>
            <p class="text-sm font-semibold">Kuotamu Habis?</p>
            <p class="text-xs opacity-80">Beli paket data sekarang</p>
        </div>
        <a href="/order/paket-internet" class="bg-white text-indigo-600 px-4 py-2 rounded-full text-xs font-bold shadow-md">
            BELI YUK
        </a>
    </div>
</section>

<!-- MAIN MENU -->
<section class="px-4 mt-5">
    <div class="bg-white rounded-3xl shadow-xl p-5">
        <div class="grid grid-cols-4 gap-6 text-center text-xs">
        <?php
        $menus = [
            ['Pulsa Reguler','/order/pulsa-reguler','phone'],
            ['Pulsa Transfer','/order/pulsa-transfer','phone'],
            ['Paket Internet','/order/paket-internet','wifi'],
            ['Telpon & Sms','/order/paket-telepon','chat'],
            ['Game','/order/voucher-game','game'],
            ['Token PLN','/order/token-pln','bolt'],
            ['e-Money','/order/saldo-emoney','wallet'],
            ['Streaming','/order/streaming-tv','tv'],
            ['Lainnya','/order/paket-lainnya','grid'],
        ];

        foreach ($menus as $m):
        ?>
            <a href="<?= $m[1] ?>" class="flex flex-col items-center group">
                <div class="w-14 h-14 bg-gradient-to-br from-slate-100 to-slate-200 rounded-2xl flex items-center justify-center shadow-md group-hover:scale-105 transition">
                    <?= appIcon($m[2]) ?>
                </div>
                <span class="mt-2 font-semibold text-slate-700"><?= $m[0] ?></span>
            </a>
        <?php endforeach ?>
        </div>
    </div>
</section>

<!-- INFO -->
<section class="px-4 mt-6 space-y-3">
<?php while($ib = $infoBanner->fetch_assoc()): ?>
    <div class="bg-white rounded-2xl p-4 shadow-md text-sm flex items-center gap-3">
        <div class="w-9 h-9 bg-<?= $ib['icon_color'] ?>-100 rounded-xl"></div>
        <?= $ib['title'] ?>
        <b class="text-blue-500"><?= $ib['highlight'] ?></b>
    </div>
<?php endwhile ?>
</section>

<!-- BANNER -->
<section class="px-4 mt-6 pb-28">
    <div class="relative overflow-hidden bg-gradient-to-br from-blue-600 to-cyan-500 rounded-3xl p-7 text-white shadow-2xl">
        <div class="absolute -right-10 -top-10 w-40 h-40 bg-white/10 rounded-full blur-2xl"></div>
        <p class="text-xs font-semibold opacity-80">PROTECTION</p>
        <h2 class="text-3xl font-bold mt-1 leading-tight">
            JAMINAN 100%<br>UANG KEMBALI
        </h2>
        <p class="text-xs mt-2 opacity-80">#AMANdariBADMAN</p>
    </div>
</section>

<?php include __DIR__ . '/layout/user/footer.php'; ?>