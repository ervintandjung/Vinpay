<?php
require '../connect.php';
require _DIR_('library/session/user');

$get_qq = isset($_GET['wid']) ? $_GET['wid'] : '';
$search = $call->query("SELECT * FROM deposit WHERE wid = '$get_qq' AND user = '$sess_username'");
if($search->num_rows == 0) redirect(0, base_url('user/deposit'));
$row = $search->fetch_assoc();

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Invoice Deposit</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { background:#f1f5f9 }
    </style>
</head>
<body class="min-h-screen flex justify-center">

<div class="w-full max-w-md md:max-w-lg lg:max-w-xl bg-slate-100 relative">

<!-- ================= PAGE HEADER ================= -->
<section class="bg-white px-4 py-5 shadow-sm">
    <h1 class="text-lg font-semibold text-slate-800">Invoice Deposit</h1>
    <p class="text-xs text-slate-500 mt-1">
        Detail transaksi deposit saldo
    </p>
</section>

<!-- ================= STATUS ================= -->
<? if($row['status'] == 'paid') { ?>
<section class="px-4 mt-4">
    <div class="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 text-center">
        <p class="text-sm font-semibold text-emerald-600">Deposit Berhasil</p>
        <p class="text-xs text-emerald-500 mt-1">
            Saldo telah berhasil ditambahkan
        </p>
    </div>
</section>
<? } ?>
<!-- ================= INVOICE DETAIL ================= -->
<section class="px-4 mt-4">
    <div class="bg-white rounded-2xl shadow-sm p-4 space-y-3">

        <?php
        // Dummy data (ganti dari backend)
        $invoice = [
            'id'        => $row['wid'],
            'tanggal'   => $row['date'],
            'nominal'   => currency($row['amount']),
            'biaya'     => 'Rp '.currency($row['fee']),
            'total'     => 'Rp '.currency($row['amount'] + $row['fee'] + $row['uniq']),
            'metode'    => $row['method'],
            'status'    => $row['status']
        ];

        $rows = [
            'ID Deposit'     => $invoice['id'],
            'Tanggal'        => $invoice['tanggal'],
            'Metode Bayar'   => $invoice['metode'],
            'Status'         => $invoice['status'],
        ];

        foreach ($rows as $label => $value):
        ?>
        <div class="flex justify-between text-sm">
            <span class="text-slate-500"><?= $label ?></span>
            <span class="font-medium text-slate-700"><?= $value ?></span>
        </div>
        <?php endforeach ?>
        
        <? if($row['status'] == 'unpaid') { ?>
        <div class="flex justify-between text-sm">
            <span class="text-slate-500">Note</span>
            <span class="font-medium"><?= $row['note'] ?></span>
        </div>
        <? } ?>
        
        <hr>

        <div class="flex justify-between text-sm">
            <span class="text-slate-500">Nominal Deposit</span>
            <span class="font-medium"><?= $invoice['nominal'] ?></span>
        </div>

        <div class="flex justify-between text-sm">
            <span class="text-slate-500">Biaya Admin</span>
            <span class="font-medium"><?= $invoice['biaya'] ?></span>
        </div>

        <div class="flex justify-between text-base font-semibold mt-2">
            <span>Total Masuk</span>
            <span class="text-blue-600"><?= $invoice['total'] ?></span>
        </div>
    </div>
</section>

<!-- ================= INFO SALDO ================= -->
<section class="px-4 mt-4">
    <div class="bg-blue-50 border border-blue-200 rounded-2xl p-4 text-center">
        <p class="text-xs text-blue-600">Saldo Anda Sekarang</p>
        <p class="text-xl font-bold text-blue-700 mt-1">
            Rp <?= currency($data_user['balance']) ?>
        </p>
    </div>
</section>

<!-- ================= ACTION ================= -->
<section class="px-4 mt-6 pb-28 space-y-3">
    <a href="/"
       class="block w-full text-center bg-blue-500 hover:bg-blue-600
              text-white py-4 rounded-xl font-semibold transition">
        Kembali ke Beranda
    </a>

    <button
        onclick="window.print()"
        class="block w-full text-center bg-white border
               text-slate-700 py-4 rounded-xl font-semibold
               hover:bg-slate-50 transition">
        Cetak Invoice
    </button>
</section>

<?php include __DIR__ . '/layout/user/footer.php'; ?>

</div>
</body>
</html>
