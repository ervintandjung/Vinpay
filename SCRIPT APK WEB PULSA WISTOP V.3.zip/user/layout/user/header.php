<?php
$rawBalance = preg_replace('/[^0-9]/', '', $data_user['balance']);
$balanceInt = (int) $rawBalance;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($_CONFIG['title'], ENT_QUOTES, 'UTF-8') ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.tailwindcss.com"></script>

    <link rel="icon" href="<?= htmlspecialchars($_CONFIG['icon'], ENT_QUOTES, 'UTF-8') ?>">

    <style>
        body { background:#f1f5f9 }
    </style>
</head>

<body class="min-h-screen flex justify-center">

<div class="w-full max-w-md md:max-w-lg lg:max-w-xl bg-slate-100 relative">

<section id="saldoHeader"
    class="sticky top-0 z-50
           bg-gradient-to-br from-sky-500 via-blue-500 to-indigo-600
           px-5 pt-6 pb-16 rounded-b-[28px]
           transition-all duration-300 overflow-hidden">

    <div class="absolute -top-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-2xl pointer-events-none"></div>

    <div class="relative text-white flex justify-between items-center">

        <div>
            <p class="text-xs opacity-80 mb-1">Saldo</p>

            <div class="flex items-center gap-2">

                <h1 id="saldoText"
                    data-balance="<?= $balanceInt ?>"
                    class="text-3xl font-bold tracking-tight">
                    Rp <?= number_format($balanceInt, 0, ',', '.') ?>
                </h1>

                <!-- Eye Toggle -->
                <button type="button"
                        onclick="toggleSaldo()"
                        class="bg-white/20 hover:bg-white/30 transition
                               w-8 h-8 rounded-full flex items-center justify-center">

                    <svg xmlns="http://www.w3.org/2000/svg"
                         class="w-4 h-4"
                         fill="none"
                         viewBox="0 0 24 24"
                         stroke="currentColor"
                         stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round"
                              d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        <path stroke-linecap="round" stroke-linejoin="round"
                              d="M2.458 12C3.732 7.943 7.523 5 12 5
                                 c4.477 0 8.268 2.943 9.542 7
                                 -1.274 4.057-5.065 7-9.542 7
                                 -4.477 0-8.268-2.943-9.542-7z" />
                    </svg>

                </button>

                <!-- Deposit -->
                <a href="/user/deposit"
                   class="bg-white/20 hover:bg-white/30 transition
                          w-8 h-8 rounded-full flex items-center justify-center">

                    <svg xmlns="http://www.w3.org/2000/svg"
                         class="w-4 h-4"
                         fill="none"
                         viewBox="0 0 24 24"
                         stroke="currentColor"
                         stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round"
                              d="M12 4v16m8-8H4" />
                    </svg>

                </a>

            </div>
        </div>

        <div class="bg-white/20 rounded-xl px-3 py-2 flex items-center justify-center">
            <img src="<?= htmlspecialchars($_CONFIG['icon_nav'], ENT_QUOTES, 'UTF-8') ?>"
                 class="h-6 object-contain"
                 alt="logo">
        </div>

    </div>
</section>

<script>
let saldoHidden = false;

function toggleSaldo() {
    const el = document.getElementById('saldoText');
    const balance = parseInt(el.dataset.balance, 10);

    if (saldoHidden) {
        el.textContent = 'Rp ' + balance.toLocaleString('id-ID');
        saldoHidden = false;
    } else {
        el.textContent = 'Rp ********';
        saldoHidden = true;
    }
}
</script>