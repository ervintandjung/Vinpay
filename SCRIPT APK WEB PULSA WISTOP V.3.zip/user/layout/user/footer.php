<!-- ================= BOTTOM NAV ================= -->
<nav class="fixed bottom-0 left-0 right-0 z-50">

    <!-- background glass -->
    <div class="absolute inset-0 bg-white/90 backdrop-blur-lg border-t"></div>

    <div class="relative max-w-xl mx-auto grid grid-cols-5 text-center text-[11px] py-2 pb-3">

        <!-- HOME -->
        <a href="/" 
           class="flex flex-col items-center gap-1 text-slate-600 hover:text-blue-600 transition duration-200">

            <svg class="w-5 h-5 stroke-current" fill="none" stroke-width="2" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round"
                    d="M3 10.5L12 3l9 7.5M5 9.5V20h14V9.5"/>
            </svg>

            Home
        </a>

        <!-- AKTIVITAS -->
        <a href="/user/aktivitas" 
           class="flex flex-col items-center gap-1 text-slate-600 hover:text-blue-600 transition duration-200">

            <svg class="w-5 h-5 stroke-current" fill="none" stroke-width="2" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round"
                    d="M4 6h16M4 12h10M4 18h7"/>
            </svg>

            Aktivitas
        </a>

        <!-- DEPOSIT (CENTER FLOATING) -->
        <div class="-mt-10 relative">
            <a href="/user/deposit"
               class="group bg-gradient-to-br from-blue-500 to-indigo-600
                      w-16 h-16 mx-auto rounded-full shadow-2xl
                      flex items-center justify-center
                      transition duration-200 hover:scale-110 active:scale-95">

                <svg class="w-7 h-7 text-white transition duration-300 group-hover:rotate-90"
                     fill="none" stroke="currentColor" stroke-width="2"
                     viewBox="0 0 24 24">

                    <path stroke-linecap="round" stroke-linejoin="round"
                          d="M12 8v8m-4-4h8"/>
                </svg>
            </a>

            <span class="block mt-1 font-semibold text-blue-600 text-center">
                Deposit
            </span>
        </div>

        <!-- Berita -->
        <a href="/user/informasi"
           class="flex flex-col items-center gap-1 text-slate-600 hover:text-blue-600 transition duration-200">

            <svg class="w-5 h-5 stroke-current" fill="none" stroke-width="2" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round"
                      d="M4 4h16v16H4z"/>
                <path stroke-linecap="round" stroke-linejoin="round"
                      d="M8 8h8M8 12h8M8 16h5"/>
            </svg>

            Info
        </a>

        <!-- PROFILE -->
        <a href="/user/saya"
           class="flex flex-col items-center gap-1 text-slate-600 hover:text-blue-600 transition duration-200">

            <svg class="w-5 h-5 stroke-current" fill="none" stroke-width="2" viewBox="0 0 24 24">
                <circle cx="12" cy="8" r="4"/>
                <path stroke-linecap="round" stroke-linejoin="round"
                      d="M4 20c2-4 6-6 8-6s6 2 8 6"/>
            </svg>

            Saya
        </a>

    </div>
</nav>

</div> <!-- end container -->

<!-- ================= JS GLOBAL ================= -->
<script>
document.addEventListener("DOMContentLoaded", function () {

    const saldoText = document.getElementById('saldoText');
    const header = document.getElementById('saldoHeader');

    let saldoVisible = true;

    function formatRupiah(number) {
        return 'Rp ' + Number(number).toLocaleString('id-ID');
    }

    window.toggleSaldo = function () {
        const balance = saldoText.dataset.balance;

        saldoVisible = !saldoVisible;

        if (saldoVisible) {
            saldoText.textContent = formatRupiah(balance);
        } else {
            saldoText.textContent = 'Rp ••••••';
        }
    };

    window.addEventListener('scroll', function () {
        if (window.scrollY > 10) {
            header.classList.add(
                'backdrop-blur-md',
                'bg-white/80',
                'shadow'
            );
        } else {
            header.classList.remove(
                'backdrop-blur-md',
                'bg-white/80',
                'shadow'
            );
        }
    });

});
</script>

</body>
</html>