<?php
declare(strict_types=1);

require __DIR__ . '/../connect.php';
require _DIR_('library/session/user');

if (!isset($sess_username)) {
    header("Location: /login");
    exit;
}

/**
 * =============================
 * FILTER HANDLER
 * =============================
 */
$allowedFilters = ['all', 'masuk', 'keluar'];
$filter = $_GET['filter'] ?? 'all';

if (!in_array($filter, $allowedFilters, true)) {
    $filter = 'all';
}

/**
 * =============================
 * BUILD QUERY DINAMIS
 * =============================
 */
$sql = "SELECT id, type, amount, note, date 
        FROM mutation 
        WHERE user = ?";

$params = [$sess_username];
$types  = "s";

if ($filter === 'masuk') {
    $sql .= " AND type = ?";
    $params[] = '+';
    $types .= "s";
} elseif ($filter === 'keluar') {
    $sql .= " AND type = ?";
    $params[] = '-';
    $types .= "s";
}

$sql .= " ORDER BY id DESC LIMIT 10";

$stmt = $call->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

/**
 * Helper untuk active button
 */
function activeBtn(string $current, string $value): string {
    return $current === $value
        ? "bg-blue-500 text-white"
        : "bg-white text-slate-600 shadow-sm";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Aktivitas</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { background:#f1f5f9 }
    </style>
</head>
<body class="min-h-screen flex justify-center">

<div class="w-full max-w-md md:max-w-lg lg:max-w-xl bg-slate-100 relative">

<!-- ================= PAGE HEADER ================= -->
<section class="bg-white px-4 py-5 shadow-sm">
    <h1 class="text-lg font-semibold text-slate-800">Aktivitas</h1>
    <p class="text-xs text-slate-500 mt-1">
        Riwayat transaksi dan aktivitas akun
    </p>
</section>

<!-- ================= FILTER ================= -->
<section class="px-4 mt-4 flex gap-2">

    <a href="?filter=all"
       class="flex-1 text-xs py-2 rounded-full font-semibold text-center <?= activeBtn($filter,'all') ?>">
        Semua
    </a>

    <a href="?filter=masuk"
       class="flex-1 text-xs py-2 rounded-full font-semibold text-center <?= activeBtn($filter,'masuk') ?>">
        Masuk
    </a>

    <a href="?filter=keluar"
       class="flex-1 text-xs py-2 rounded-full font-semibold text-center <?= activeBtn($filter,'keluar') ?>">
        Keluar
    </a>

</section>

<!-- ================= ACTIVITY LIST ================= -->
<section class="px-4 mt-4 space-y-3 pb-28">

<?php if ($result->num_rows > 0): ?>
    <?php while ($a = $result->fetch_assoc()): 
        $isPlus = $a['type'] === '+';

        $color = $isPlus 
            ? 'text-emerald-500' 
            : 'text-rose-500';

        $amount = ($isPlus ? '+ ' : '- ') . 
                  'Rp ' . number_format((int)$a['amount'], 0, ',', '.');

        $note = htmlspecialchars($a['note'], ENT_QUOTES, 'UTF-8');
        $date = htmlspecialchars($a['date'], ENT_QUOTES, 'UTF-8');
    ?>
        <div class="bg-white rounded-xl p-4 shadow-sm flex justify-between items-center">
            <div>
                <p class="text-sm font-medium text-slate-700"><?= $note ?></p>
                <p class="text-xs text-slate-500"><?= $date ?></p>
            </div>
            <span class="text-sm font-semibold <?= $color ?>">
                <?= $amount ?>
            </span>
        </div>
    <?php endwhile; ?>
<?php else: ?>
    <div class="bg-white rounded-xl p-6 text-center text-sm text-slate-500 shadow-sm">
        Tidak ada data untuk filter ini.
    </div>
<?php endif; ?>

</section>

<?php include __DIR__ . '/layout/user/footer.php'; ?>

</div>
</body>
</html>

<?php
$stmt->close();