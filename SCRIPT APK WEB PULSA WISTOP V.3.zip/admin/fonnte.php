<?php
require '../connect.php';
require _DIR_('library/session/admin');
include __DIR__ . '/../layout/adminheader.php';
include __DIR__ . '/../layout/adminnavigasi.php';
?>

<main class="flex-1 p-4 md:p-6 overflow-x-hidden">

    <!-- HEADER -->
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-slate-800">Fonnte</h1>
        <p class="text-sm text-slate-500">Pengaturan WhatsApp Gatewat</p>
    </div>

    <!-- FORM -->
    <div class="bg-white rounded-2xl shadow-sm p-6 max-w-3xl">

        <div class="grid grid-cols-1 gap-4">

            <input id="c1" class="input" placeholder="Token" value="<?= conf('fonnte', 1) ?>">
            
        </div>

        <!-- ACTION -->
        <div class="flex justify-between mt-6">
            <button onclick="resetAll()"
                    class="btn-danger">
                Reset
            </button>

            <button onclick="saveConfig()"
                    class="btn-primary">
                Save
            </button>
        </div>

    </div>

</main>

<!-- NOTIF -->
<div id="notif"
     class="fixed bottom-6 right-6 hidden
            px-5 py-4 rounded-2xl shadow-lg
            text-white font-semibold z-50"></div>

<script>
/* ================= DEFAULT DATA ================= */
const defaultValue = '081342509413';

let config = {
    c1:'<?= conf('fonnte', 1) ?>'
};

const fields = Object.keys(config);

/* ================= INIT ================= */
function load(){
    fields.forEach(f=>{
        document.getElementById(f).value = config[f];
    });
}
load();

/* ================= SAVE ================= */
function saveConfig(){
    let payload = {};
    let changed = false;

    fields.forEach(f=>{
        const el = document.getElementById(f);
        if(!el) return;

        const val = el.value;
        if(val !== config[f]){
            payload[f] = val;
            config[f] = val;
            changed = true;
        }
    });

    if(!changed){
        notify('Tidak ada perubahan','bg-amber-500');
        return;
    }

    const form = new URLSearchParams();
    form.append('data', JSON.stringify(payload));

    fetch('<?= base_url("admin/api/fonnte/save") ?>',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:form.toString()
    })
    .then(r=>r.json())
    .then(j=>{
        console.log(j);

        if(!j.success){
            notify('Gagal menyimpan','bg-rose-500');
            return;
        }

        notify('Konfigurasi disimpan','bg-emerald-500');
    });
}

/* ================= RESET ================= */
function resetAll(){
    fields.forEach(f=>{
        document.getElementById(f).value = defaultValue;
        config[f] = defaultValue;
    });

    notify('Semua field direset','bg-rose-500');
}

/* ================= NOTIF ================= */
function notify(text,color){
    notif.textContent = text;
    notif.className = `fixed bottom-6 right-6 px-5 py-4
                       rounded-2xl shadow-lg text-white font-semibold ${color}`;
    notif.classList.remove('hidden');
    setTimeout(()=>notif.classList.add('hidden'),3000);
}
</script>

<style>
.input{
    width:100%;
    padding:.6rem 1rem;
    border-radius:.75rem;
    border:1px solid #e5e7eb;
    outline:none
}
.input:focus{
    border-color:#3b82f6;
    box-shadow:0 0 0 2px rgba(59,130,246,.15)
}
.btn-primary{
    padding:.6rem 1.5rem;
    background:#3b82f6;
    color:white;
    border-radius:.75rem
}
.btn-danger{
    padding:.6rem 1.5rem;
    background:#ef4444;
    color:white;
    border-radius:.75rem
}
</style>

<?php include __DIR__ . '/../layout/adminfooter.php'; ?>
