<?php
require '../connect.php';
require _DIR_('library/session/admin');
include __DIR__ . '/../layout/adminheader.php';
include __DIR__ . '/../layout/adminnavigasi.php';
?>
<main class="flex-1 p-4 md:p-6 overflow-x-hidden">

    <!-- HEADER -->
    <div class="mb-5">
        <h1 class="text-2xl font-bold text-slate-800">Provider</h1>
        <p class="text-sm text-slate-500">Konfigurasi provider & koneksi API</p>
    </div>

    <!-- SEARCH -->
    <div class="mb-4">
        <input id="search"
               type="text"
               placeholder="Cari provider..."
               class="w-full md:w-80 input">
    </div>

    <!-- TABLE -->
    <div class="bg-white rounded-2xl shadow-sm">
        <div class="relative overflow-x-auto">
            <table class="min-w-[1100px] w-full text-sm">

                <thead class="bg-slate-100 text-slate-600">
                    <tr>
                        <th class="px-4 py-3 text-left">Nama</th>
                        <th class="px-4 py-3 text-left">Code</th>
                        <th class="px-4 py-3 text-left">Saldo</th>
                        <th class="px-4 py-3 text-left">Status</th>
                        <th class="px-4 py-3 text-center">Action</th>
                    </tr>
                </thead>

                <tbody id="providerTable" class="divide-y"></tbody>

            </table>
        </div>
    </div>

    <!-- PAGINATION -->
    <div id="pagination"
         class="flex justify-center items-center gap-1 mt-6 text-sm flex-wrap"></div>

</main>

<!-- MODAL -->
<div id="modal"
     class="fixed inset-0 bg-black/40 backdrop-blur-sm
            hidden items-center justify-center z-50"></div>

<!-- NOTIF -->
<div id="notif"
     class="fixed bottom-6 right-6 hidden
            px-5 py-4 rounded-2xl shadow-lg
            text-white font-semibold z-50"></div>

<script>
/* ================= DOM ================= */
const providerTable = document.getElementById('providerTable');
const pagination    = document.getElementById('pagination');
const search        = document.getElementById('search');
const modal         = document.getElementById('modal');
const notif         = document.getElementById('notif');

/* ================= GLOBAL ================= */
let providers = [];
let filtered  = [];
let page = 1;
const perPage = 6;
let active = null;

/* ================= LOAD DATA ================= */
async function loadProvider(){
    const res  = await fetch("<?= base_url('admin/api/provider/provider_list') ?>");
    const json = await res.json();

    providers = (json.data || []).map(p => ({
        code: p.code,
        nama: p.nama,
        userid: p.userid,
        apikey: p.apikey,
        callback: p.callback,
        saldo: Number(p.saldo || 0),
        status: Boolean(p.status)
    }));

    filtered = [...providers];
    page = 1;
    render();
}

/* ================= RENDER ================= */
function render(){
    const start = (page - 1) * perPage;
    const data  = filtered.slice(start, start + perPage);

    providerTable.innerHTML = data.map(p => `
        <tr class="hover:bg-slate-50">
            <td class="px-4 py-3 font-medium">${p.nama}</td>
            <td class="px-4 py-3">${p.code}</td>
            <td class="px-4 py-3 font-semibold">
                Rp ${p.saldo.toLocaleString()}
            </td>
            <td class="px-4 py-3">
                ${p.status
                    ? '<span class="px-3 py-1 rounded-full text-xs bg-emerald-100 text-emerald-600">Konek</span>'
                    : '<span class="px-3 py-1 rounded-full text-xs bg-rose-100 text-rose-600">Tidak Konek</span>'}
            </td>
            <td class="px-4 py-3">
                <div class="flex justify-center gap-2">
                    <button onclick="edit('${p.code}')" class="icon-btn">
                        ${iconGear()}
                    </button>
                    <button onclick="checkSaldo('${p.code}')" class="icon-btn">
                        ${iconPlane()}
                    </button>
                </div>
            </td>
        </tr>
    `).join('');

    renderPagination();
}

/* ================= PAGINATION ================= */
function renderPagination(){
    const total = Math.ceil(filtered.length / perPage);
    pagination.innerHTML = '';

    const btn = (l,p,a=false)=>`
        <button onclick="page=${p};render()"
            class="px-3 py-1 rounded-lg ${a?'bg-blue-500 text-white':'hover:bg-slate-100'}">
            ${l}
        </button>`;

    if(page > 1) pagination.innerHTML += btn('&lt;', page-1);

    let s = Math.max(1, page-2),
        e = Math.min(total, page+2);

    if(s > 1) pagination.innerHTML += btn(1,1,page===1)+'<span>…</span>';
    for(let i=s;i<=e;i++) pagination.innerHTML += btn(i,i,page===i);
    if(e < total) pagination.innerHTML += '<span>…</span>'+btn(total,total,page===total);

    if(page < total) pagination.innerHTML += btn('&gt;', page+1);
}

/* ================= SEARCH ================= */
if(search){
    search.oninput = e => {
        const q = e.target.value.toLowerCase();
        filtered = providers.filter(p =>
            p.nama.toLowerCase().includes(q) ||
            p.code.toLowerCase().includes(q)
        );
        page = 1;
        render();
    };
}

/* ================= EDIT ================= */
function edit(code){
    active = providers.find(p => p.code === code);
    if(!active) return alert('Provider tidak ditemukan');

    openModal(`
        <div class="bg-white rounded-2xl p-6 w-full max-w-md">
            <h3 class="text-lg font-bold mb-4">Edit Provider</h3>

            <input id="eUser" class="input" placeholder="User ID" value="${active.userid || ''}">
            <input id="eKey" class="input" placeholder="API Key" value="${active.apikey || ''}">

            <div class="relative">
                <input id="eCallback" class="input pr-12"
                       value="${active.callback || '-'}" readonly>
                <button onclick="copyCallback()" class="absolute right-3 top-3 text-slate-500">
                    ${iconCopy()}
                </button>
            </div>

            <div class="flex justify-end gap-2 mt-4">
                <button onclick="closeModal()" class="btn">Batal</button>
                <button onclick="saveProvider()" class="btn-primary">Simpan</button>
            </div>
        </div>
    `);
}

/* ================= SAVE ================= */
function saveProvider(){
    fetch("<?= base_url('admin/api/provider/provider_update') ?>", {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: new URLSearchParams({
            code: active.code,
            userid: eUser.value,
            apikey: eKey.value
        })
    })
    .then(r=>r.json())
    .then(res=>{
        notify(res.message || 'Disimpan', res.status?'bg-emerald-500':'bg-rose-500');
        if(res.status){
            closeModal();
            loadProvider();
        }
    });
}

/* ================= CHECK SALDO (ICON ✈️) ================= */
function checkSaldo(code){
    notify('Cek saldo...', 'bg-blue-500');

    fetch("<?= base_url('admin/api/provider/provider_check') ?>", {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: new URLSearchParams({ code })
    })
    .then(r=>r.json())
    .then(res=>{
        if(res.status){
            const p = providers.find(x => x.code === code);
            if(p){
                p.saldo  = Number(res.saldo);
                p.status = true;
            }
            notify('Saldo diperbarui', 'bg-emerald-500');
            render();
        }else{
            notify(res.message || 'Gagal cek saldo', 'bg-rose-500');
        }
    });
}

/* ================= UTIL ================= */
function openModal(html){
    modal.innerHTML = html;
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}
function closeModal(){
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}
function notify(text,color){
    notif.textContent = text;
    notif.className = `fixed bottom-6 right-6 px-5 py-4
        rounded-2xl shadow-lg text-white font-semibold ${color}`;
    notif.classList.remove('hidden');
    setTimeout(()=>notif.classList.add('hidden'),3000);
}
function copyCallback(){
    navigator.clipboard.writeText(eCallback.value);
    notify('Callback disalin','bg-blue-500');
}

/* ================= ICON ================= */
function iconGear(){return `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M12 15.5a3.5 3.5 0 1 0 0-7"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.7l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.7-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 0 1-4 0v-.2a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.7.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.7 1.6 1.6 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.2a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.7l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.7.3 1.6 1.6 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.2a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.7-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.7 1.6 1.6 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.2a1.6 1.6 0 0 0-1.5 1z"/></svg>`;}
function iconPlane(){return `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M10 14l11-2-11-2V3L3 12l7 9v-7z"/></svg>`;}
function iconCopy(){return `<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>`;}

/* ================= INIT ================= */
loadProvider();
</script>


<style>
.input{width:100%;padding:.5rem 1rem;border-radius:.75rem;border:1px solid #e5e7eb;margin-bottom:.5rem}
.btn{padding:.5rem 1rem;border:1px solid #e5e7eb;border-radius:.75rem}
.btn-primary{padding:.5rem 1rem;background:#3b82f6;color:white;border-radius:.75rem}
.icon-btn svg{color:#475569}
</style>

<?php include __DIR__ . '/../layout/adminfooter.php'; ?>
