<?php
require '../connect.php';
require _DIR_('library/session/admin');
include __DIR__ . '/../layout/adminheader.php';
include __DIR__ . '/../layout/adminnavigasi.php';
?>

<main class="flex-1 p-4 md:p-6 overflow-x-hidden">

    <!-- HEADER -->
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-slate-800">Deposit</h1>
        <p class="text-sm text-slate-500">
            Kelola dan verifikasi deposit pengguna
        </p>
    </div>

    <!-- ================= STAT CARDS ================= -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div class="bg-rose-50 border border-rose-200 rounded-2xl p-5">
            <p class="text-sm text-rose-600">Deposit Error</p>
            <p class="text-3xl font-bold text-rose-600" id="countError"><?= currency($call->query("SELECT id FROM deposit WHERE status = 'cancelled'")->num_rows) ?></p>
        </div>
        <div class="bg-amber-50 border border-amber-200 rounded-2xl p-5">
            <p class="text-sm text-amber-600">Deposit Pending</p>
            <p class="text-3xl font-bold text-amber-600" id="countPending"><?= currency($call->query("SELECT id FROM deposit WHERE status = 'unpaid'")->num_rows) ?></p>
        </div>
        <div class="bg-emerald-50 border border-emerald-200 rounded-2xl p-5">
            <p class="text-sm text-emerald-600">Deposit Sukses</p>
            <p class="text-3xl font-bold text-emerald-600" id="countSuccess"><?= currency($call->query("SELECT id FROM deposit WHERE status = 'paid'")->num_rows) ?></p>
        </div>
    </div>

    <!-- ================= TABLE ================= -->
    <div class="bg-white rounded-2xl shadow-sm">
        <div class="relative overflow-x-auto">
            <table class="min-w-[1200px] w-full text-sm">

                <thead class="bg-slate-100 text-slate-600">
                    <tr>
                        <th class="px-4 py-3 text-left">Tanggal</th>
                        <th class="px-4 py-3 text-left">User</th>
                        <th class="px-4 py-3 text-left">Jumlah</th>
                        <th class="px-4 py-3 text-left">Metode</th>
                        <th class="px-4 py-3 text-left">Status</th>
                        <th class="px-4 py-3 text-center">Action</th>
                    </tr>
                </thead>

                <tbody id="depositTable" class="divide-y"></tbody>

            </table>
        </div>
    </div>

    <!-- PAGINATION -->
    <div id="pagination"
         class="flex justify-center items-center gap-1 mt-6 text-sm flex-wrap"></div>

</main>

<!-- MODAL -->
<div id="modal"
     class="fixed inset-0 bg-black/40 backdrop-blur-sm
            hidden items-center justify-center z-50"></div>

<!-- NOTIF -->
<div id="notif"
     class="fixed bottom-6 right-6 hidden
            px-5 py-4 rounded-2xl shadow-lg
            text-white font-semibold z-50"></div>

<script>
/* ================= LOAD DATA ================= */
let deposits = [];
let filtered = [];
let page = 1;
const perPage = 6;

fetch('<?= base_url('admin/api/deposit/deposit_list') ?>')
.then(res => res.json())
.then(res => {
    deposits = res;
    filtered = [...deposits];
    render();
});


/* ================= RENDER ================= */
function render(){
    const start=(page-1)*perPage;
    const data=filtered.slice(start,start+perPage);

    depositTable.innerHTML=data.map(d=>`
        <tr class="hover:bg-slate-50">
            <td class="px-4 py-3">${d.tanggal}</td>
            <td class="px-4 py-3 font-medium">${d.user}</td>
            <td class="px-4 py-3 font-semibold">
                Rp ${Number(d.jumlah).toLocaleString()}
            </td>
            <td class="px-4 py-3">${d.metode}</td>
            <td class="px-4 py-3">${statusBadge(d.status)}</td>
            <td class="px-4 py-3">
                <div class="flex justify-center gap-2">
                    <button onclick="detail('${d.id}')" class="icon-btn">
                        ${iconEye()}
                    </button>
                    <button onclick="updateStatus('${d.id}')" class="icon-btn">
                        ${iconSend()}
                    </button>
                    <button onclick="hapus('${d.id}')" class="icon-btn text-rose-500">
                        ${iconTrash()}
                    </button>
                </div>
            </td>
        </tr>
    `).join('');

    renderPagination();
    updateCards();
}


/* ================= PAGINATION ================= */
function renderPagination(){
    const total=Math.ceil(filtered.length/perPage);
    pagination.innerHTML='';

    const btn=(label,p,active=false)=>`
        <button onclick="page=${p};render()"
            class="px-3 py-1 rounded-lg
            ${active?'bg-blue-500 text-white':'hover:bg-slate-100'}">
            ${label}
        </button>`;

    if(page>1) pagination.innerHTML+=btn('&lt;',page-1);

    let s=Math.max(1,page-2), e=Math.min(total,page+2);

    if(s>1){
        pagination.innerHTML+=btn(1,1,page===1);
        pagination.innerHTML+='<span class="px-1">…</span>';
    }

    for(let i=s;i<=e;i++){
        pagination.innerHTML+=btn(i,i,page===i);
    }

    if(e<total){
        pagination.innerHTML+='<span class="px-1">…</span>';
        pagination.innerHTML+=btn(total,total,page===total);
    }

    if(page<total) pagination.innerHTML+=btn('&gt;',page+1);
}


/* ================= STATUS ================= */
function statusBadge(s){
    const map={
        Error:'bg-rose-100 text-rose-600',
        Pending:'bg-amber-100 text-amber-600',
        Sukses:'bg-emerald-100 text-emerald-600',
        System:'bg-blue-100 text-blue-600'
    };
    return `<span class="px-3 py-1 rounded-full text-xs ${map[s]}">${s}</span>`;
}

function updateCards(){
    countError.textContent   = deposits.filter(d=>d.status==='Error').length;
    countPending.textContent = deposits.filter(d=>d.status==='Pending').length;
    countSuccess.textContent = deposits.filter(d=>d.status==='Sukses').length;
}


/* ================= ACTION ================= */
function detail(id){
    const d=deposits.find(x=>x.id===id);
    openModal(`
        <div class="bg-white rounded-2xl p-6 w-full max-w-md">
            <h3 class="text-lg font-bold mb-4">Detail Deposit</h3>
            <div class="text-sm space-y-2">
                <p><b>ID:</b> ${d.id}</p>
                <p><b>User:</b> ${d.user}</p>
                <p><b>Jumlah:</b> Rp ${Number(d.jumlah).toLocaleString()}</p>
                <p><b>Metode:</b> ${d.metode}</p>
                <p><b>Status:</b> ${d.status}</p>
                <p><b>Tanggal:</b> ${d.tanggal}</p>
            </div>
            <div class="text-right mt-4">
                <button onclick="closeModal()" class="btn">Tutup</button>
            </div>
        </div>
    `);
}

function updateStatus(id){
    const d=deposits.find(x=>x.id===id);
    
    console.log(id);
    openModal(`
        <div class="bg-white rounded-2xl p-6 w-full max-w-sm">
            <h3 class="text-lg font-bold mb-2">Ubah Status Deposit</h3>
            <p class="text-sm text-slate-500 mb-4">
                ${d.user} • Rp ${Number(d.jumlah).toLocaleString()}
            </p>
            <div class="flex justify-end gap-2">
                <button onclick="closeModal()" class="btn">Batal</button>
                <button onclick="setSuccess('${id}')" class="btn-primary">
                    Set Sukses
                </button>
            </div>
        </div>
    `);
}

function hapus(id){
    openModal(`
        <div class="bg-white rounded-2xl p-6 w-full max-w-sm text-center">
            <h3 class="text-lg font-bold text-rose-600 mb-2">Hapus Deposit</h3>
            <p class="text-sm text-slate-500">Yakin hapus deposit ${id}?</p>
            <div class="flex justify-center gap-2 mt-4">
                <button onclick="closeModal()" class="btn">Batal</button>
                <button onclick="deleteDeposit('${id}')" class="btn-danger">Hapus</button>
            </div>
        </div>
    `);
}

function setSuccess(id){
    fetch('<?= base_url('admin/api/deposit/deposit_status') ?>', {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: new URLSearchParams({ id:id, status:'paid' })
    })
    .then(r=>r.json())
    .then(r=>{
        if(!r.status) return alert(r.msg);

        const d = deposits.find(x=>x.id===id);
        if(d) d.status='Sukses';

        notify('Status deposit diperbarui','bg-blue-500');
        render();
        closeModal();
    });
}

function deleteDeposit(id){
    fetch('<?= base_url('admin/api/deposit/deposit_delete') ?>', {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: new URLSearchParams({ id:id })
    })
    .then(r=>r.json())
    .then(r=>{
        if(!r.status) return alert(r.msg);

        deposits=deposits.filter(d=>d.id!==id);
        filtered=filtered.filter(d=>d.id!==id);

        notify('Deposit dihapus','bg-rose-500');
        render();
        closeModal();
    });
}

/* ================= UTIL ================= */
function openModal(html){
    modal.innerHTML=html;
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}
function closeModal(){
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}
function notify(text,color){
    notif.textContent=text;
    notif.className=`fixed bottom-6 right-6 px-5 py-4
                     rounded-2xl shadow-lg text-white font-semibold ${color}`;
    notif.classList.remove('hidden');
    setTimeout(()=>notif.classList.add('hidden'),3000);
}

/* ================= ICON ================= */
function iconEye(){return `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M1.5 12s4-7 10.5-7 10.5 7 10.5 7-4 7-10.5 7S1.5 12 1.5 12z"/><circle cx="12" cy="12" r="3"/></svg>`;}
function iconSend(){return `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M10 14l11-2-11-2V3L3 12l7 9v-7z"/></svg>`;}
function iconTrash(){return `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M3 6h18"/><path d="M8 6v14"/><path d="M16 6v14"/><path d="M5 6l1 14h12l1-14"/></svg>`;}

render();
</script>

<style>
.btn{padding:.5rem 1rem;border:1px solid #e5e7eb;border-radius:.75rem}
.btn-primary{padding:.5rem 1rem;background:#3b82f6;color:white;border-radius:.75rem}
.btn-danger{padding:.5rem 1rem;background:#ef4444;color:white;border-radius:.75rem}
.icon-btn svg{color:#475569}
</style>

<?php include __DIR__ . '/../layout/adminfooter.php'; ?>
