<?php
require '../connect.php';
require _DIR_('library/session/admin');
include __DIR__ . '/../layout/adminheader.php';
include __DIR__ . '/../layout/adminnavigasi.php';

$q = $call->query("
    SELECT 
        DATE_FORMAT(STR_TO_DATE(date, '%Y-%m-%d %H:%i:%s'), '%b') AS bulan,
        COUNT(id) AS total
    FROM users
    WHERE STR_TO_DATE(date, '%Y-%m-%d %H:%i:%s') >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH)
    GROUP BY YEAR(STR_TO_DATE(date, '%Y-%m-%d %H:%i:%s')),
             MONTH(STR_TO_DATE(date, '%Y-%m-%d %H:%i:%s'))
    ORDER BY YEAR(STR_TO_DATE(date, '%Y-%m-%d %H:%i:%s')),
             MONTH(STR_TO_DATE(date, '%Y-%m-%d %H:%i:%s'))
");

if(!$q){
    die($call->error);
}

$labels = [];
$data   = [];

while ($r = $q->fetch_assoc()) {
    $labels[] = $r['bulan'];
    $data[]   = (int)$r['total'];
}

$qTrans = $call->query("
    SELECT 
        DATE_FORMAT(STR_TO_DATE(date_cr, '%Y-%m-%d %H:%i:%s'), '%b') AS bulan,
        COUNT(id) AS total
    FROM transaction
    WHERE STR_TO_DATE(date_cr, '%Y-%m-%d %H:%i:%s') >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH)
    GROUP BY YEAR(STR_TO_DATE(date_cr, '%Y-%m-%d %H:%i:%s')),
             MONTH(STR_TO_DATE(date_cr, '%Y-%m-%d %H:%i:%s'))
    ORDER BY YEAR(STR_TO_DATE(date_cr, '%Y-%m-%d %H:%i:%s')),
             MONTH(STR_TO_DATE(date_cr, '%Y-%m-%d %H:%i:%s'))
");

if(!$qTrans){
    die($call->error);
}

$labelsTrans = [];
$dataTrans   = [];

while ($r = $qTrans->fetch_assoc()) {
    $labelsTrans[] = $r['bulan'];
    $dataTrans[]   = (int)$r['total'];
}

?>
<main class="flex-1 p-4 md:p-6">

    <!-- ================= PAGE TITLE ================= -->
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-slate-800">
            Dashboard
        </h1>
        <p class="text-sm text-slate-500">
            Ringkasan performa sistem hari ini
        </p>
    </div>

    <!-- ================= STAT CARDS ================= -->
    <section class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">

        <?php
        $stats = [
            ['Total User', currency($call->query("SELECT id FROM users WHERE status = 'active'")->num_rows), 'text-blue-600'],
            ['Hari Ini', currency($call->query("SELECT id FROM users WHERE status = 'active' AND DATE(created_at) = CURDATE()")->num_rows), 'text-emerald-600'],
            ['Mingguan', currency($call->query("SELECT id FROM users WHERE status = 'active' AND YEARWEEK(created_at, 1) = YEARWEEK(CURDATE(), 1)")->num_rows), 'text-indigo-600'],
            ['Total Transaksi', currency($call->query("SELECT id FROM transaction WHERE status = 'success'")->num_rows), 'text-rose-600'],
        ];
        foreach ($stats as $s):
        ?>
        <div class="bg-white rounded-2xl p-5 shadow-sm hover:shadow-md transition">
            <p class="text-xs text-slate-500 mb-1"><?= $s[0] ?></p>
            <p class="text-3xl font-bold <?= $s[2] ?>">
                <?= $s[1] ?>
            </p>
            <div class="mt-2 h-1 rounded-full bg-slate-100">
                <div class="h-1 rounded-full bg-current w-2/3"></div>
            </div>
        </div>
        <?php endforeach ?>

    </section>

    <!-- ================= CHART SECTION ================= -->
    <section class="grid grid-cols-1 xl:grid-cols-2 gap-6">

        <!-- TRANSAKSI -->
        <div class="bg-white rounded-2xl p-6 shadow-sm">
            <div class="flex justify-between items-center mb-4">
                <h2 class="font-semibold text-slate-700">
                    Transaksi Bulanan
                </h2>
                <span class="text-xs text-slate-400">
                    6 bulan terakhir
                </span>
            </div>
            <canvas id="monthlyChart" height="120"></canvas>
        </div>

        <!-- USER -->
        <div class="bg-white rounded-2xl p-6 shadow-sm">
            <div class="flex justify-between items-center mb-4">
                <h2 class="font-semibold text-slate-700">
                    Pertumbuhan User
                </h2>
                <span class="text-xs text-slate-400">
                    Akumulatif
                </span>
            </div>
            <canvas id="userChart" height="120"></canvas>
        </div>

    </section>

    <!-- ================= QUICK INFO ================= -->
    <section class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">

        <div class="bg-gradient-to-br from-blue-500 to-indigo-600
                    rounded-2xl p-5 text-white shadow">
            <p class="text-xs opacity-90">Profit</p>
            <p class="text-lg font-bold mt-1">Rp <?= currency($call->query("SELECT SUM(profit) AS x FROM transaction WHERE status = 'success'")->fetch_assoc()['x']) ?></p>
            <p class="text-xs opacity-80 mt-1">
                Total Profit
            </p>
        </div>

        <div class="bg-white rounded-2xl p-5 shadow-sm">
            <p class="text-xs text-slate-500">Total Deposit</p>
            <p class="text-2xl font-bold text-slate-800 mt-1">Rp <?= currency($call->query("SELECT SUM(amount + uniq) AS x FROM deposit WHERE status = 'paid'")->fetch_assoc()['x']) ?> </p>
            <p class="text-xs text-slate-400 mt-1">
                Total Deposit
            </p>
        </div>

        <div class="bg-white rounded-2xl p-5 shadow-sm">
            <p class="text-xs text-slate-500">Total Transaksi</p>
            <p class="text-2xl font-bold text-slate-800 mt-1">Rp <?= currency($call->query("SELECT SUM(price) AS x FROM transaction WHERE status = 'success'")->fetch_assoc()['x']) ?></p>
            <p class="text-xs text-slate-400 mt-1">
                Jumlah seluruh transaksi
            </p>
        </div>

    </section>

</main>

<!-- ================= CHART JS ================= -->
<script>
new Chart(document.getElementById('monthlyChart'), {
    type: 'bar',
    data: {
        labels: <?= json_encode($labelsTrans); ?>,
        datasets: [{
            data: <?= json_encode($dataTrans); ?>,
            backgroundColor: '#3b82f6',
            borderRadius: 8
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
            y: { grid: { color: '#f1f5f9' } },
            x: { grid: { display: false } }
        }
    }
});

new Chart(document.getElementById('userChart'), {
    type: 'line',
    data: {
        labels: <?= json_encode($labels); ?>,
        datasets: [{
            data: <?= json_encode($data); ?>,
            borderColor: '#6366f1',
            backgroundColor: 'rgba(99,102,241,0.1)',
            fill: true,
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
            y: { grid: { color: '#f1f5f9' } },
            x: { grid: { display: false } }
        }
    }
});
</script>

<?php include __DIR__ . '/../layout/adminfooter.php'; ?>
