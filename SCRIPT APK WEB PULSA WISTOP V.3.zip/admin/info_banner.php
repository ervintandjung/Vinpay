<?php
require '../connect.php';
require _DIR_('library/session/admin');
include __DIR__ . '/../layout/adminheader.php';
include __DIR__ . '/../layout/adminnavigasi.php';

$totalBanner = $call->query("SELECT id FROM info_banner")->num_rows;
?>

<main class="flex-1 p-4 md:p-6 overflow-x-hidden">

    <div class="mb-6">
        <h1 class="text-2xl font-bold text-slate-800">Info Banner</h1>
        <p class="text-sm text-slate-500">Kelola banner informasi halaman utama</p>
    </div>

    <!-- STAT -->
    <div class="bg-sky-50 border border-sky-200 rounded-2xl p-5 w-64 mb-6">
        <p class="text-sm text-sky-600">Total Banner</p>
        <p id="totalBanner" class="text-3xl font-bold text-sky-600"><?= $totalBanner ?></p>
    </div>

    <!-- ACTION -->
    <div class="mb-6">
        <button onclick="openAdd()" class="btn-primary">+ Tambah Banner</button>
    </div>

    <!-- TABLE -->
    <div class="bg-white rounded-2xl shadow-sm">
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-slate-100 text-slate-600">
                    <tr>
                        <th class="px-4 py-3 text-left">Judul</th>
                        <th class="px-4 py-3 text-left">Highlight</th>
                        <th class="px-4 py-3 text-left">Warna</th>
                        <th class="px-4 py-3 text-left">Status</th>
                        <th class="px-4 py-3 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody id="tableData" class="divide-y"></tbody>
            </table>
        </div>
    </div>

</main>

<!-- MODAL -->
<div id="modal" class="fixed inset-0 bg-black/40 hidden items-center justify-center z-50"></div>

<script>
let banners=[];
let editId=null;
let modeEdit=false;

const tableData=document.getElementById('tableData');
const modal=document.getElementById('modal');
const totalBanner=document.getElementById('totalBanner');

const colorMap={
    blue:['bg-blue-100','text-blue-600'],
    emerald:['bg-emerald-100','text-emerald-600'],
    rose:['bg-rose-100','text-rose-600'],
    amber:['bg-amber-100','text-amber-600'],
    violet:['bg-violet-100','text-violet-600'],
    cyan:['bg-cyan-100','text-cyan-600']
};

/* ================= LOAD ================= */
load();

function load(){
    tableData.innerHTML=`<tr><td colspan="5" class="text-center py-6 text-slate-400">Loading...</td></tr>`;
    fetch('api/info_banner/list.php')
    .then(r=>{
        if(!r.ok) throw new Error();
        return r.json();
    })
    .then(r=>{
        banners=r||[];
        render();
        totalBanner.textContent=banners.length;
    })
    .catch(()=>{
        tableData.innerHTML=`<tr><td colspan="5" class="text-center py-6 text-rose-500">Gagal memuat data</td></tr>`;
    });
}

/* ================= RENDER ================= */
function render(){
    if(!banners.length){
        tableData.innerHTML=`<tr><td colspan="5" class="text-center py-6 text-slate-400">Belum ada banner</td></tr>`;
        return;
    }

    tableData.innerHTML=banners.map(b=>{
        const color=colorMap[b.icon_color]||colorMap.blue;
        return `
        <tr class="hover:bg-slate-50">
            <td class="px-4 py-3 font-semibold">${escapeHtml(b.title)}</td>
            <td class="px-4 py-3 text-blue-600 font-semibold">${escapeHtml(b.highlight)}</td>
            <td class="px-4 py-3">
                <span class="px-3 py-1 rounded-full ${color[0]} ${color[1]} text-xs">
                    ${b.icon_color}
                </span>
            </td>
            <td class="px-4 py-3">${badge(b.status)}</td>
            <td class="px-4 py-3 text-center space-x-2">
                <button onclick="edit(${b.id})">✏️</button>
                <button onclick="hapus(${b.id})" class="text-rose-500">🗑️</button>
            </td>
        </tr>`;
    }).join('');
}

function badge(s){
    return `<span class="px-3 py-1 rounded-full text-xs ${
        s=='ON'?'bg-emerald-100 text-emerald-600':'bg-rose-100 text-rose-600'
    }">${s}</span>`;
}

/* ================= FORM ================= */
function form(d={}){
    return `
    <div class="bg-white p-6 rounded-2xl w-full max-w-md">
        <h3 class="text-lg font-bold mb-4">${modeEdit?'Edit':'Tambah'} Banner</h3>
        <div class="space-y-3">
            <input id="title" value="${d.title??''}" placeholder="Judul" class="input">
            <input id="highlight" value="${d.highlight??''}" placeholder="Highlight" class="input">
            <select id="icon_color" class="input">
                ${Object.keys(colorMap).map(c=>
                    `<option value="${c}" ${d.icon_color===c?'selected':''}>${c}</option>`
                ).join('')}
            </select>
            <select id="status" class="input">
                <option value="ON" ${d.status==='ON'?'selected':''}>Aktif</option>
                <option value="OFF" ${d.status==='OFF'?'selected':''}>Nonaktif</option>
            </select>
            <div class="text-right flex gap-2 justify-end pt-2">
                <button onclick="closeModal()" class="btn">Batal</button>
                <button onclick="save()" class="btn-primary">Simpan</button>
            </div>
        </div>
    </div>`;
}

/* ================= CRUD ================= */
function openAdd(){
    modeEdit=false;
    editId=null;
    openModal(form());
}

function edit(id){
    const d=banners.find(x=>x.id==id);
    if(!d) return;
    modeEdit=true;
    editId=id;
    openModal(form(d));
}

function save(){
    const t=document.getElementById('title').value.trim();
    const h=document.getElementById('highlight').value.trim();
    const c=document.getElementById('icon_color').value;
    const s=document.getElementById('status').value;

    if(!t||!h) return alert('Judul & Highlight wajib diisi');

    fetch('api/info_banner/save.php',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:new URLSearchParams({
            id:editId||'',
            title:t,
            highlight:h,
            icon_color:c,
            status:s
        })
    })
    .then(()=>{ closeModal(); load(); });
}

function hapus(id){
    if(!confirm('Hapus banner ini?')) return;
    fetch('api/info_banner/delete.php',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:new URLSearchParams({id})
    })
    .then(()=>load());
}

/* ================= UTIL ================= */
function openModal(html){
    modal.innerHTML=html;
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    modal.onclick=e=>{ if(e.target===modal) closeModal(); };
}
function closeModal(){
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}

function escapeHtml(str){
    return String(str).replace(/[&<>"']/g,m=>({
        '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'
    }[m]));
}
</script>

<style>
.btn{padding:.5rem 1rem;border:1px solid #e5e7eb;border-radius:.75rem}
.btn-primary{padding:.5rem 1rem;background:#0ea5e9;color:white;border-radius:.75rem}
.input{width:100%;border:1px solid #e5e7eb;padding:.6rem .8rem;border-radius:.75rem}
</style>

<?php include __DIR__ . '/../layout/adminfooter.php'; ?>