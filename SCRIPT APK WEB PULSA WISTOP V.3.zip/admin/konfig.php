<?php
require '../connect.php';
require _DIR_('library/session/admin');
include __DIR__ . '/../layout/adminheader.php';
include __DIR__ . '/../layout/adminnavigasi.php';
?>

<main class="flex-1 p-4 md:p-6 overflow-x-hidden">

    <!-- HEADER -->
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-slate-800">Web Configuration</h1>
        <p class="text-sm text-slate-500">Pengaturan umum website</p>
    </div>

    <!-- FORM -->
    <div class="bg-white rounded-2xl shadow-sm p-6 max-w-3xl">

        <div class="grid grid-cols-1 gap-4">

            <input id="c1" class="input" placeholder="Title Web" value="<?= $_CONFIG['title'] ?>">
            <input id="c2" class="input" placeholder="Nav Title" value="<?= $_CONFIG['navbar'] ?>">
            <textarea id="c3" class="input" rows="3" placeholder="Deskripsi Web"><?= $_CONFIG['description'] ?></textarea>
            <input id="c4" class="input" placeholder="Keyword Web" value="<?= $_CONFIG['keyword'] ?>">

            <div>
                <input id="c5" class="input" placeholder="OG Image URL" value="<?= $_CONFIG['banner'] ?>">
                <p class="text-xs text-slate-500 mt-1">
                    Gambar ini akan muncul saat di share di sosial media
                </p>
            </div>

            <input id="c6" class="input" placeholder="Icon Web" value="<?= $_CONFIG['icon'] ?>">
            
            <input id="c7" class="input" placeholder="Icon Navigasi" value="<?= $_CONFIG['icon_nav'] ?>">
            <input id="wa" class="input" placeholder="Whatsapp">
            <input id="ig" class="input" placeholder="Instagram">
            <input id="yt" class="input" placeholder="Youtube">
            <input id="tg" class="input" placeholder="Telegram">
            <input id="x" class="input" placeholder="X (Twitter)">
            <input id="email" class="input" placeholder="Email">

        </div>

        <!-- ACTION -->
        <div class="flex justify-between mt-6">
            <button onclick="resetAll()"
                    class="btn-danger">
                Reset
            </button>

            <button onclick="saveConfig()"
                    class="btn-primary">
                Save
            </button>
        </div>

    </div>

</main>

<!-- NOTIF -->
<div id="notif"
     class="fixed bottom-6 right-6 hidden
            px-5 py-4 rounded-2xl shadow-lg
            text-white font-semibold z-50"></div>

<script>
/* ================= DEFAULT DATA ================= */
const defaultValue = '081342509413';

let config = {
    c1:'<?= $_CONFIG['title'] ?>',
    c2:'<?= $_CONFIG['navbar'] ?>',
    c3:'<?= $_CONFIG['description'] ?>',
    c4:'<?= $_CONFIG['keyword'] ?>',
    c5:'<?= $_CONFIG['banner'] ?>',
    c6:'<?= $_CONFIG['icon'] ?>',
    c7:'<?= $_CONFIG['icon_nav'] ?>',
    wa:'',
    ig:'',
    yt:'',
    tg:'',
    x:'',
    email:''
};

const fields = Object.keys(config);

/* ================= INIT ================= */
function load(){
    fields.forEach(f=>{
        document.getElementById(f).value = config[f];
    });
}
load();

/* ================= SAVE ================= */
function saveConfig(){
    let payload = {};
    let changed = false;

    fields.forEach(f=>{
        const el = document.getElementById(f);
        if(!el) return;

        const val = el.value;
        if(val !== config[f]){
            payload[f] = val;
            config[f] = val;
            changed = true;
        }
    });

    if(!changed){
        notify('Tidak ada perubahan','bg-amber-500');
        return;
    }

    const form = new URLSearchParams();
    form.append('data', JSON.stringify(payload));

    fetch('<?= base_url("admin/api/config/save") ?>',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:form.toString()
    })
    .then(r=>r.json())
    .then(j=>{
        console.log(j);

        if(!j.success){
            notify('Gagal menyimpan','bg-rose-500');
            return;
        }

        notify('Konfigurasi disimpan','bg-emerald-500');
    });
}

/* ================= RESET ================= */
function resetAll(){
    fields.forEach(f=>{
        document.getElementById(f).value = defaultValue;
        config[f] = defaultValue;
    });

    notify('Semua field direset','bg-rose-500');
}

/* ================= NOTIF ================= */
function notify(text,color){
    notif.textContent = text;
    notif.className = `fixed bottom-6 right-6 px-5 py-4
                       rounded-2xl shadow-lg text-white font-semibold ${color}`;
    notif.classList.remove('hidden');
    setTimeout(()=>notif.classList.add('hidden'),3000);
}
</script>

<style>
.input{
    width:100%;
    padding:.6rem 1rem;
    border-radius:.75rem;
    border:1px solid #e5e7eb;
    outline:none
}
.input:focus{
    border-color:#3b82f6;
    box-shadow:0 0 0 2px rgba(59,130,246,.15)
}
.btn-primary{
    padding:.6rem 1.5rem;
    background:#3b82f6;
    color:white;
    border-radius:.75rem
}
.btn-danger{
    padding:.6rem 1.5rem;
    background:#ef4444;
    color:white;
    border-radius:.75rem
}
</style>

<?php include __DIR__ . '/../layout/adminfooter.php'; ?>
