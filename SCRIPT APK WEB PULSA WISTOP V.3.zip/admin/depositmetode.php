<?php
require '../connect.php';
require _DIR_('library/session/admin');
include __DIR__ . '/../layout/adminheader.php';
include __DIR__ . '/../layout/adminnavigasi.php';
?>

<main class="flex-1 p-4 md:p-6 overflow-x-hidden">

    <!-- HEADER -->
    <div class="mb-5">
        <h1 class="text-2xl font-bold text-slate-800">Metode Deposit</h1>
        <p class="text-sm text-slate-500">Kelola metode pembayaran deposit</p>
    </div>

    <!-- ACTION BAR -->
    <div class="flex flex-wrap items-center justify-between gap-3 mb-4">
        <button onclick="openAdd()" class="btn-primary">
            + Tambah Metode
        </button>

        <input id="search"
               type="text"
               placeholder="Cari metode deposit..."
               class="w-full md:w-80 input">
    </div>

    <!-- ================= TABLE ================= -->
    <div class="bg-white rounded-2xl shadow-sm">
        <div class="relative overflow-x-auto">
            <table class="min-w-[1200px] w-full text-sm">

                <thead class="bg-slate-100 text-slate-600">
                    <tr>
                        <th class="px-4 py-3 text-left">Nama</th>
                        <th class="px-4 py-3 text-left">Rate</th>
                        <th class="px-4 py-3 text-left">Fee</th>
                        <th class="px-4 py-3 text-left">Minimal</th>
                        <th class="px-4 py-3 text-left">Deskripsi</th>
                        <th class="px-4 py-3 text-center">Action</th>
                    </tr>
                </thead>

                <tbody id="metodeTable" class="divide-y"></tbody>

            </table>
        </div>
    </div>

    <!-- PAGINATION -->
    <div id="pagination"
         class="flex justify-center items-center gap-1 mt-6 text-sm flex-wrap"></div>

</main>

<!-- MODAL -->
<div id="modal"
     class="fixed inset-0 bg-black/40 backdrop-blur-sm
            hidden items-center justify-center z-50"></div>

<!-- NOTIF -->
<div id="notif"
     class="fixed bottom-6 right-6 hidden
            px-5 py-4 rounded-2xl shadow-lg
            text-white font-semibold z-50"></div>

<script>
/* ================= STATE ================= */
let metode = [];
let filtered = [];
let page = 1;
const perPage = 6;
let active = null;

/* ================= LOAD DATA ================= */
async function loadMetode(){
    try{
        const res = await fetch('<?= base_url('admin/api/method/method_list') ?>');
        metode = await res.json();
        filtered = [...metode];
        page = 1;
        render();
    }catch(e){
        console.error(e);
        notify('Gagal load data','bg-rose-500');
    }
}

/* ================= RENDER ================= */
function render(){
    const start = (page-1) * perPage;
    const data = filtered.slice(start, start + perPage);

    metodeTable.innerHTML = data.map((m,i)=>`
        <tr class="hover:bg-slate-50">
            <td class="px-4 py-3 font-medium">${m.nama}</td>
            <td class="px-4 py-3">${m.rate}</td>
            <td class="px-4 py-3">
                ${m.feeType==='%' ? m.fee+'%' : 'Rp '+Number(m.fee).toLocaleString()}
                <div class="text-xs text-slate-500">${m.inc}</div>
            </td>
            <td class="px-4 py-3 font-semibold">
                Rp ${Number(m.minimal).toLocaleString()}
            </td>
            <td class="px-4 py-3 text-sm">
                ${m.owner}<br>${m.rekening}
            </td>
            <td class="px-4 py-3">
                <div class="flex justify-center gap-2">
                    <button onclick="detail(${i})" class="icon-btn">${iconEye()}</button>
                    <button onclick="edit(${i})" class="icon-btn">${iconGear()}</button>
                    <button onclick="hapus(${i})" class="icon-btn text-rose-500">${iconTrash()}</button>
                </div>
            </td>
        </tr>
    `).join('');

    renderPagination();
}

/* ================= PAGINATION ================= */
function renderPagination(){
    const total = Math.ceil(filtered.length / perPage);
    pagination.innerHTML = '';

    const btn = (l,p,a=false)=>`
        <button onclick="page=${p};render()"
            class="px-3 py-1 rounded-lg ${a?'bg-blue-500 text-white':'hover:bg-slate-100'}">
            ${l}
        </button>`;

    if(page>1) pagination.innerHTML += btn('&lt;', page-1);

    let s = Math.max(1, page-2),
        e = Math.min(total, page+2);

    if(s>1) pagination.innerHTML += btn(1,1,page===1)+'<span>…</span>';
    for(let i=s;i<=e;i++) pagination.innerHTML += btn(i,i,page===i);
    if(e<total) pagination.innerHTML += '<span>…</span>'+btn(total,total,page===total);

    if(page<total) pagination.innerHTML += btn('&gt;', page+1);
}

/* ================= SEARCH ================= */
search.oninput = e => {
    const q = e.target.value.toLowerCase();
    filtered = metode.filter(m =>
        m.nama.toLowerCase().includes(q)
    );
    page = 1;
    render();
};

/* ================= ACTION ================= */
function openAdd(){
    openModal(formModal('Tambah Metode', {}, true));
}

function edit(i){
    active = filtered[(page-1)*perPage + i];
    openModal(formModal('Edit Metode', active, false));
}

function detail(i){
    const m = filtered[(page-1)*perPage + i];
    openModal(`
    <div class="bg-white rounded-2xl p-6 w-full max-w-md">
        <h3 class="text-lg font-bold mb-4">Detail Metode</h3>
        <div class="text-sm space-y-2">
            <p><b>Nama:</b> ${m.nama}</p>
            <p><b>Provider:</b> ${m.provider}</p>
            <p><b>Owner:</b> ${m.owner}</p>
            <p><b>Rekening:</b> ${m.rekening}</p>
            <p><b>Fee:</b> ${m.feeType==='%'?m.fee+'%':'Rp '+m.fee}</p>
            <p><b>Ditanggung:</b> ${m.inc}</p>
            <p><b>Minimal:</b> Rp ${Number(m.minimal).toLocaleString()}</p>
        </div>
        <div class="text-right mt-4">
            <button onclick="closeModal()" class="btn">Tutup</button>
        </div>
    </div>`);
}

let deleteId = null;

function hapus(i){
    const item = filtered[(page-1)*perPage + i];
    deleteId = item.id;

    openModal(`
    <div class="bg-white rounded-2xl p-6 w-full max-w-sm text-center">
        <h3 class="text-lg font-bold text-rose-600 mb-2">Hapus Metode</h3>
        <p class="text-sm text-slate-500">Yakin hapus metode ini?</p>
        <div class="flex justify-center gap-2 mt-4">
            <button type="button" onclick="closeModal()" class="btn">Batal</button>
            <button type="button" onclick="confirmDelete()" class="btn-danger">Hapus</button>
        </div>
    </div>`);
}

function confirmDelete(){
    console.log('CONFIRM DELETE CLICKED', deleteId);

    if(!deleteId){
        alert('ID kosong');
        return;
    }

    fetch('<?= base_url('admin/api/method/method_delete') ?>', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ id: deleteId })
    })
    .then(r => r.json())
    .then(res => {
        console.log(res);
        if(res.status){
            loadMetode();
            notify('Metode dihapus','bg-rose-500');
            closeModal();
        }else{
            notify(res.message || 'Gagal hapus','bg-rose-500');
        }
    })
    .catch(err => {
        console.error(err);
        notify('Error server','bg-rose-500');
    });
}

/* ================= FORM MODAL ================= */
function formModal(title, data = {}, isAdd = true){
    return `
    <div class="bg-white rounded-2xl p-6 w-full max-w-md">
        <h3 class="text-lg font-bold mb-4">${title}</h3>

        <select id="fProvider" class="input">
            <option value="X" ${data.provider==='X'?'selected':''}>Manual</option>
            <option value="PST" ${data.provider==='PST'?'selected':''}>Pusat PPOB</option>
        </select>

        <input id="fNama" class="input" placeholder="Nama Bank" value="${data.nama||''}">
        <input id="fOwner" class="input" placeholder="Owner" value="${data.owner||''}">
        <input id="fRek" class="input" placeholder="Nomor Rekening" value="${data.rekening||''}">

        <select id="fFeeType" class="input" onchange="feeTypeChange()">
            <option value="%" ${data.feeType==='%'?'selected':''}>Persentase (%)</option>
            <option value="+" ${data.feeType==='+'?'selected':''}>Nominal (+)</option>
        </select>
        
        <input id="fFee" type="number" step="0.01" min="0" class="input" placeholder="Fee" value="${data.fee||''}">

        <select id="finc" class="input">
            <option value="Pelanggan" ${data.inc==='Pelanggan'?'selected':''}>Pelanggan</option>
            <option value="Store" ${data.inc==='Store'?'selected':''}>Store</option>
        </select>

        <input id="fMin" type="number" class="input" placeholder="Minimal Deposit" value="${data.minimal||''}">

        <div class="flex justify-end gap-2 mt-4">
            <button type="button" onclick="closeModal()" class="btn">Batal</button>
            <button type="button" onclick="submitMetode(${isAdd ? 'null' : data.id})"
                    class="btn-primary">
                Simpan
            </button>
        </div>
    </div>`;
}

function submitMetode(id){
    const payload = {
        id: id,
        nama: fNama.value,
        owner: fOwner.value,
        provider: fProvider.value,
        feeType: fFeeType.value,
        fee: fFee.value,
        inc: finc.value,
        minimal: +fMin.value,
        rekening: fRek.value
    };

    // VALIDASI SEDERHANA
    if(!payload.nama || !payload.rekening){
        notify('Nama & Rekening wajib diisi','bg-rose-500');
        return;
    }

    fetch('<?= base_url('admin/api/method/method_edit') ?>', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify(payload)
    })
    .then(r => r.json())
    .then(res => {
        if(res.status){
            loadMetode();
            notify('Data disimpan','bg-emerald-500');
            closeModal();
        }else{
            notify(res.message || 'Gagal simpan','bg-rose-500');
        }
    })
    .catch(err => {
        console.error(err);
        notify('Error server','bg-rose-500');
    });
}

function feeTypeChange(){
    if (fFeeType.value === '%') {
        fFee.step = '0.01';   // boleh desimal
        fFee.max  = '100';
    } else {
        fFee.step = '1';      // wajib bulat
        fFee.max  = '';
    }
}

/* ================= UTIL ================= */
function openModal(html){
    modal.innerHTML=html;
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}
function closeModal(){
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}
function notify(text,color){
    notif.textContent=text;
    notif.className=`fixed bottom-6 right-6 px-5 py-4
                     rounded-2xl shadow-lg text-white font-semibold ${color}`;
    notif.classList.remove('hidden');
    setTimeout(()=>notif.classList.add('hidden'),3000);
}

/* ================= ICON ================= */
function iconEye(){return `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M1.5 12s4-7 10.5-7 10.5 7 10.5 7-4 7-10.5 7S1.5 12 1.5 12z"/><circle cx="12" cy="12" r="3"/></svg>`;}
function iconGear(){return `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M12 15.5a3.5 3.5 0 1 0 0-7"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.7l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.7-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 0 1-4 0v-.2a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.7.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.7 1.6 1.6 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.2a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.7l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.7.3 1.6 1.6 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.2a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.7-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.7 1.6 1.6 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.2a1.6 1.6 0 0 0-1.5 1z"/></svg>`;}
function iconTrash(){return `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M3 6h18"/><path d="M8 6v14"/><path d="M16 6v14"/><path d="M5 6l1 14h12l1-14"/></svg>`;}

loadMetode();
</script>

<style>
.input{width:100%;padding:.5rem 1rem;border-radius:.75rem;border:1px solid #e5e7eb;margin-bottom:.5rem}
.btn{padding:.5rem 1rem;border:1px solid #e5e7eb;border-radius:.75rem}
.btn-primary{padding:.5rem 1rem;background:#3b82f6;color:white;border-radius:.75rem}
.btn-danger{padding:.5rem 1rem;background:#ef4444;color:white;border-radius:.75rem}
.icon-btn svg{color:#475569}
</style>

<?php include __DIR__ . '/../layout/adminfooter.php'; ?>
