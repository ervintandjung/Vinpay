<?php
header("Content-Type: application/json");
require '../../../connect.php';
require _DIR_('library/session/admin');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["success"=>false,"error"=>"METHOD INVALID"]);
    exit;
}

if (empty($_POST['data'])) {
    echo json_encode(["success"=>false,"error"=>"DATA KOSONG"]);
    exit;
}

$data = json_decode($_POST['data'], true);
if (!is_array($data)) {
    echo json_encode(["success"=>false,"error"=>"FORMAT DATA SALAH"]);
    exit;
}

$allowed = [
    'c1'
];

$set = [];
foreach ($data as $k => $v) {
    if (!in_array($k, $allowed)) continue;
    $val = $call->real_escape_string($v);
    $set[] = "$k='$val'";
}

if (empty($set)) {
    echo json_encode(["success"=>false,"error"=>"TIDAK ADA DATA VALID"]);
    exit;
}

// ⚠️ pastikan hanya 1 row config (code = fonnte)
$sql = "
    UPDATE conf
    SET ".implode(',', $set)."
    WHERE code='fonnte'
    LIMIT 1
";

$call->query($sql);

echo json_encode([
    "success"=>true,
    "affected"=>$call->affected_rows
]);