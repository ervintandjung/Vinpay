<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

require '../../../connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

$method = $_SERVER['REQUEST_METHOD'];

// METHOD SPOOFING (FORM DATA)
if ($method === 'POST' && isset($_POST['_method'])) {
    $method = strtoupper($_POST['_method']);
}

/* ================= GET ================= */
if ($method === "GET") {
    $res = $call->query("SELECT * FROM services ORDER BY id DESC");
    $data = [];
    while ($row = $res->fetch_assoc()) {
        $data[] = $row;
    }
    echo json_encode($data);
    exit;
}

/* ================= ADD ================= */
if ($method === "POST") {

    if (
        empty($_POST['code']) ||
        empty($_POST['nama']) ||
        empty($_POST['kategory']) ||
        !isset($_POST['modal']) ||
        empty($_POST['provider'])
    ) {
        echo json_encode(["success"=>false,"error"=>"DATA ADD TIDAK LENGKAP"]);
        exit;
    }

    $code = trim($_POST['code']);

    // VALIDASI CODE
    if (!preg_match('/^[A-Z0-9_-]+$/i', $code)) {
        echo json_encode(["success"=>false,"error"=>"FORMAT CODE TIDAK VALID"]);
        exit;
    }

    // CEK DUPLIKAT CODE
    $cek = $call->query("SELECT id FROM services WHERE code='$code' LIMIT 1");
    if ($cek->num_rows > 0) {
        echo json_encode(["success"=>false,"error"=>"CODE SUDAH DIGUNAKAN"]);
        exit;
    }

    $type     = $call->real_escape_string($_POST['kategory']);
    $code     = $call->real_escape_string($code);
    $name     = $call->real_escape_string($_POST['nama']);
    $brand    = $call->real_escape_string($_POST['brand']);
    $basic    = (int)$_POST['modal'];
    $profit   = isset($_POST['profit']) ? (int)$_POST['profit'] : 0;
    $price    = $basic + $profit;
    $provider = $call->real_escape_string($_POST['provider']);

    if ($basic <= 0) {
        echo json_encode(["success"=>false,"error"=>"MODAL TIDAK VALID"]);
        exit;
    }

    $call->query("
        INSERT INTO services (type, code, name, varian, note, price, basic, brand, status, provider, date_up)
        VALUES ('$type', '$code', '$name', 'Umum', '-', $basic, $profit, '$brand', 'available', '$provider', NOW())
    ");

    echo json_encode(["success"=>true]);
    exit;
}

/* ================= EDIT ================= */
if ($method === "PUT") {

    if (empty($_POST['id']) || empty($_POST['code'])) {
        echo json_encode(["success"=>false,"error"=>"ID / CODE KOSONG"]);
        exit;
    }

    $id   = (int)$_POST['id'];
    $code = $call->real_escape_string($_POST['code']);

    // ambil data lama
    $res = $call->query("
        SELECT name, basic, price provider
        FROM services
        WHERE id=$id AND code='$code'
        LIMIT 1
    ");

    if ($res->num_rows === 0) {
        echo json_encode(["success"=>false,"error"=>"DATA TIDAK DITEMUKAN"]);
        exit;
    }

    $old = $res->fetch_assoc();

    $name = trim($_POST['nama']) !== ''
        ? $call->real_escape_string($_POST['nama'])
        : $old['name'];

    $basic = (isset($_POST['profit']) && is_numeric($_POST['profit']))
        ? (int)$_POST['profit']
        : (int)$old['basic'];

    $provider = trim($_POST['provider']) !== ''
        ? $call->real_escape_string($_POST['provider'])
        : $old['provider'];

    //$profit = (int)$old['price'] - (int)$old['basic'];
    //$price  = $old['price'] + $basic;

    $call->query("
        UPDATE services SET
            name='$name',
            basic=$basic,
            provider='$provider'
        WHERE id=$id AND code='$code'
        LIMIT 1
    ");

    echo json_encode(["success"=>true,"affected"=>$call->affected_rows]);
    exit;
}

/* ================= DELETE ================= */
if ($method === "DELETE") {

    if (empty($_POST['code'])) {
        echo json_encode(["success"=>false,"error"=>"CODE KOSONG"]);
        exit;
    }

    $code = $call->real_escape_string($_POST['code']);

    // pastikan data ada
    $res = $call->query("SELECT id FROM services WHERE code='$code' LIMIT 1");
    if ($res->num_rows === 0) {
        echo json_encode(["success"=>false,"error"=>"DATA TIDAK DITEMUKAN"]);
        exit;
    }

    $call->query("DELETE FROM services WHERE code='$code' LIMIT 1");

    echo json_encode([
        "success"=>true,
        "affected"=>$call->affected_rows
    ]);
    exit;
}