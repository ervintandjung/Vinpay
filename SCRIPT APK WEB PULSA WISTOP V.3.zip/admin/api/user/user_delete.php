<?php
require '../../../connect.php';
require _DIR_('library/session/admin');

$id = intval($_POST['id']);
$call->query("DELETE FROM users WHERE id=$id");

echo json_encode(["success"=>true]);
