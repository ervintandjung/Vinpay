<?php
require '../../../connect.php';
require _DIR_('library/session/admin');

$page   = max(1, intval($_GET['page'] ?? 1));
$limit  = 8;
$offset = ($page - 1) * $limit;
$search = $_GET['q'] ?? '';

$where = '';
if ($search) {
    $s = $call->real_escape_string($search);
    $where = "WHERE username LIKE '%$s%' 
              OR name LIKE '%$s%' 
              OR email LIKE '%$s%'";
}

$total = $call->query("SELECT COUNT(*) c FROM users $where")
               ->fetch_assoc()['c'];

$data = [];
$q = $call->query("
    SELECT id, username, name, email, phone, balance, level
    FROM users
    $where
    ORDER BY id DESC
    LIMIT $limit OFFSET $offset
");

while ($row = $q->fetch_assoc()) {
    $data[] = [
        "id"       => $row['id'],
        "username" => $row['username'],
        "nama"     => $row['name'],
        "email"    => $row['email'],
        "wa"       => $row['phone'],
        "saldo"    => (int)$row['balance'],
        "role"     => $row['level']
    ];
}

echo json_encode([
    "data"  => $data,
    "total" => $total
]);
