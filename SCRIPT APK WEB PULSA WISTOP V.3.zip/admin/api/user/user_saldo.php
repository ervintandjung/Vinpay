<?php
require '../../../connect.php';
require _DIR_('library/session/admin');

$id = intval($_POST['id']);
$saldo = intval($_POST['saldo']);

$call->query("UPDATE users SET balance=$saldo WHERE id=$id");
echo json_encode(["success"=>true]);
