<?php
require '../../../connect.php';
require _DIR_('library/session/admin');

header('Content-Type: application/json');

/* ================= AMBIL & SANITASI ================= */
$id    = trim($_POST['id'] ?? '');
$name  = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$level = trim($_POST['level'] ?? '');

/* ================= VALIDASI WAJIB ================= */
if ($id === '' || $name === '' || $email === '' || $phone === '' || $level === '') {
    echo json_encode([
        'status'  => false,
        'message' => 'Semua field wajib diisi'
    ]);
    exit;
}

if (!ctype_digit($id)) {
    echo json_encode([
        'status'  => false,
        'message' => 'ID tidak valid'
    ]);
    exit;
}

/* ================= VALIDASI FORMAT ================= */
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode([
        'status'  => false,
        'message' => 'Format email tidak valid'
    ]);
    exit;
}

if (!preg_match('/^[0-9]{8,15}$/', $phone)) {
    echo json_encode([
        'status'  => false,
        'message' => 'Nomor HP tidak valid'
    ]);
    exit;
}

/* ================= VALIDASI LEVEL ================= */
$allowedLevel = ['Admin', 'Basic'];
if (!in_array($level, $allowedLevel, true)) {
    echo json_encode([
        'status'  => false,
        'message' => 'Level user tidak valid'
    ]);
    exit;
}

/* ================= CEK USER ADA ================= */
$checkUser = $call->prepare("
    SELECT name, email, phone, level 
    FROM users WHERE id=? LIMIT 1
");
$checkUser->bind_param("i", $id);
$checkUser->execute();
$result = $checkUser->get_result();

if ($result->num_rows === 0) {
    echo json_encode([
        'status'  => false,
        'message' => 'User tidak ditemukan'
    ]);
    exit;
}

$current = $result->fetch_assoc();

/* ================= CEK DUPLIKAT EMAIL ================= */
$checkEmail = $call->prepare("
    SELECT id FROM users 
    WHERE email=? AND id!=? 
    LIMIT 1
");
$checkEmail->bind_param("si", $email, $id);
$checkEmail->execute();
$checkEmail->store_result();

if ($checkEmail->num_rows > 0) {
    echo json_encode([
        'status'  => false,
        'message' => 'Email sudah digunakan user lain'
    ]);
    exit;
}

/* ================= CEK TIDAK ADA PERUBAHAN ================= */
if (
    $current['name']  === $name &&
    $current['email'] === $email &&
    $current['phone'] === $phone &&
    $current['level'] === $level
) {
    echo json_encode([
        'status'  => false,
        'message' => 'Tidak ada perubahan data'
    ]);
    exit;
}

/* ================= UPDATE DATA ================= */
$stmt = $call->prepare("
    UPDATE users
    SET name=?, email=?, phone=?, level=?
    WHERE id=?
");
$stmt->bind_param("ssssi", $name, $email, $phone, $level, $id);

if ($stmt->execute()) {
    echo json_encode([
        'status'  => true,
        'message' => 'Data user berhasil diperbarui'
    ]);
} else {
    echo json_encode([
        'status'  => false,
        'message' => 'Gagal memperbarui user'
    ]);
}
