<?php
header('Content-type: application/json');
require '../../../connect.php';

$id = $_POST['id'];

$call->query("DELETE FROM deposit WHERE wid='$id'");

echo json_encode(['status'=>true]);
