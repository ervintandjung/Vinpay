<?php
header('Content-Type: application/json');
require '../../../connect.php';

$q = $call->query("SELECT * FROM deposit ORDER BY id DESC");

$data = [];

while($r = $q->fetch_assoc()){

    $map = [
        'cancelled' => 'Error',
        'unpaid'   => 'Pending',
        'paid'     => 'Sukses'
    ];

    $data[] = [
        'id'      => $r['wid'], // atau id
        'tanggal' => $r['date'],
        'user'    => $r['user'],
        'jumlah'  => (int)$r['amount'] + $r['fee'] + $r['uniq'],
        'metode'  => $r['method'],
        'status'  => $map[$r['status']] ?? 'System'
    ];
}

echo json_encode($data);
