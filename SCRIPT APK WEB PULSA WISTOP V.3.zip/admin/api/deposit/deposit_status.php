<?php
header('Content-type: application/json');
require '../../../connect.php';

$id = $_POST['id'];       // wid
$status = $_POST['status'];

// ambil data deposit
$search = $call->query("SELECT * FROM deposit WHERE wid = '$id'");
if($search->num_rows == 0){
    echo json_encode(['status'=>false,'msg'=>'Deposit tidak ditemukan']);
    exit;
}

$d = $search->fetch_assoc();

// kalau sudah paid, jangan tambah saldo lagi
if($d['status'] == 'paid'){
    echo json_encode(['status'=>false,'msg'=>'Sudah pernah diproses']);
    exit;
}

// update status deposit
$update = $call->query("UPDATE deposit SET status='$status' WHERE wid='$id' AND status = 'unpaid'");

if(!$update){
    echo json_encode(['status'=>false,'msg'=>'Gagal update']);
    exit;
}


// kalau status jadi paid → tambah saldo
if($status == 'paid'){

    $user   = $d['user'];
    $amount = $d['amount'] + $d['uniq']; // atau jumlah kalau nama kolommu begitu

    $call->query("UPDATE users SET balance = balance + '$amount' WHERE username='$user'");
    $call->query("INSERT INTO mutation VALUES (null, '$user', '+', '$amount', 'Deposit :: {$id}', '$dtme')");
}

echo json_encode(['status'=>true]);
