<?php
require '../../../connect.php';
require _DIR_('library/session/admin');

header('Content-Type: application/json');

$q = $call->query("
    SELECT code, name, userid, apikey, link, balance
    FROM provider
    ORDER BY name ASC
");

$data = [];
while ($row = $q->fetch_assoc()) {
    $data[] = [
        'code'     => $row['code'],
        'nama'     => $row['name'],
        'userid'   => $row['userid'],
        'apikey'   => $row['apikey'],
        'callback' => $row['link'],
        'saldo'    => (int)$row['balance'],
        'status'   => ($row['userid'] && $row['apikey'])
    ];
}

echo json_encode(['data' => $data]);
