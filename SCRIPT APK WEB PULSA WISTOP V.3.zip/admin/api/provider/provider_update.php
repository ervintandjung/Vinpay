<?php
require '../../../connect.php';
require _DIR_('library/session/admin');

header('Content-Type: application/json');

$code   = trim($_POST['code'] ?? '');
$userid = trim($_POST['userid'] ?? '');
$apikey = trim($_POST['apikey'] ?? '');

if ($code === '') {
    echo json_encode(['status'=>false,'message'=>'Kode provider tidak valid']);
    exit;
}

/* cek provider */
$check = $call->prepare("
    SELECT userid, apikey FROM provider WHERE code=? LIMIT 1
");
$check->bind_param("s", $code);
$check->execute();
$res = $check->get_result();

if ($res->num_rows === 0) {
    echo json_encode(['status'=>false,'message'=>'Provider tidak ditemukan']);
    exit;
}

$current = $res->fetch_assoc();

/* tidak ada perubahan */
if ($current['userid'] === $userid && $current['apikey'] === $apikey) {
    echo json_encode(['status'=>false,'message'=>'Tidak ada perubahan data']);
    exit;
}

/* update */
$stmt = $call->prepare("
    UPDATE provider
    SET userid=?, apikey=?
    WHERE code=?
");
$stmt->bind_param("sss", $userid, $apikey, $code);
$stmt->execute();

echo json_encode([
    'status'  => true,
    'message' => 'Provider berhasil diperbarui'
]);
