<?php
header('Content-Type: application/json');

require '../../../connect.php';
require _DIR_('library/session/admin');

/* ================= VALIDASI METHOD ================= */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'status'  => false,
        'message' => 'Invalid request'
    ]);
    exit;
}

/* ================= VALIDASI INPUT ================= */
$code = isset($_POST['code']) ? trim($_POST['code']) : '';

if ($code === '') {
    echo json_encode([
        'status'  => false,
        'message' => 'Provider code tidak valid'
    ]);
    exit;
}

/* ================= AMBIL PROVIDER ================= */
$stmt = $call->prepare("SELECT * FROM provider WHERE code = ? LIMIT 1");
$stmt->bind_param("s", $code);
$stmt->execute();
$provider = $stmt->get_result()->fetch_assoc();

if (!$provider) {
    echo json_encode([
        'status'  => false,
        'message' => 'Provider tidak ditemukan'
    ]);
    exit;
}

/* ================= CHECK PROVIDER ================= */
try {

    /* === PUSAT PPOB === */
    if ($provider['code'] === 'PST') {

        $result = $PUSATPPOB->checkProfile();

        if (
            !isset($result['result']) ||
            $result['result'] !== true ||
            !isset($result['data']['balance'])
        ) {
            throw new Exception('Gagal mengambil saldo provider');
        }

        $saldo = (float) $result['data']['balance'];

        /* === UPDATE SALDO === */
        $upd = $call->prepare("
            UPDATE provider
            SET balance = ?
            WHERE code = ?
        ");
        $upd->bind_param("ds", $saldo, $code);
        $upd->execute();

        echo json_encode([
            'status'  => true,
            'saldo'   => $saldo,
            'message' => 'Saldo berhasil diperbarui'
        ]);
        exit;
    }

    /* === PROVIDER MANUAL / LAINNYA === */
    echo json_encode([
        'status'  => false,
        'message' => 'Provider ini tidak mendukung cek saldo otomatis'
    ]);
    exit;

} catch (Exception $e) {
    echo json_encode([
        'status'  => false,
        'message' => $e->getMessage()
    ]);
    exit;
}
