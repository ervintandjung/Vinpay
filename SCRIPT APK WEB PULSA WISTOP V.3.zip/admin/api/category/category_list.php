<?php
require '../../../connect.php';
require _DIR_('library/session/admin');

$q = $call->query("SELECT * FROM category ORDER BY id DESC");

$data = [];
while ($r = $q->fetch_assoc()) {
    $data[] = [
        'id'      => (int)$r['id'],
        'code'    => $r['code'],
        'nama'    => $r['name'],   // mapping ke JS
        'target'  => (int)$r['target'],
        'type'    => $r['type']
    ];
}

echo json_encode(['data' => $data]);
