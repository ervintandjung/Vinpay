<?php
require '../../../connect.php';
require _DIR_('library/session/admin');

header('Content-Type: application/json');

/* ================= AMBIL & SANITASI DATA ================= */
$code   = trim($_POST['code'] ?? '');
$name   = trim($_POST['name'] ?? '');
$type   = trim($_POST['type'] ?? '');
$target = trim($_POST['target'] ?? '');

/* ================= VALIDASI WAJIB ================= */
if ($code === '' || $name === '' || $type === '' || $target === '') {
    echo json_encode([
        'status'  => false,
        'message' => 'Semua field wajib diisi'
    ]);
    exit;
}

if (!is_numeric($target)) {
    echo json_encode([
        'status'  => false,
        'message' => 'Target tidak valid'
    ]);
    exit;
}

/* ================= VALIDASI PANJANG DATA ================= */
if (strlen($code) > 30) {
    echo json_encode([
        'status'  => false,
        'message' => 'Kode kategori terlalu panjang'
    ]);
    exit;
}

if (strlen($name) > 100) {
    echo json_encode([
        'status'  => false,
        'message' => 'Nama kategori terlalu panjang'
    ]);
    exit;
}

/* ================= CEK DUPLIKAT CODE ================= */
$checkCode = $call->prepare("
    SELECT id FROM category WHERE code=? LIMIT 1
");
$checkCode->bind_param("s", $code);
$checkCode->execute();
$checkCode->store_result();

if ($checkCode->num_rows > 0) {
    echo json_encode([
        'status'  => false,
        'message' => 'Kode kategori sudah digunakan'
    ]);
    exit;
}

/* ================= CEK DUPLIKAT NAME ================= */
$checkName = $call->prepare("
    SELECT id FROM category WHERE name=? LIMIT 1
");
$checkName->bind_param("s", $name);
$checkName->execute();
$checkName->store_result();

if ($checkName->num_rows > 0) {
    echo json_encode([
        'status'  => false,
        'message' => 'Nama kategori sudah digunakan'
    ]);
    exit;
}

/* ================= INSERT DATA ================= */
$stmt = $call->prepare("
    INSERT INTO category (code, name, type, target)
    VALUES (?, ?, ?, ?)
");
$stmt->bind_param(
    "sssi",
    $code,
    $name,
    $type,
    $target
);

if ($stmt->execute()) {
    echo json_encode([
        'status'  => true,
        'message' => 'Kategori berhasil ditambahkan'
    ]);
} else {
    echo json_encode([
        'status'  => false,
        'message' => 'Gagal menambahkan kategori'
    ]);
}