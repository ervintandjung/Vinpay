<?php
require '../../../connect.php';
require _DIR_('library/session/admin');

$stmt = $call->prepare("DELETE FROM category WHERE id=?");
$stmt->bind_param("i", $_POST['id']);
$stmt->execute();

echo json_encode(['status' => true]);
