<?php
require '../../../connect.php';
require _DIR_('library/session/admin');

header('Content-Type: application/json');

/* ================= VALIDASI WAJIB ================= */
$id     = trim($_POST['id'] ?? '');
$name   = trim($_POST['name'] ?? '');
$target = trim($_POST['target'] ?? '');

if (!$id || !$name || !$target) {
    echo json_encode([
        'status' => false,
        'message' => 'Data tidak lengkap'
    ]);
    exit;
}

if (!is_numeric($id) || !is_numeric($target)) {
    echo json_encode([
        'status' => false,
        'message' => 'Data tidak valid'
    ]);
    exit;
}

/* ================= CEK KATEGORI ADA ATAU TIDAK ================= */
$check = $call->prepare("SELECT id FROM category WHERE id=? LIMIT 1");
$check->bind_param("i", $id);
$check->execute();
$check->store_result();

if ($check->num_rows === 0) {
    echo json_encode([
        'status' => false,
        'message' => 'Kategori tidak ditemukan'
    ]);
    exit;
}

/* ================= CEK DUPLIKAT NAMA ================= */
$dupName = $call->prepare("
    SELECT id FROM category 
    WHERE name=? AND id!=? 
    LIMIT 1
");
$dupName->bind_param("si", $name, $id);
$dupName->execute();
$dupName->store_result();

if ($dupName->num_rows > 0) {
    echo json_encode([
        'status' => false,
        'message' => 'Nama kategori sudah digunakan'
    ]);
    exit;
}

/* ================= CEK APAKAH DATA BERUBAH ================= */
$current = $call->prepare("
    SELECT name, target 
    FROM category WHERE id=? LIMIT 1
");
$current->bind_param("i", $id);
$current->execute();
$data = $current->get_result()->fetch_assoc();

if (
    $data['name']   === $name &&
    (int)$data['target'] === (int)$target
) {
    echo json_encode([
        'status' => false,
        'message' => 'Tidak ada perubahan data'
    ]);
    exit;
}

/* ================= UPDATE ================= */
$stmt = $call->prepare("
    UPDATE category
    SET name=?, target=?
    WHERE id=?
");
$stmt->bind_param(
    "sii",
    $name,
    $target,
    $id
);
$stmt->execute();

/* ================= RESULT ================= */
if ($stmt->affected_rows >= 0) {
    echo json_encode([
        'status' => true,
        'message' => 'Kategori berhasil diperbarui'
    ]);
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Gagal memperbarui kategori'
    ]);
}