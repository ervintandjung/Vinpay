<?php
header('Content-Type: application/json');
require '../../../connect.php';

// Ambil JSON body
$input = json_decode(file_get_contents("php://input"), true);

// Validasi ID
if (!isset($input['id']) || empty($input['id'])) {
    http_response_code(400);
    echo json_encode([
        'status' => false,
        'message' => 'ID tidak valid'
    ]);
    exit;
}

$id = (int) $input['id'];

// Cek data ada atau tidak
$check = $call->prepare("SELECT id FROM method WHERE id=?");
$check->bind_param("i", $id);
$check->execute();
$check->store_result();

if ($check->num_rows === 0) {
    http_response_code(404);
    echo json_encode([
        'status' => false,
        'message' => 'Data tidak ditemukan'
    ]);
    exit;
}
$check->close();

// Delete data
$stmt = $call->prepare("DELETE FROM method WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo json_encode([
        'status' => true,
        'message' => 'Metode berhasil dihapus'
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        'status' => false,
        'message' => 'Gagal menghapus data'
    ]);
}

$stmt->close();
$call->close();
