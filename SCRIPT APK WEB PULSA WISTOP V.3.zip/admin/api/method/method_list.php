<?php
header('Content-Type: application/json');
require '../../../connect.php';

$q = $call->query("SELECT * FROM method ORDER BY id DESC");

$data = [];
while($r = $q->fetch_assoc()){
    $data[] = [
        "id"   => $r['id'],
        "nama" => $r["nama"],
        "rate" => (int)$r["rate"],
        "feeType" => $r["fee_type"],
        "fee" => $r["fee"],
        "inc" => $r["inc"],
        "minimal" => (int)$r["minimal"],
        "provider" => $r["provider"],
        "owner" => $r["owner"],
        "rekening" => $r["rekening"]
    ];
}

echo json_encode($data);
