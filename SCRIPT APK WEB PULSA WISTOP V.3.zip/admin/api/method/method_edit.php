<?php
header('Content-Type: application/json');
require '../../../connect.php';

$input = json_decode(file_get_contents("php://input"), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['status'=>false,'message'=>'Request tidak valid']);
    exit;
}

$id         = isset($input['id']) ? (int)$input['id'] : null;
$nama       = trim($input['nama'] ?? '');
$owner      = trim($input['owner'] ?? '');
$providerIn = $input['provider'] ?? '';
$feeType    = $input['feeType'] ?? '';
$fee        = trim($input['fee'] ?? '0');
$inc        = $input['inc'] ?? '';
$minimal    = (int)($input['minimal'] ?? 0);
$rekening   = trim($input['rekening'] ?? '');
$rate       = 1;

/* ================= VALIDASI ================= */

if ($nama === '' || $rekening === '') {
    echo json_encode(['status'=>false,'message'=>'Nama & rekening wajib diisi']);
    exit;
}

if (!in_array($feeType, ['%','+'])) {
    echo json_encode(['status'=>false,'message'=>'Fee type tidak valid']);
    exit;
}

if (!in_array($inc, ['Pelanggan','Store'])) {
    echo json_encode(['status'=>false,'message'=>'Tanggungan tidak valid']);
    exit;
}

/* ===== VALIDASI FEE SESUAI TIPE (WAJIB) ===== */
if ($feeType === '%') {
    if (!is_numeric($fee) || $fee < 0 || $fee > 100) {
        echo json_encode([
            'status'=>false,
            'message'=>'Persentase harus angka 0 - 100'
        ]);
        exit;
    }
} else {
    if (!ctype_digit(str_replace('.', '', $fee))) {
        echo json_encode([
            'status'=>false,
            'message'=>'Nominal harus angka'
        ]);
        exit;
    }
}

/* ================= KONVERSI PROVIDER ================= */
$provider = ($providerIn === 'X') ? 'Manual' : 'PST';

/* ================= INSERT ================= */
if ($id === null) {

    $stmt = $call->prepare("
        INSERT INTO method
        (nama, rate, fee_type, fee, inc, minimal, provider, owner, rekening)
        VALUES (?,?,?,?,?,?,?,?,?)
    ");
    
    $stmt->bind_param(
        "sisssisss",
        $nama,       // s
        $rate,       // i
        $feeType,    // s
        $fee,        // d ✅
        $inc,        // s
        $minimal,    // i
        $provider,   // s
        $owner,      // s
        $rekening    // s
    );

    if(!$stmt->execute()){
        echo json_encode(['status'=>false,'message'=>'SQL Error: '.$stmt->error]);
        exit;
    }

    $stmt->close();

    echo json_encode(['status'=>true,'message'=>'Data berhasil ditambahkan']);
    exit;
}

/* ================= UPDATE ================= */

$check = $call->prepare("SELECT id FROM method WHERE id=?");
$check->bind_param("i",$id);
$check->execute();
$check->store_result();

if($check->num_rows===0){
    echo json_encode(['status'=>false,'message'=>'Data tidak ditemukan']);
    exit;
}
$check->close();

$stmt = $call->prepare("
    UPDATE method SET
        nama=?,
        rate=?,
        fee_type=?,
        fee=?,
        inc=?,
        minimal=?,
        provider=?,
        owner=?,
        rekening=?
    WHERE id=?
");

$stmt->bind_param(
    "sisssisssi",
    $nama,       // s
    $rate,       // i
    $feeType,    // s
    $fee,        // d ✅
    $inc,        // s
    $minimal,    // i
    $provider,   // s
    $owner,      // s
    $rekening,   // s
    $id          // i
);

file_put_contents(
    __DIR__.'/debug_fee.txt',
    "RAW: ".$input['fee']." | FLOAT: ".$fee
);

if(!$stmt->execute()){
    echo json_encode(['status'=>false,'message'=>'SQL Error: '.$stmt->error]);
    exit;
}

$stmt->close();

echo json_encode(['status'=>true,'message'=>'Data berhasil diperbarui']);