<?php
require '../../../connect.php';
require _DIR_('library/session/admin');

$q = $call->query("SELECT * FROM transaction ORDER BY id DESC");

$data = [];

while($r = $q->fetch_assoc()){

    $map = [
        'error'   => 'Error',
        'waiting' => 'Waiting',
        'success' => 'Sukses'
    ];

    $data[] = [
        'id'      => $r['tid'],     // bisa pakai id kalau mau
        'tanggal' => $r['date_cr'],
        'user'    => $r['user'],
        'produk'  => $r['name'],
        'data'    => $r['data'],
        'harga'   => (int)$r['price'],
        'status'  => $map[$r['status']] ?? 'Pending'
    ];
}

echo json_encode($data);
