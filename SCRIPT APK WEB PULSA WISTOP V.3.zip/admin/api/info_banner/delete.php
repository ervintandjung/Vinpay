<?php
require '../../../connect.php';
header('Content-Type: application/json');

$id = intval($_POST['id'] ?? 0);
mysqli_query($call,"DELETE FROM info_banner WHERE id=$id");

echo json_encode(['success'=>true]);