<?php
require '../../../connect.php';
header('Content-Type: application/json');

$q = mysqli_query($call,"SELECT * FROM info_banner ORDER BY id DESC");

$data = [];
while($r = mysqli_fetch_assoc($q)){
    $data[] = $r;
}

echo json_encode($data);