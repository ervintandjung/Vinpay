<?php
require '../../../connect.php';
header('Content-Type: application/json');

$id        = $_POST['id'] ?? '';
$title     = mysqli_real_escape_string($call,$_POST['title'] ?? '');
$highlight = mysqli_real_escape_string($call,$_POST['highlight'] ?? '');
$color     = mysqli_real_escape_string($call,$_POST['icon_color'] ?? 'blue');
$status    = mysqli_real_escape_string($call,$_POST['status'] ?? 'ON');

if($id){
    mysqli_query($call,"UPDATE info_banner SET
        title='$title',
        highlight='$highlight',
        icon_color='$color',
        status='$status'
        WHERE id='$id'
    ");
}else{
    mysqli_query($call,"INSERT INTO info_banner
        (title,highlight,icon_color,status)
        VALUES
        ('$title','$highlight','$color','$status')
    ");
}

echo json_encode(['success'=>true]);