<?php
require '../../../connect.php';
require _DIR_('library/session/admin');

header('Content-Type: application/json');

$q = $call->query("SELECT support_email, support_whatsapp FROM help_settings LIMIT 1");

if($q->num_rows == 0){
    echo json_encode([]);
}else{
    echo json_encode($q->fetch_assoc());
}