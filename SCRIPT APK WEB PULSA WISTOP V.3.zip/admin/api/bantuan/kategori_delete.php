<?php
require '../../../connect.php';
require _DIR_('library/session/admin');

header('Content-Type: application/json');

$id = intval($_POST['id'] ?? 0);
if(!$id) exit(json_encode(['status'=>false]));

$call->query("DELETE FROM help_faq WHERE category_id=$id");
$call->query("DELETE FROM help_categories WHERE id=$id");

echo json_encode(['status'=>true]);