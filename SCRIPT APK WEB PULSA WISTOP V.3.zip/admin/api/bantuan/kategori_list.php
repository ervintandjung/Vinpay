<?php
require '../../../connect.php';
require _DIR_('library/session/admin');

header('Content-Type: application/json');

$data = [];

$q = $call->query("
    SELECT c.id, c.title, c.subtitle, c.slug, c.status,
           COUNT(f.id) as total_faq
    FROM help_categories c
    LEFT JOIN help_faq f ON f.category_id = c.id
    GROUP BY c.id
    ORDER BY c.sort_order ASC
");

while($row = $q->fetch_assoc()){
    $data[] = $row;
}

echo json_encode($data);