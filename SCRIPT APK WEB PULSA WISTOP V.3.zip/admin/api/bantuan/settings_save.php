<?php
require '../../../connect.php';
require _DIR_('library/session/admin');

header('Content-Type: application/json');

$email = trim($_POST['email'] ?? '');
$wa    = trim($_POST['wa'] ?? '');

$exists = $call->query("SELECT id FROM help_settings LIMIT 1")->num_rows;

if($exists){
    $stmt = $call->prepare("UPDATE help_settings SET support_email=?, support_whatsapp=?");
    $stmt->bind_param("ss",$email,$wa);
    $stmt->execute();
}else{
    $stmt = $call->prepare("INSERT INTO help_settings (support_email,support_whatsapp) VALUES (?,?)");
    $stmt->bind_param("ss",$email,$wa);
    $stmt->execute();
}

echo json_encode(['status'=>true]);