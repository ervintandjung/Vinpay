<?php
require '../../../connect.php';
require _DIR_('library/session/admin');

header('Content-Type: application/json');

$category_id = intval($_POST['category_id'] ?? 0);
$question    = trim($_POST['question'] ?? '');
$answer      = trim($_POST['answer'] ?? '');

if(!$category_id || !$question || !$answer){
    exit(json_encode(['status'=>false,'msg'=>'Data tidak lengkap']));
}

$stmt = $call->prepare("INSERT INTO help_faq (category_id,question,answer,status,sort_order) VALUES (?,?,?,'ON',0)");
$stmt->bind_param("iss",$category_id,$question,$answer);
$stmt->execute();

echo json_encode(['status'=>true]);