<?php
require '../../../connect.php';
require _DIR_('library/session/admin');

header('Content-Type: application/json');

$id       = $_POST['id'] ?? null;
$title    = trim($_POST['title'] ?? '');
$subtitle = trim($_POST['subtitle'] ?? '');
$slug     = trim($_POST['slug'] ?? '');
$status   = $_POST['status'] ?? 'ON';

if(!$title || !$slug){
    exit(json_encode(['status'=>false,'msg'=>'Data tidak lengkap']));
}

if($id){
    $stmt = $call->prepare("UPDATE help_categories SET title=?, subtitle=?, slug=?, status=? WHERE id=?");
    $stmt->bind_param("ssssi",$title,$subtitle,$slug,$status,$id);
    $stmt->execute();
}else{
    $stmt = $call->prepare("INSERT INTO help_categories (title,subtitle,slug,status,sort_order) VALUES (?,?,?,?,0)");
    $stmt->bind_param("ssss",$title,$subtitle,$slug,$status);
    $stmt->execute();
}

echo json_encode(['status'=>true]);