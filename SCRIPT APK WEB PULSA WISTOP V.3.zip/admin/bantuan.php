<?php
require '../connect.php';
require _DIR_('library/session/admin');
include __DIR__ . '/../layout/adminheader.php';
include __DIR__ . '/../layout/adminnavigasi.php';

/* ================= STAT ================= */
$totalKategori = $call->query("SELECT id FROM help_categories")->num_rows;
$totalFAQ      = $call->query("SELECT id FROM help_faq")->num_rows;
?>

<main class="flex-1 p-4 md:p-6 overflow-x-hidden">

    <div class="mb-6">
        <h1 class="text-2xl font-bold text-slate-800">Kelola Bantuan</h1>
        <p class="text-sm text-slate-500">
            Pengaturan halaman bantuan & FAQ pengguna
        </p>
    </div>

    <!-- STAT -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div class="bg-indigo-50 border border-indigo-200 rounded-2xl p-5">
            <p class="text-sm text-indigo-600">Total Kategori</p>
            <p class="text-3xl font-bold text-indigo-600"><?= $totalKategori ?></p>
        </div>
        <div class="bg-cyan-50 border border-cyan-200 rounded-2xl p-5">
            <p class="text-sm text-cyan-600">Total FAQ</p>
            <p class="text-3xl font-bold text-cyan-600"><?= $totalFAQ ?></p>
        </div>
    </div>

    <!-- ACTION -->
    <div class="flex flex-wrap gap-3 mb-6">
        <button onclick="openAddKategori()" class="btn-primary">+ Tambah Kategori</button>
        <button onclick="openAddFAQ()" class="btn-primary bg-emerald-500 hover:bg-emerald-600">
            + Tambah FAQ
        </button>
        <button onclick="openSettings()" class="btn">Pengaturan Kontak</button>
    </div>

    <!-- TABLE -->
    <div class="bg-white rounded-2xl shadow-sm">
        <div class="relative overflow-x-auto">
            <table class="min-w-[900px] w-full text-sm">
                <thead class="bg-slate-100 text-slate-600">
                    <tr>
                        <th class="px-4 py-3 text-left">Kategori</th>
                        <th class="px-4 py-3 text-left">Subtitle</th>
                        <th class="px-4 py-3 text-left">Slug</th>
                        <th class="px-4 py-3 text-left">FAQ</th>
                        <th class="px-4 py-3 text-left">Status</th>
                        <th class="px-4 py-3 text-center">Action</th>
                    </tr>
                </thead>
                <tbody id="tableData" class="divide-y"></tbody>
            </table>
        </div>
    </div>

</main>

<!-- MODAL -->
<div id="modal" class="fixed inset-0 bg-black/40 hidden items-center justify-center z-50"></div>

<script>
let kategori = [];
let modeEdit = false;
let editId   = null;

/* ================= LOAD DATA ================= */
loadKategori();

function loadKategori(){
    fetch('<?= base_url('admin/api/bantuan/kategori_list') ?>')
    .then(r=>r.json())
    .then(r=>{
        kategori=r;
        render();
    });
}

/* ================= RENDER ================= */
function render(){
    tableData.innerHTML=kategori.map(k=>`
        <tr class="hover:bg-slate-50">
            <td class="px-4 py-3 font-semibold">${k.title}</td>
            <td class="px-4 py-3">${k.subtitle??'-'}</td>
            <td class="px-4 py-3">${k.slug}</td>
            <td class="px-4 py-3">${k.total_faq} FAQ</td>
            <td class="px-4 py-3">${badge(k.status)}</td>
            <td class="px-4 py-3">
                <div class="flex justify-center gap-2">
                    <button onclick="editKategori(${k.id})" class="icon-btn">${iconEdit()}</button>
                    <button onclick="hapusKategori(${k.id})" class="icon-btn text-rose-500">${iconTrash()}</button>
                </div>
            </td>
        </tr>
    `).join('');
}

function badge(s){
    return `<span class="px-3 py-1 rounded-full text-xs
        ${s=='ON'?'bg-emerald-100 text-emerald-600':'bg-rose-100 text-rose-600'}">
        ${s}
    </span>`;
}

/* ================= FORM KATEGORI ================= */
function formKategori(data={}){
    return `
    <div class="bg-white p-6 rounded-2xl w-full max-w-md">
        <h3 class="text-lg font-bold mb-4">
            ${modeEdit?'Edit':'Tambah'} Kategori
        </h3>
        <div class="space-y-3">
            <input id="title" value="${data.title??''}" placeholder="Judul" class="input">
            <input id="subtitle" value="${data.subtitle??''}" placeholder="Subtitle" class="input">
            <input id="slug" value="${data.slug??''}" placeholder="Slug" class="input">
            <select id="status" class="input">
                <option value="ON" ${data.status=='ON'?'selected':''}>Aktif</option>
                <option value="OFF" ${data.status=='OFF'?'selected':''}>Nonaktif</option>
            </select>
            <div class="text-right flex gap-2 justify-end">
                <button onclick="closeModal()" class="btn">Batal</button>
                <button onclick="saveKategori()" class="btn-primary">Simpan</button>
            </div>
        </div>
    </div>`;
}

/* ================= TAMBAH ================= */
function openAddKategori(){
    modeEdit=false;
    editId=null;
    openModal(formKategori());
}

/* ================= EDIT ================= */
function editKategori(id){
    const data = kategori.find(k=>k.id==id);
    if(!data) return;

    modeEdit=true;
    editId=id;
    openModal(formKategori(data));
}

/* ================= SIMPAN ================= */
function saveKategori(){
    fetch('<?= base_url('admin/api/bantuan/kategori_save') ?>',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:new URLSearchParams({
            id:editId,
            title:title.value,
            subtitle:subtitle.value,
            slug:slug.value,
            status:status.value
        })
    })
    .then(r=>r.json())
    .then(r=>{
        if(!r.status) return alert(r.msg);
        closeModal();
        loadKategori();
    });
}

/* ================= HAPUS ================= */
function hapusKategori(id){
    if(!confirm('Hapus kategori ini beserta semua FAQ?')) return;

    fetch('<?= base_url('admin/api/bantuan/kategori_delete') ?>',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:new URLSearchParams({id})
    })
    .then(r=>r.json())
    .then(r=>{
        if(!r.status) return alert('Gagal hapus');
        loadKategori();
    });
}

/* ================= FAQ ================= */
function openAddFAQ(){
    const options = kategori.map(k=>`<option value="${k.id}">${k.title}</option>`).join('');

    openModal(`
    <div class="bg-white p-6 rounded-2xl w-full max-w-lg">
        <h3 class="text-lg font-bold mb-4">Tambah FAQ</h3>
        <div class="space-y-3">
            <select id="category_id" class="input">${options}</select>
            <input id="question" placeholder="Pertanyaan" class="input">
            <textarea id="answer" placeholder="Jawaban" class="input h-28"></textarea>
            <div class="text-right">
                <button onclick="saveFAQ()" class="btn-primary">Simpan</button>
            </div>
        </div>
    </div>`);
}

function saveFAQ(){
    fetch('<?= base_url('admin/api/bantuan/faq_save') ?>',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:new URLSearchParams({
            category_id:category_id.value,
            question:question.value,
            answer:answer.value
        })
    })
    .then(r=>r.json())
    .then(r=>{
        if(!r.status) return alert(r.msg);
        closeModal();
        loadKategori();
    });
}

/* ================= SETTINGS ================= */
function openSettings(){
    fetch('<?= base_url('admin/api/bantuan/settings_get') ?>')
    .then(r=>r.json())
    .then(s=>{
        openModal(`
        <div class="bg-white p-6 rounded-2xl w-full max-w-md">
            <h3 class="text-lg font-bold mb-4">Pengaturan Kontak</h3>
            <div class="space-y-3">
                <input id="email" value="${s.support_email??''}" placeholder="Email" class="input">
                <input id="wa" value="${s.support_whatsapp??''}" placeholder="WhatsApp" class="input">
                <div class="text-right">
                    <button onclick="saveSettings()" class="btn-primary">Simpan</button>
                </div>
            </div>
        </div>`);
    });
}

function saveSettings(){
    fetch('<?= base_url('admin/api/bantuan/settings_save') ?>',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:new URLSearchParams({
            email:email.value,
            wa:wa.value
        })
    }).then(()=>closeModal());
}

/* ================= UTIL ================= */
function openModal(html){
    modal.innerHTML=html;
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}
function closeModal(){
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}

function iconEdit(){return `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M4 21h4l11-11-4-4L4 17v4z"/></svg>`;}
function iconTrash(){return `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M3 6h18"/><path d="M8 6v14"/><path d="M16 6v14"/></svg>`;}
</script>

<style>
.btn{padding:.5rem 1rem;border:1px solid #e5e7eb;border-radius:.75rem}
.btn-primary{padding:.5rem 1rem;background:#6366f1;color:white;border-radius:.75rem}
.input{width:100%;border:1px solid #e5e7eb;padding:.6rem .8rem;border-radius:.75rem}
.icon-btn svg{color:#475569}
</style>

<?php include __DIR__ . '/../layout/adminfooter.php'; ?>