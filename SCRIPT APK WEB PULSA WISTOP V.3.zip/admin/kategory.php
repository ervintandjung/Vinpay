<?php
require '../connect.php';
require _DIR_('library/session/admin');
include __DIR__ . '/../layout/adminheader.php';
include __DIR__ . '/../layout/adminnavigasi.php';
?>
<main class="flex-1 p-4 md:p-6 overflow-x-hidden">

    <!-- HEADER -->
    <div class="mb-5">
        <h1 class="text-2xl font-bold text-slate-800">Kategory</h1>
        <p class="text-sm text-slate-500">Kelola kategory produk</p>
    </div>

    <!-- ACTION BAR -->
    <div class="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div class="flex gap-2">
            <button onclick="openAdd()"
                    class="btn-primary">
                + Tambah Kategory
            </button>
            <button onclick="hapusSemua()"
                    class="btn-danger">
                Hapus Semua
            </button>
        </div>

        <input id="search"
               type="text"
               placeholder="Cari kategory..."
               class="w-full md:w-80 input">
    </div>

    <!-- ================= TABLE ================= -->
    <div class="bg-white rounded-2xl shadow-sm">
        <div class="relative overflow-x-auto">
            <table class="min-w-[1000px] w-full text-sm">

                <thead class="bg-slate-100 text-slate-600">
                    <tr>
                        <th class="px-4 py-3 text-left">Code</th>
                        <th class="px-4 py-3 text-left">Nama</th>
                        <th class="px-4 py-3 text-left">Type</th>
                        <th class="px-4 py-3 text-left">Target</th>
                        <th class="px-4 py-3 text-center">Action</th>
                    </tr>
                </thead>

                <tbody id="katTable" class="divide-y"></tbody>

            </table>
        </div>
    </div>

    <!-- PAGINATION -->
    <div id="pagination"
         class="flex justify-center items-center gap-1 mt-6 text-sm flex-wrap"></div>

</main>

<!-- MODAL -->
<div id="modal"
     class="fixed inset-0 bg-black/40 backdrop-blur-sm
            hidden items-center justify-center z-50"></div>

<!-- NOTIF -->
<div id="notif"
     class="fixed bottom-6 right-6 hidden
            px-5 py-4 rounded-2xl shadow-lg
            text-white font-semibold z-50"></div>

<script>
/* ================= GLOBAL ================= */
let kategories = [];
let filtered = [];
let page = 1;
const perPage = 7;
let active = null;

/* ================= LOAD DATA ================= */
async function loadKategori(){
    const res = await fetch("<?= base_url('admin/api/category/category_list') ?>");
    const json = await res.json();

    kategories = json.data.map(k => ({
        ...k,
        id: Number(k.id),
        target: Number(k.target)
    }));

    filtered = [...kategories];
    page = 1;
    render();
}

/* ================= RENDER ================= */
function render(){
    const start = (page - 1) * perPage;
    const data = filtered.slice(start, start + perPage);

    katTable.innerHTML = data.map(k => `
        <tr class="hover:bg-slate-50">
            <td class="px-4 py-3 font-medium">${k.code}</td>
            <td class="px-4 py-3">${k.nama}</td>
            <td class="px-4 py-3">${k.type}</td>
            <td class="px-4 py-3">${k.target} Kolom</td>
            <td class="px-4 py-3">
                <div class="flex justify-center gap-2">
                    <button onclick="openEdit(${k.id})" class="icon-btn">
                        ${iconGear()}
                    </button>
                    <button onclick="openDelete(${k.id})" class="icon-btn text-rose-500">
                        ${iconTrash()}
                    </button>
                </div>
            </td>
        </tr>
    `).join('');

    renderPagination();
}

/* ================= PAGINATION ================= */
function renderPagination(){
    const total = Math.ceil(filtered.length / perPage);
    pagination.innerHTML = '';

    const btn = (label, p, active=false) => `
        <button onclick="page=${p};render()"
            class="px-3 py-1 rounded-lg ${active ? 'bg-blue-500 text-white' : 'hover:bg-slate-100'}">
            ${label}
        </button>`;

    if(page > 1) pagination.innerHTML += btn('&lt;', page - 1);

    for(let i = 1; i <= total; i++){
        pagination.innerHTML += btn(i, i, page === i);
    }

    if(page < total) pagination.innerHTML += btn('&gt;', page + 1);
}

/* ================= SEARCH ================= */
search.oninput = e => {
    const q = e.target.value.toLowerCase();
    filtered = kategories.filter(k =>
        k.code.toLowerCase().includes(q) ||
        k.nama.toLowerCase().includes(q)
    );
    page = 1;
    render();
};

/* ================= ADD ================= */
function openAdd(){
    openModal(`
        <div class="bg-white rounded-2xl p-6 w-full max-w-md">
            <h3 class="text-lg font-bold mb-4">Tambah Kategori</h3>

            <input id="aCode" class="input" placeholder="Code">
            <input id="aNama" class="input" placeholder="Nama">

            <select id="aType" class="input">
                <option value="pulsa-reguler">Pulsa</option>
                <option value="pulsa-internasional">Pulsa Internasional</option>
                <option value="paket-internet">Paket Internet</option>
                <option value="paket-telepon">Paket Telepon</option>
                <option value="token-pln">Token PLN</option>
                <option value="saldo-emoney">E-Money</option>
                <option value="paket-lainnya">Lainnya</option>
                <option value="streaming-tv">Streaming TV</option>
                <option value="voucher-game">Voucher Game</option>
                <option value="pascabayar">Pascabayar</option>
            </select>

            <select id="aTarget" class="input">
                <option value="1">1 Kolom</option>
                <option value="2">2 Kolom</option>
                <option value="3">3 Kolom</option>
            </select>

            <div class="flex justify-end gap-2 mt-4">
                <button onclick="closeModal()" class="btn">Batal</button>
                <button onclick="saveAdd()" class="btn-primary">Simpan</button>
            </div>
        </div>
    `);
}

function saveAdd(){
    fetch("<?= base_url('admin/api/category/category_add') ?>", {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: new URLSearchParams({
            code: aCode.value,
            name: aNama.value,
            type: aType.value,
            target: aTarget.value
        })
    })
    .then(r => r.json())
    .then(res => {
        notify(res.message, res.status ? 'bg-emerald-500' : 'bg-rose-500');
        if(res.status){
            closeModal();
            loadKategori();
        }
    });
}

/* ================= EDIT ================= */
function openEdit(id){
    active = kategories.find(k => k.id === id);
    if(!active) return alert('Kategori tidak ditemukan');

    openModal(`
        <div class="bg-white rounded-2xl p-6 w-full max-w-md">
            <h3 class="text-lg font-bold mb-4">Edit Kategori</h3>

            <input class="input" value="${active.code}" disabled>
            <input id="eNama" class="input" value="${active.nama}">

            <select id="eType" class="input" disabled>
                <option value="pulsa-reguler" ${active.type==='pulsa-reguler'?'selected':'pulsa-reguler'}>Pulsa</option>
                <option value="pulsa-internasional" ${active.type==='pulsa-internasional'?'selected':'pulsa-internasional'}>Pulsa Internasional</option>
                <option value="paket-internet" ${active.type==='paket-internet'?'selected':'paket-internet'}>Paket Internet</option>
                <option value="paket-telepon" ${active.type==='paket-telepon'?'selected':'paket-telepon'}>Paket Telepon</option>
                <option value="token-pln" ${active.type==='token-pln'?'selected':'token-pln'}>Token PLN</option>
                <option value="saldo-emoney" ${active.type==='saldo-emoney'?'selected':'saldo-emoney'}>E-Money</option>
                <option value="paket-lainnya" ${active.type==='paket-lainnya'?'selected':'paket-lainnya'}>Lainnya</option>
                <option value="streaming-tv" ${active.type==='streaming-tv'?'selected':'streaming-tv'}>Streaming TV</option>
                <option value="voucher-game" ${active.type==='voucher-game'?'selected':'voucher-game'}>Voucher Game</option>
                <option value="pascabayar" ${active.type==='pascabayar'?'selected':'pascabayar'}>Pascabayar</option>
            </select>

            <select id="eTarget" class="input">
                <option value="1" ${active.target==1?'selected':''}>1 Kolom</option>
                <option value="2" ${active.target==2?'selected':''}>2 Kolom</option>
                <option value="3" ${active.target==3?'selected':''}>3 Kolom</option>
            </select>

            <div class="flex justify-end gap-2 mt-4">
                <button onclick="closeModal()" class="btn">Batal</button>
                <button onclick="saveEdit()" class="btn-primary">Simpan</button>
            </div>
        </div>
    `);
}

function saveEdit(){
    fetch("<?= base_url('admin/api/category/category_update') ?>", {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: new URLSearchParams({
            id: active.id,
            name: eNama.value,
            target: eTarget.value
        })
    })
    .then(r => r.json())
    .then(res => {
        notify(res.message, res.status ? 'bg-emerald-500' : 'bg-rose-500');
        if(res.status){
            closeModal();
            loadKategori();
        }
    });
}

/* ================= DELETE ================= */
function openDelete(id){
    active = kategories.find(k => k.id === id);
    if(!active) return alert('Kategori tidak ditemukan');

    openModal(`
        <div class="bg-white rounded-2xl p-6 w-full max-w-sm text-center">
            <h3 class="text-lg font-bold text-rose-600 mb-2">Hapus Kategori</h3>
            <p class="text-sm text-slate-500">
                Yakin hapus kategori <b>${active.code}</b>?
            </p>

            <div class="flex justify-center gap-2 mt-4">
                <button onclick="closeModal()" class="btn">Batal</button>
                <button onclick="deleteKategori()" class="btn-danger">Hapus</button>
            </div>
        </div>
    `);
}

function deleteKategori(){
    fetch("<?= base_url('admin/api/category/category_delete') ?>", {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: new URLSearchParams({ id: active.id })
    }).then(() => {
        notify('Kategori dihapus','bg-rose-500');
        closeModal();
        loadKategori();
    });
}

/* ================= UTIL ================= */
function openModal(html){
    modal.innerHTML = html;
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}
function closeModal(){
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}
function notify(text,color){
    notif.textContent = text;
    notif.className = `fixed bottom-6 right-6 px-5 py-4 rounded-2xl shadow-lg text-white font-semibold ${color}`;
    notif.classList.remove('hidden');
    setTimeout(()=>notif.classList.add('hidden'),3000);
}

/* ================= ICON ================= */
function iconGear(){return `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M12 15.5a3.5 3.5 0 1 0 0-7"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.7l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.7-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 0 1-4 0v-.2a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.7.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.7 1.6 1.6 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.2a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.7l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.7.3 1.6 1.6 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.2a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.7-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.7 1.6 1.6 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.2a1.6 1.6 0 0 0-1.5 1z"/></svg>`;}
function iconTrash(){return `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M3 6h18"/><path d="M8 6v14"/><path d="M16 6v14"/><path d="M5 6l1 14h12l1-14"/></svg>`;}

/* ================= INIT ================= */
loadKategori();
</script>


<style>
.input{width:100%;padding:.5rem 1rem;border-radius:.75rem;border:1px solid #e5e7eb;margin-bottom:.5rem}
.btn{padding:.5rem 1rem;border:1px solid #e5e7eb;border-radius:.75rem}
.btn-primary{padding:.5rem 1rem;background:#3b82f6;color:white;border-radius:.75rem}
.btn-danger{padding:.5rem 1rem;background:#ef4444;color:white;border-radius:.75rem}
.icon-btn svg{color:#475569}
</style>

<?php include __DIR__ . '/../layout/adminfooter.php'; ?>
