<?php
require '../connect.php';
require _DIR_('library/session/admin');
include __DIR__ . '/../layout/adminheader.php';
include __DIR__ . '/../layout/adminnavigasi.php';
?>

<main class="flex-1 p-4 md:p-6 overflow-x-hidden">

    <!-- HEADER -->
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-slate-800">Transaksi</h1>
        <p class="text-sm text-slate-500">
            Geser tabel ke kiri / kanan untuk melihat kolom lainnya
        </p>
    </div>

    <!-- ================= STAT CARDS ================= -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div class="bg-rose-50 border border-rose-200 rounded-2xl p-5">
            <p class="text-sm text-rose-600">Transaksi Error</p>
            <p class="text-3xl font-bold text-rose-600" id="countError"><?= currency($call->query("SELECT id FROM transaction WHERE status = 'error'")->num_rows) ?></p>
        </div>
        <div class="bg-amber-50 border border-amber-200 rounded-2xl p-5">
            <p class="text-sm text-amber-600">Transaksi Pending</p>
            <p class="text-3xl font-bold text-amber-600" id="countPending"><?= currency($call->query("SELECT id FROM transaction WHERE status = 'waiting'")->num_rows) ?></p>
        </div>
        <div class="bg-emerald-50 border border-emerald-200 rounded-2xl p-5">
            <p class="text-sm text-emerald-600">Transaksi Sukses</p>
            <p class="text-3xl font-bold text-emerald-600" id="countSuccess"><?= currency($call->query("SELECT id FROM transaction WHERE status = 'success'")->num_rows) ?></p>
        </div>
    </div>

    <!-- ================= TABLE ================= -->
    <div class="bg-white rounded-2xl shadow-sm">
        <div class="relative overflow-x-auto">
            <table class="min-w-[1200px] w-full text-sm">

                <thead class="bg-slate-100 text-slate-600">
                    <tr>
                        <th class="px-4 py-3 text-left">Tanggal</th>
                        <th class="px-4 py-3 text-left">User</th>
                        <th class="px-4 py-3 text-left">Produk</th>
                        <th class="px-4 py-3 text-left">Data</th>
                        <th class="px-4 py-3 text-left">Status</th>
                        <th class="px-4 py-3 text-center">Action</th>
                    </tr>
                </thead>

                <tbody id="trxTable" class="divide-y"></tbody>

            </table>
        </div>
    </div>

    <!-- PAGINATION -->
    <div id="pagination"
         class="flex justify-center items-center gap-1 mt-6 text-sm flex-wrap"></div>

</main>

<!-- MODAL -->
<div id="modal"
     class="fixed inset-0 bg-black/40 backdrop-blur-sm
            hidden items-center justify-center z-50"></div>

<!-- NOTIF -->
<div id="notif"
     class="fixed bottom-6 right-6 hidden
            px-5 py-4 rounded-2xl shadow-lg
            text-white font-semibold z-50"></div>

<script>
/* ================= LOAD DATA FROM SERVER ================= */
let transaksi = [];
let filtered = [];
let page = 1;
const perPage = 6;

fetch('<?= base_url('admin/api/transaction/transaction_list') ?>')
    .then(res => res.json())
    .then(res => {
    transaksi = res;
    filtered = [...transaksi];
    render();
});


/* ================= RENDER ================= */
function render(){
    const start = (page-1)*perPage;
    const data = filtered.slice(start,start+perPage);

    trxTable.innerHTML = data.map(t=>`
        <tr class="hover:bg-slate-50">
            <td class="px-4 py-3">${t.tanggal}</td>
            <td class="px-4 py-3 font-medium">${t.user}</td>
            <td class="px-4 py-3">${t.produk}</td>
            <td class="px-4 py-3">
                <div class="flex items-center gap-2">
                    <span>${t.data}</span>
                    <button onclick="copyText('${t.data}')" class="icon-btn">
                        ${iconCopy()}
                    </button>
                </div>
            </td>
            <td class="px-4 py-3">${statusBadge(t.status)}</td>
            <td class="px-4 py-3">
                <div class="flex justify-center gap-2">
                    <button onclick="detail('${t.id}')" class="icon-btn">
                        ${iconEye()}
                    </button>
                    <button onclick="hapus('${t.id}')" class="icon-btn text-rose-500">
                        ${iconTrash()}
                    </button>
                </div>
            </td>
        </tr>
    `).join('');

    renderPagination();
    updateCards();
}


/* ================= PAGINATION ================= */
function renderPagination(){
    const total = Math.ceil(filtered.length/perPage);
    pagination.innerHTML = '';

    const btn = (label,p,active=false)=>`
        <button onclick="page=${p};render()"
            class="px-3 py-1 rounded-lg
            ${active?'bg-blue-500 text-white':'hover:bg-slate-100'}">
            ${label}
        </button>`;

    if(page>1) pagination.innerHTML += btn('&lt;',page-1);

    let s = Math.max(1,page-2),
        e = Math.min(total,page+2);

    if(s>1){
        pagination.innerHTML += btn(1,1,page===1);
        pagination.innerHTML += '<span class="px-1">…</span>';
    }

    for(let i=s;i<=e;i++){
        pagination.innerHTML += btn(i,i,page===i);
    }

    if(e<total){
        pagination.innerHTML += '<span class="px-1">…</span>';
        pagination.innerHTML += btn(total,total,page===total);
    }

    if(page<total) pagination.innerHTML += btn('&gt;',page+1);
}


/* ================= STATUS & CARD ================= */
function statusBadge(s){
    const map={
        Error:'bg-rose-100 text-rose-600',
        Pending:'bg-amber-100 text-amber-600',
        Proses:'bg-blue-100 text-blue-600',
        Waiting:'bg-slate-200 text-slate-600',
        Sukses:'bg-emerald-100 text-emerald-600'
    };
    return `<span class="px-3 py-1 rounded-full text-xs ${map[s]}">${s}</span>`;
}

function updateCards(){
    countError.textContent   = transaksi.filter(t=>t.status==='Error').length;
    countPending.textContent = transaksi.filter(t=>t.status==='Pending').length;
    countSuccess.textContent = transaksi.filter(t=>t.status==='Sukses').length;
}


/* ================= ACTION ================= */
function detail(id){
    const t = transaksi.find(x=>x.id===id);
    openModal(`
        <div class="bg-white rounded-2xl p-6 w-full max-w-md">
            <h3 class="text-lg font-bold mb-4">Detail Order</h3>
            <div class="text-sm space-y-2">
                <p><b>ID:</b> ${t.id}</p>
                <p><b>Produk:</b> ${t.produk}</p>
                <p><b>Data:</b> ${t.data}</p>
                <p><b>Harga:</b> Rp ${Number(t.harga).toLocaleString()}</p>
                <p><b>Status:</b> ${t.status}</p>
                <p><b>Tanggal:</b> ${t.tanggal}</p>
            </div>
            <div class="text-right mt-4">
                <button onclick="closeModal()" class="btn">Tutup</button>
            </div>
        </div>
    `);
}


function retry(id){
    const t = transaksi.find(x=>x.id===id);
    openModal(`
        <div class="bg-white rounded-2xl p-6 w-full max-w-sm">
            <h3 class="text-lg font-bold mb-2">Proses Ulang</h3>
            <p class="text-sm text-slate-500 mb-4">
                ${t.produk}<br>Target: <b>${t.data}</b>
            </p>
            <div class="flex justify-end gap-2">
                <button onclick="closeModal()" class="btn">Batal</button>
                <button onclick="
                    t.status='Proses';
                    notify('Proses ulang berhasil','bg-blue-500');
                    render();
                    closeModal();
                " class="btn-primary">Proses Ulang</button>
            </div>
        </div>
    `);
}


function hapus(id){
    openModal(`
        <div class="bg-white rounded-2xl p-6 w-full max-w-sm text-center">
            <h3 class="text-lg font-bold text-rose-600 mb-2">Hapus Transaksi</h3>
            <p class="text-sm text-slate-500">Yakin hapus transaksi ${id}?</p>
            <div class="flex justify-center gap-2 mt-4">
                <button onclick="closeModal()" class="btn">Batal</button>
                <button onclick="
                    transaksi = transaksi.filter(t=>t.id!=='${id}');
                    filtered = filtered.filter(t=>t.id!=='${id}');
                    notify('Transaksi dihapus','bg-rose-500');
                    render();
                    closeModal();
                " class="btn-danger">Hapus</button>
            </div>
        </div>
    `);
}

function copyText(text){
    navigator.clipboard.writeText(text);
    notify('Data disalin','bg-emerald-500');
}

/* ================= UTIL ================= */
function openModal(html){
    modal.innerHTML = html;
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}
function closeModal(){
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}
function notify(text,color){
    notif.textContent=text;
    notif.className=`fixed bottom-6 right-6 px-5 py-4
                     rounded-2xl shadow-lg text-white font-semibold ${color}`;
    notif.classList.remove('hidden');
    setTimeout(()=>notif.classList.add('hidden'),3000);
}

/* ================= ICONS ================= */
function iconEye(){return `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M1.5 12s4-7 10.5-7 10.5 7 10.5 7-4 7-10.5 7S1.5 12 1.5 12z"/><circle cx="12" cy="12" r="3"/></svg>`;}
function iconPlane(){return `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M10 14l11-2-11-2V3L3 12l7 9v-7z"/></svg>`;}
function iconTrash(){return `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M3 6h18"/><path d="M8 6v14"/><path d="M16 6v14"/><path d="M5 6l1 14h12l1-14"/></svg>`;}
function iconCopy(){return `<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>`;}

render();
</script>

<style>
.btn{padding:.5rem 1rem;border:1px solid #e5e7eb;border-radius:.75rem}
.btn-primary{padding:.5rem 1rem;background:#3b82f6;color:white;border-radius:.75rem}
.btn-danger{padding:.5rem 1rem;background:#ef4444;color:white;border-radius:.75rem}
.icon-btn svg{color:#475569}
</style>

<?php include __DIR__ . '/../layout/adminfooter.php'; ?>
