<?php
require '../connect.php';
require _DIR_('library/session/admin');
include __DIR__ . '/../layout/adminheader.php';
include __DIR__ . '/../layout/adminnavigasi.php';
?>
<main class="flex-1 p-4 md:p-6 overflow-x-hidden">

    <!-- HEADER -->
    <div class="mb-5">
        <h1 class="text-2xl font-bold text-slate-800">Produk</h1>
        <p class="text-sm text-slate-500">Kelola produk & profit</p>
    </div>

    <!-- ACTION BAR -->
    <div class="flex flex-wrap items-center justify-between gap-3 mb-4">

        <div class="flex flex-wrap gap-2">
            <button onclick="openAdd()"
                    class="btn-primary">
                + Tambah Produk
            </button>

            <button onclick="openDeleteBulk()"
                    class="btn-danger">
                Hapus Produk
            </button>

            <button onclick="openProfit()"
                    class="btn border border-blue-500 text-blue-600">
                Set Profit
            </button>
        </div>

        <input id="search"
               type="text"
               placeholder="Cari produk..."
               class="w-full md:w-80 input">
    </div>

    <!-- ================= TABLE ================= -->
    <div class="bg-white rounded-2xl shadow-sm">
        <div class="relative overflow-x-auto">

            <table class="min-w-[1200px] w-full text-sm">

                <thead class="bg-slate-100 text-slate-600">
                    <tr>
                        <th class="px-4 py-3 text-left">Code</th>
                        <th class="px-4 py-3 text-left">Nama</th>
                        <th class="px-4 py-3 text-left">Kategory</th>
                        <th class="px-4 py-3 text-left">Harga</th>
                        <th class="px-4 py-3 text-left">Provider</th>
                        <th class="px-4 py-3 text-center">Action</th>
                    </tr>
                </thead>

                <tbody id="produkTable" class="divide-y"></tbody>

            </table>

        </div>
    </div>

    <!-- PAGINATION -->
    <div id="pagination"
         class="flex justify-center items-center gap-1 mt-6 text-sm flex-wrap"></div>

</main>

<!-- MODAL -->
<div id="modal"
     class="fixed inset-0 bg-black/40 backdrop-blur-sm
            hidden items-center justify-center z-50"></div>

<!-- NOTIF -->
<div id="notif"
     class="fixed bottom-6 right-6 hidden
            px-5 py-4 rounded-2xl shadow-lg
            text-white font-semibold z-50"></div>

<script>
/* ================= API ================= */
const API = '<?= base_url('admin/api/service/service_list') ?>';

let produk = [];
let filtered = [];
let page = 1;
const perPage = 6;
let active = null;

/* ================= LOAD DATA ================= */
async function loadProduk(){
    const res = await fetch(API);
    const data = await res.json();

    produk = data.map(p => {
        const basic = parseInt(p.basic);
        const price = parseInt(p.price);
        
        return {
            id: p.id,   
            code: p.code,
            nama: p.name,
            kategory: p.type,
            modal: price,         
            profit: basic, 
            provider: p.provider
        };
    });

    filtered = [...produk];
    render();
}


/* ================= RENDER ================= */
function render(){
    const start=(page-1)*perPage;
    const data=filtered.slice(start,start+perPage);

    produkTable.innerHTML=data.map(p=>`
        <tr class="hover:bg-slate-50">
            <td class="px-4 py-3 font-medium">${p.code}</td>
            <td class="px-4 py-3">${p.nama}</td>
            <td class="px-4 py-3">${p.kategory}</td>
            <td class="px-4 py-3">
                <div class="text-xs text-slate-500">
                    Modal: Rp ${p.modal.toLocaleString()}
                </div>
                <div class="text-xs text-slate-500">
                    Profit: Rp ${p.profit.toLocaleString()}
                </div>
                <div class="font-semibold">
                    Jual: Rp ${(p.modal+p.profit).toLocaleString()}
                </div>
            </td>
            <td class="px-4 py-3">${p.provider}</td>
            <td class="px-4 py-3">
                <div class="flex justify-center gap-2">
                    <button onclick="detail('${p.code}')" class="icon-btn">${iconEye()}</button>
                    <button onclick="edit('${p.code}')" class="icon-btn">${iconGear()}</button>
                    <button onclick="hapus('${p.code}')" class="icon-btn text-rose-500">${iconTrash()}</button>
                </div>
            </td>
        </tr>
    `).join('');

    renderPagination();
}

/* ================= PAGINATION ================= */
function renderPagination(){
    const total=Math.ceil(filtered.length/perPage);
    pagination.innerHTML='';

    const btn=(l,p,a=false)=>`
        <button onclick="page=${p};render()"
            class="px-3 py-1 rounded-lg ${a?'bg-blue-500 text-white':'hover:bg-slate-100'}">
            ${l}
        </button>`;

    if(page>1) pagination.innerHTML+=btn('&lt;',page-1);

    let s=Math.max(1,page-2), e=Math.min(total,page+2);
    if(s>1){ pagination.innerHTML+=btn(1,1,page===1)+'<span>…</span>'; }
    for(let i=s;i<=e;i++) pagination.innerHTML+=btn(i,i,page===i);
    if(e<total){ pagination.innerHTML+='<span>…</span>'+btn(total,total,page===total); }
    if(page<total) pagination.innerHTML+=btn('&gt;',page+1);
}

/* ================= SEARCH ================= */
search.oninput=e=>{
    const q=e.target.value.toLowerCase();
    filtered=produk.filter(p=>
        p.code.toLowerCase().includes(q) ||
        p.nama.toLowerCase().includes(q)
    );
    page=1;
    render();
};

/* ================= ADD ================= */
const API_CATEGORY = '<?= base_url("admin/api/category/category_list") ?>';

async function loadCategory(){
    const res = await fetch(API_CATEGORY);
    const json = await res.json();

    const select = document.getElementById('aBrand');

    // reset isi
    select.innerHTML = `<option value="">-- Pilih Brand --</option>`;

    // ⬅️ PENTING: json.data
    json.data.forEach(cat => {
        select.innerHTML += `
            <option value="${cat.code}">
                ${cat.nama} [${cat.type}]
            </option>
        `;
    });
}

function openAdd(){
    openModal(`
        <div class="bg-white rounded-2xl p-6 w-full max-w-md">
            <h3 class="text-lg font-bold mb-4">Tambah Produk</h3>
    
            <input id="aCode" class="input" placeholder="Code (unik)">
            <input id="aNama" class="input" placeholder="Nama Produk">
            
            <select id="aBrand" class="input"></select>
            <select id="aKat" class="input">
                <option value="">-- Konfirmasi Brand --</option>
                <option value="pulsa-reguler">pulsa-reguler</option>
                <option value="pulsa-internasional">pulsa-internasional</option>
                <option value="paket-internet">paket-internet</option>
                <option value="paket-telepon">paket-telepon</option>
                <option value="token-pln">token-pln</option>
                <option value="saldo-emoney">saldo-emoney</option>
                <option value="paket-lainnya">paket-lainnya</option>
                <option value="streaming-tv">streaming-tv</option>
                <option value="voucher-game">voucher-game</option>
                <option value="pascabayar">pascabayar</option>
            </select>
            
            <input id="aModal" type="number" class="input" placeholder="Harga Modal">
            <input id="aProfit" type="number" class="input" placeholder="Profit">
    
            <select id="aProvider" class="input">
                <option value="">-- Pilih Provider --</option>
                <option value="X">Manual</option>
                <option value="PST">Pusat PPOB</option>
            </select>
    
            <div class="flex justify-end gap-2 mt-4">
                <button onclick="closeModal()" class="btn">Batal</button>
                <button onclick="simpanProdukBaru()" class="btn-primary">Simpan</button>
            </div>
        </div>
    `);
    
    loadCategory();
}

function simpanProdukBaru(){
    const code = aCode.value.trim();
    const nama = aNama.value.trim();
    const kat  = aKat.value;
    const brand = aBrand.value;
    const modal = aModal.value;
    const profit = aProfit.value || 0;
    const provider = aProvider.value;

    // VALIDASI FRONTEND
    if(code === ''){
        notify('Code wajib diisi','bg-red-500');
        return;
    }
    if(!/^[A-Z0-9_-]+$/i.test(code)){
        notify('Code hanya boleh huruf & angka','bg-red-500');
        return;
    }
    if(nama === ''){
        notify('Nama wajib diisi','bg-red-500');
        return;
    }
    if(kat === ''){
        notify('Kategori wajib dipilih','bg-red-500');
        return;
    }
    if(brand === ''){
        notify('Brand wajib dipilihh','bg-red-500');
        return;
    }
    if(modal === '' || isNaN(modal) || modal <= 0){
        notify('Harga modal tidak valid','bg-red-500');
        return;
    }
    if(isNaN(profit) || profit < 0){
        notify('Profit tidak valid','bg-red-500');
        return;
    }
    if(provider === ''){
        notify('Provider wajib dipilih','bg-red-500');
        return;
    }

    const form = new URLSearchParams();
    form.append('code', code);
    form.append('nama', nama);
    form.append('kategory', kat);
    form.append('brand', brand);
    form.append('modal', modal);
    form.append('profit', profit);
    form.append('provider', provider);

    fetch(API,{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:form.toString()
    })
    .then(r=>r.json())
    .then(j=>{
        console.log(j);

        if(!j.success){
            alert('Gagal tambah: ' + j.error);
            return;
        }

        notify('Produk ditambahkan','bg-emerald-500');
        closeModal();
        loadProduk();
    });
}


/* ================= EDIT ================= */
function edit(code){
    active = produk.find(p => p.code === code);

    openModal(`
    <div class="bg-white rounded-2xl p-6 w-full max-w-md">
        <h3 class="text-lg font-bold mb-4">Edit Produk</h3>

        <input id="eNama" class="input" value="${active.nama}">
        <input id="eProfit" type="number" class="input" value="${active.profit}">
        <select id="eProvider" class="input">
            <option value="X" ${active.provider==='X'?'selected':''}>Manual</option>
            <option value="PST" ${active.provider==='PST'?'selected':''}>Pusat PPOB</option>
        </select>

        <div class="flex justify-end gap-2 mt-4">
            <button onclick="closeModal()" class="btn">Batal</button>
            <button onclick="simpanEditProduk(${active.id}, '${active.code}')" class="btn-primary">
                Simpan
            </button>
        </div>
    </div>`);
}

function simpanEditProduk(id, code){
    const eNama = document.getElementById('eNama');
    const eProfit = document.getElementById('eProfit');
    const eProvider = document.getElementById('eProvider');

    const form = new URLSearchParams();
    form.append('_method','PUT');
    form.append('id', id);
    form.append('code', code);
    form.append('nama', eNama.value);
    form.append('profit', eProfit.value);
    form.append('provider', eProvider.value);

    fetch(API,{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:form.toString()
    })
    .then(r=>r.json())
    .then(j=>{
        //console.log(j);
    
        if(!j.success){
            alert('Gagal update: ' + (j.error ?? 'unknown error'));
            return; // ⬅️ PENTING
        }
    
        closeModal();
        loadProduk();
    });
}


/* ================= DELETE ================= */
function hapus(code){
    openModal(`
    <div class="bg-white rounded-2xl p-6 w-full max-w-sm text-center">
        <h3 class="text-lg font-bold text-rose-600 mb-2">Hapus Produk</h3>
        <p class="text-sm text-slate-500">Yakin hapus produk ${code}?</p>
        <div class="flex justify-center gap-2 mt-4">
            <button onclick="closeModal()" class="btn">Batal</button>
            <button onclick="hapusProduk('${code}')" class="btn-danger">Hapus</button>
        </div>
    </div>`);
}

function hapusProduk(code){
    const form = new URLSearchParams();
    form.append('_method','DELETE');
    form.append('code', code);

    fetch(API,{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:form.toString()
    })
    .then(r=>r.json())
    .then(j=>{
        console.log(j);

        if(!j.success){
            alert('Gagal hapus');
            return;
        }

        notify('Produk dihapus','bg-rose-500');
        closeModal();
        loadProduk();
    });
}

/* ================= DETAIL ================= */
function detail(code){
    const p=produk.find(x=>x.code===code);
    openModal(`
    <div class="bg-white rounded-2xl p-6 w-full max-w-md">
        <h3 class="text-lg font-bold mb-4">Detail Produk</h3>
        <div class="text-sm space-y-2">
            <p><b>Code:</b> ${p.code}</p>
            <p><b>Nama:</b> ${p.nama}</p>
            <p><b>Kategory:</b> ${p.kategory}</p>
            <p><b>Modal:</b> Rp ${p.modal.toLocaleString()}</p>
            <p><b>Profit:</b> Rp ${p.profit.toLocaleString()}</p>
            <p><b>Harga Jual:</b> Rp ${(p.modal+p.profit).toLocaleString()}</p>
            <p><b>Provider:</b> ${p.provider}</p>
        </div>
        <div class="text-right mt-4">
            <button onclick="closeModal()" class="btn">Tutup</button>
        </div>
    </div>`);
}

/* ================= UTIL ================= */
function openModal(html){
    modal.innerHTML=html;
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}
function closeModal(){
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}
function notify(text,color){
    notif.textContent=text;
    notif.className=`fixed bottom-6 right-6 px-5 py-4
                     rounded-2xl shadow-lg text-white font-semibold ${color}`;
    notif.classList.remove('hidden');
    setTimeout(()=>notif.classList.add('hidden'),3000);
}

/* ================= ICON ================= */
function iconEye(){return `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M1.5 12s4-7 10.5-7 10.5 7 10.5 7-4 7-10.5 7S1.5 12 1.5 12z"/><circle cx="12" cy="12" r="3"/></svg>`;}
function iconGear(){return `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M12 15.5a3.5 3.5 0 1 0 0-7"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.7l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.7-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 0 1-4 0v-.2a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.7.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.7 1.6 1.6 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.2a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.7l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.7.3 1.6 1.6 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.2a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.7-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.7 1.6 1.6 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.2a1.6 1.6 0 0 0-1.5 1z"/></svg>`;}
function iconTrash(){return `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M3 6h18"/><path d="M8 6v14"/><path d="M16 6v14"/><path d="M5 6l1 14h12l1-14"/></svg>`;}

loadProduk();
</script>

<style>
.input{width:100%;padding:.5rem 1rem;border-radius:.75rem;border:1px solid #e5e7eb;margin-bottom:.5rem}
.btn{padding:.5rem 1rem;border:1px solid #e5e7eb;border-radius:.75rem}
.btn-primary{padding:.5rem 1rem;background:#3b82f6;color:white;border-radius:.75rem}
.btn-danger{padding:.5rem 1rem;background:#ef4444;color:white;border-radius:.75rem}
.icon-btn svg{color:#475569}
</style>

<?php include __DIR__ . '/../layout/adminfooter.php'; ?>
