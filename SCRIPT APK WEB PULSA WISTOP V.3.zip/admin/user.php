<?php
require '../connect.php';
require _DIR_('library/session/admin');
include __DIR__ . '/../layout/adminheader.php';
include __DIR__ . '/../layout/adminnavigasi.php';
?>

<main class="flex-1 p-4 md:p-6 overflow-x-hidden">

    <!-- HEADER -->
    <div class="mb-5">
        <h1 class="text-2xl font-bold text-slate-800">Manajemen User</h1>
        <p class="text-sm text-slate-500">
            Geser tabel ke kiri / kanan untuk melihat kolom lainnya
        </p>
    </div>

    <!-- SEARCH -->
    <div class="mb-4">
        <input id="searchUser"
               type="text"
               placeholder="Cari username, nama, email..."
               class="w-full md:w-96 px-4 py-2 rounded-xl border
                      focus:ring-2 focus:ring-blue-500 outline-none">
    </div>

    <!-- TABLE -->
    <div class="bg-white rounded-2xl shadow-sm">
        <div class="relative overflow-x-auto">
            <table class="min-w-[1100px] w-full text-sm">

                <thead class="bg-slate-100 text-slate-600">
                    <tr>
                        <th class="px-4 py-3 text-left">Username</th>
                        <th class="px-4 py-3 text-left">Nama</th>
                        <th class="px-4 py-3 text-left">Email</th>
                        <th class="px-4 py-3 text-left">WhatsApp</th>
                        <th class="px-4 py-3 text-left">Saldo</th>
                        <th class="px-4 py-3 text-left">Role</th>
                        <th class="px-4 py-3 text-center">Aksi</th>
                    </tr>
                </thead>

                <tbody id="userTable" class="divide-y"></tbody>

            </table>
        </div>
    </div>

    <!-- PAGINATION -->
    <div id="pagination"
         class="flex justify-center items-center gap-1 mt-6 text-sm flex-wrap"></div>

</main>

<!-- MODAL -->
<div id="modal"
     class="fixed inset-0 bg-black/40 backdrop-blur-sm
            hidden items-center justify-center z-50"></div>

<!-- NOTIF -->
<div id="notif"
     class="fixed bottom-6 right-6 hidden
            px-5 py-4 rounded-2xl shadow-lg
            text-white font-semibold z-50"></div>

<script>
let users = [];
let filtered = [];
let page = 1;
const perPage = 8;
let totalData = 0;
let activeUser = null;

/* ================= DATA DUMMY ================= */
async function loadUsers() {
    const q = searchUser.value || '';
    const res = await fetch(
        `<?= base_url('admin/api/user/users_list') ?>?page=${page}&q=${encodeURIComponent(q)}`
    );
    const json = await res.json();

    users = json.data;
    filtered = users;
    totalData = json.total;

    render();
}

/* ================= RENDER ================= */
function render(){
    userTable.innerHTML = users.map(u=>`
        <tr class="hover:bg-slate-50">
            <td class="px-4 py-3 font-medium">${u.username}</td>
            <td class="px-4 py-3">${u.nama}</td>
            <td class="px-4 py-3">${u.email}</td>
            <td class="px-4 py-3">${u.wa}</td>
            <td class="px-4 py-3 font-semibold">
                Rp ${Number(u.saldo).toLocaleString()}
            </td>
            <td class="px-4 py-3">
                <span class="px-3 py-1 rounded-full text-xs
                    ${u.role==='Admin'
                        ?'bg-indigo-100 text-indigo-600'
                        :'bg-emerald-100 text-emerald-600'}">
                    ${u.role}
                </span>
            </td>
            <td class="px-4 py-3">
                <div class="flex justify-center gap-2">
                    <button onclick="openEdit(${u.id})" class="icon-btn">${iconGear()}</button>
                    <button onclick="openSaldo(${u.id})" class="icon-btn">${iconWallet()}</button>
                    <button onclick="openDelete(${u.id})" class="icon-btn text-rose-500">${iconTrash()}</button>
                </div>
            </td>
        </tr>
    `).join('');

    renderPagination();
}

/* ================= PAGINATION ================= */
function renderPagination(){
    const total = Math.ceil(totalData / perPage);
    pagination.innerHTML = '';

    const btn = (label, p, active=false)=>`
        <button onclick="page=${p};loadUsers()"
            class="px-3 py-1 rounded-lg
            ${active?'bg-blue-500 text-white':'hover:bg-slate-100'}">
            ${label}
        </button>`;

    if(page>1) pagination.innerHTML += btn('&lt;', page-1);

    for(let i=1;i<=total;i++){
        pagination.innerHTML += btn(i, i, page===i);
    }

    if(page<total) pagination.innerHTML += btn('&gt;', page+1);
}

/* ================= SEARCH ================= */
searchUser.oninput = () => {
    page = 1;
    loadUsers();
};

/* ================= MODAL ================= */
function openModal(html){
    modal.innerHTML=html;
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}
function closeModal(){
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}

/* ================= ACTIONS ================= */
function openEdit(id){
    activeUser = users.find(u => Number(u.id) === Number(id));
    if(!activeUser) return alert('User tidak ditemukan');

    openModal(`
    <div class="bg-white rounded-2xl p-6 w-full max-w-md">
        <h3 class="text-lg font-bold mb-4">Edit User</h3>

        <input id="eNama" class="input" value="${activeUser.nama}">
        <input id="eEmail" class="input" value="${activeUser.email}">
        <input id="eWa" class="input" value="${activeUser.wa}">
        <select id="eRole" class="input">
            <option ${activeUser.role==='Basic'?'selected':''}>Basic</option>
            <option ${activeUser.role==='Admin'?'selected':''}>Admin</option>
        </select>

        <div class="flex justify-end gap-2 mt-4">
            <button onclick="closeModal()" class="btn">Batal</button>
            <button onclick="saveEdit()" class="btn-primary">Simpan</button>
        </div>
    </div>`);
}

function saveEdit(){
    fetch("<?= base_url('admin/api/user/user_update') ?>", {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: new URLSearchParams({
            id: activeUser.id,
            name: eNama.value,
            email: eEmail.value,
            phone: eWa.value,
            level: eRole.value
        })
    })
    .then(r => r.json())
    .then(res => {
        notify(res.message, res.status ? 'bg-emerald-500' : 'bg-rose-500');
        if(res.status){
            closeModal();
            loadUsers();
        }
    });
}

function openSaldo(id){
    activeUser = users.find(u => Number(u.id) === Number(id));
    if(!activeUser) return alert('User tidak ditemukan');

    openModal(`
    <div class="bg-white rounded-2xl p-6 w-full max-w-sm">
        <h3 class="text-lg font-bold mb-4">Edit Saldo</h3>
        <input id="eSaldo" type="number" class="input" value="${activeUser.saldo}">
        <div class="flex justify-end gap-2 mt-4">
            <button onclick="closeModal()" class="btn">Batal</button>
            <button onclick="saveSaldo()" class="btn-primary">Simpan</button>
        </div>
    </div>`);
}

function saveSaldo(){
    fetch('<?= base_url('admin/api/user/user_saldo') ?>', {
        method: 'POST',
        body: new URLSearchParams({
            id: activeUser.id,
            saldo: eSaldo.value
        })
    }).then(()=>{
        notify('Saldo Disimpan','bg-blue-500');
        closeModal();
        loadUsers();
    });
}

function openDelete(id){
    activeUser = users.find(u => Number(u.id) === Number(id));
    if(!activeUser) return alert('User tidak ditemukan');

    openModal(`
    <div class="bg-white rounded-2xl p-6 w-full max-w-sm text-center">
        <h3 class="text-lg font-bold text-rose-600 mb-2">Hapus User</h3>
        <p class="text-sm text-slate-500">
            Yakin hapus <b>${activeUser.username}</b>?
        </p>
        <div class="flex justify-center gap-2 mt-4">
            <button onclick="closeModal()" class="btn">Batal</button>
            <button onclick="deleteUser()" class="btn-danger">Hapus</button>
        </div>
    </div>`);
}

function deleteUser(){
    fetch('<?= base_url('admin/api/user/user_delete') ?>', {
        method: 'POST',
        body: new URLSearchParams({ id: activeUser.id })
    }).then(()=>{
        notify('User Dihapus','bg-rose-500');
        closeModal();
        loadUsers();
    });
}


/* ================= NOTIF ================= */
function notify(text,color){
    notif.textContent=text;
    notif.className=`fixed bottom-6 right-6 px-5 py-4
                     rounded-2xl shadow-lg text-white font-semibold ${color}`;
    notif.classList.remove('hidden');
    setTimeout(()=>notif.classList.add('hidden'),3000);
}

/* ================= UI HELPERS ================= */
function iconGear(){return `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M12 15.5a3.5 3.5 0 1 0 0-7"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.7l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.7-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 0 1-4 0v-.2a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.7.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.7 1.6 1.6 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.2a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.7l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.7.3 1.6 1.6 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.2a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.7-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.7 1.6 1.6 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.2a1.6 1.6 0 0 0-1.5 1z"/></svg>`;}
function iconWallet(){return `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M3 7h18v10H3z"/><path d="M16 12h2"/></svg>`;}
function iconTrash(){return `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M3 6h18"/><path d="M8 6v14"/><path d="M16 6v14"/><path d="M5 6l1 14h12l1-14"/></svg>`;}

loadUsers();
</script>

<style>
.input{width:100%;padding:.5rem 1rem;border-radius:0.75rem;border:1px solid #e5e7eb;margin-bottom:.5rem}
.btn{padding:.5rem 1rem;border:1px solid #e5e7eb;border-radius:0.75rem}
.btn-primary{padding:.5rem 1rem;background:#3b82f6;color:white;border-radius:0.75rem}
.btn-danger{padding:.5rem 1rem;background:#ef4444;color:white;border-radius:0.75rem}
.icon-btn svg{color:#475569}
</style>

<?php include __DIR__ . '/../layout/adminfooter.php'; ?>
