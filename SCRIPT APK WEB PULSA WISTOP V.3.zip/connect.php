<?php
if(!isset($_SESSION)) session_start();
date_default_timezone_set('Asia/Jakarta');
ini_set('memory_limit', '1024M');
$date = date('Y-m-d ');
$time = date('H:i:s');
$dtme = date('Y-m-d H:i:s');

$aiy = [
    'host' => 'localhost',
    'user' => 'diaa8834_topup26', # Username Database
    'pass' => 'oA$En6O)j%PO5b{j', # Password Database
    'name' => 'diaa8834_topup26'  # Nama Database
];

$call = mysqli_connect($aiy['host'],$aiy['user'],$aiy['pass'],$aiy['name']);
if(!$call) { print '<font color="red"><pre>['.$dtme.'] '.mysqli_connect_error().'</pre></font>'; }

function _DIR_($path,$x = 'php') {
    global $_SERVER; global $call;
    if(isset($_SERVER['DOCUMENT_ROOT']));
    $DROOT = (isset($_SERVER['DOCUMENT_ROOT'])) ? $_SERVER['DOCUMENT_ROOT'] : '';
    if($x == 'php') return (stristr($path,'.php')) ? "$DROOT/$path" : "$DROOT/$path.php";
    else return "$DROOT/$path";
}

require _DIR_('library/mainfunction');
require _DIR_('library/function/csrf_token');
require _DIR_('library/function/cURL');
require _DIR_('library/customfunction');

$_CONFIG = [
    'title'         => conf('webcfg',1),
    'navbar'        => conf('webcfg',2),
    'description'   => conf('webcfg',3),
    'keyword'       => conf('webcfg',4),
    'banner'        => conf('webcfg',5),
    'icon'          => conf('webcfg',6),
    'icon_nav'          => conf('webcfg',7),
    'hold'          => [
        'Member' => conf('hold-balance',1),
    ],
    'mt'            => [
        'web' => conf('webmt',1),
        'trx' => conf('webmt',2),
        'deposit' => conf('webmt',3)
    ],
];

// ========================= START: Custom Required ========================= //
/* Required: Location Request */
$_USER = [
    'require' => [
        'location' => (conf('xtra-fitur',2) == 'true') ? 'true' : 'false',
    ]
];

/* Required: Fonnte */
require _DIR_('library/function/Fonnte');
$FONNTE = new Fonnte(conf('fonnte', 1));

/* Required: Pusat PPOB */
require _DIR_('library/function/pusatppob.class');
$PUSATPPOB = new PusatPPOB([
    'userid' => $call->query("SELECT userid FROM provider WHERE code = 'PST'")->fetch_assoc()['userid'],
    'apikey' => $call->query("SELECT apikey FROM provider WHERE code = 'PST'")->fetch_assoc()['apikey']
]);
// ========================== END: Custom Required ========================== //
 
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$user_agent)
    || preg_match('/Java1.1.4/si',$user_agent)
    || preg_match('/MS FrontPage Express/si',$user_agent)
    || preg_match('/HTTrack/si',$user_agent)
    || preg_match('/IDentity/si',$user_agent)
    || preg_match('/HyperBrowser/si',$user_agent)
    || preg_match('/Lynx/si',$user_agent)
) die('Our system detects it, we protect it!');