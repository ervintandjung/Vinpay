<?php
ini_set('display_errors',1);
error_reporting(E_ALL);
require '../connect.php';
require _DIR_('library/session/auth');
require _DIR_('library/components/userReset');

$reset = new AuthReset(
    $call, $_CONFIG, $curl, $FONNTE, $client_ip, $client_iploc, $dtme
);

if(isset($_POST['sendOTP'])){
    $reset->sendOTP($_POST, $result_csrf);
}

if(isset($_POST['confirmOTP'])){
    $reset->confirmOTP($_POST, $result_csrf);
}

if(isset($_POST['resetPass'])){
    $reset->resetPassword($_POST, $result_csrf);
}

if(isset($_POST['cancel'])){
    unset($_SESSION['temp_reset']);
    LannXit(['type'=>true,'message'=>'Proses dibatalkan.']);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Lupa Password</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://cdn.tailwindcss.com"></script>
<link rel="icon" href="<?= $_CONFIG['icon'] ?>">
<style>body{background:#f1f5f9}</style>
</head>
<body class="min-h-screen flex items-center justify-center">

<div class="w-full max-w-md bg-white rounded-3xl shadow-xl p-7">

<div class="text-center mb-6">
    <img src="<?= $_CONFIG['icon_nav'] ?>" class="h-10 mx-auto mb-4">
    <h1 class="text-xl font-bold">Lupa Password</h1>
    <p class="text-sm text-slate-500">Pulihkan akun Anda</p>
</div>

<form method="POST" class="space-y-5">
<?php require _DIR_('library/session/result'); ?>
<input type="hidden" name="csrf_token" value="<?= $csrf_string ?>">

<?php if(!isset($_SESSION['temp_reset'])): ?>

    <div>
        <label class="text-sm font-semibold">Email / No HP</label>
        <input type="text" name="user"
               class="mt-2 w-full px-4 py-3 rounded-xl border focus:ring-2 focus:ring-blue-500"
               placeholder="email atau nomor hp">
    </div>

    <button type="submit" name="sendOTP"
        class="w-full bg-blue-500 hover:bg-blue-600 text-white py-3 rounded-xl font-semibold">
        Kirim OTP
    </button>

<?php elseif(isset($_SESSION['temp_reset']) && !isset($_SESSION['temp_reset']['verified'])): ?>

    <div>
        <label class="text-sm font-semibold">Masukkan OTP</label>
        <input type="number" name="otp"
               class="mt-2 w-full px-4 py-3 rounded-xl border focus:ring-2 focus:ring-blue-500"
               placeholder="kode OTP">
    </div>

    <div class="grid grid-cols-2 gap-2">
        <button type="submit" name="cancel"
            class="bg-red-500 hover:bg-red-600 text-white py-3 rounded-xl font-semibold">
            Batal
        </button>
        <button type="submit" name="confirmOTP"
            class="bg-blue-500 hover:bg-blue-600 text-white py-3 rounded-xl font-semibold">
            Verifikasi
        </button>
    </div>

<?php else: ?>

    <div>
        <label class="text-sm font-semibold">Password Baru</label>
        <input type="password" name="pass1"
               class="mt-2 w-full px-4 py-3 rounded-xl border focus:ring-2 focus:ring-blue-500">
    </div>

    <div>
        <label class="text-sm font-semibold">Konfirmasi Password</label>
        <input type="password" name="pass2"
               class="mt-2 w-full px-4 py-3 rounded-xl border focus:ring-2 focus:ring-blue-500">
    </div>

    <button type="submit" name="resetPass"
        class="w-full bg-green-500 hover:bg-green-600 text-white py-3 rounded-xl font-semibold">
        Reset Password
    </button>

<?php endif; ?>

</form>

<p class="text-sm text-center mt-6">
    <a href="login" class="text-blue-500 font-semibold">Kembali ke Login</a>
</p>

</div>
</body>
</html>