<?php
require '../connect.php';
require _DIR_('library/session/auth');

if(isset($_POST['login'])) {
    require _DIR_('library/components/userAuth');
    $auth = new AuthLogin(
        $call,
        $_CONFIG,
        $client_ip,
        $client_iploc,
        $user_agent,
        $date,
        $time
    );
    
    $auth->handlePost($_POST, $result_csrf);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($_CONFIG['title'], ENT_QUOTES, 'UTF-8') ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.tailwindcss.com"></script>
    
    <link rel="icon" href="<?= $_CONFIG['icon'] ?>">

    <style>
        body { background:#f1f5f9 }
    </style>
</head>

<body class="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-100 to-slate-200">

<div class="w-full max-w-md px-6">

    <!-- CARD -->
    <div class="bg-white/90 backdrop-blur rounded-3xl shadow-xl border border-slate-200 p-8">

        <!-- HEADER -->
        <div class="text-center mb-8">
            <img src="<?= htmlspecialchars($_CONFIG['icon_nav'], ENT_QUOTES, 'UTF-8') ?>"
                 class="h-10 mx-auto mb-4 object-contain"
                 alt="logo">
            <h1 class="text-2xl font-bold text-slate-800 tracking-tight">
                Selamat Datang
            </h1>
            <p class="text-sm text-slate-500 mt-1">
                Masuk untuk melanjutkan ke akun Anda
            </p>
        </div>

        <!-- FORM -->
        <form method="POST" class="space-y-5">

            <?php require _DIR_('library/session/result'); ?>
            <input type="hidden" name="csrf_token" id="csrf_token" value="<?= $csrf_string ?>">

            <!-- USER -->
            <div>
                <label class="text-sm font-medium text-slate-700">Email / No HP</label>
                <div class="relative mt-2">
                    <input type="text" name="user"
                        class="w-full px-4 py-3 rounded-xl border border-slate-300
                               focus:border-blue-500 focus:ring-2 focus:ring-blue-200
                               outline-none transition"
                        placeholder="email atau nomor hp (62)">
                </div>
            </div>

            <!-- PASSWORD -->
            <div>
                <label class="text-sm font-medium text-slate-700">Password</label>
                <div class="relative mt-2">
                    <input type="password" name="pass"
                        class="w-full px-4 py-3 rounded-xl border border-slate-300
                               focus:border-blue-500 focus:ring-2 focus:ring-blue-200
                               outline-none transition"
                        placeholder="password">
                </div>
            </div>

            <!-- BUTTON -->
            <button type="submit" name="login"
                class="w-full bg-gradient-to-r from-blue-500 to-indigo-600
                       hover:from-blue-600 hover:to-indigo-700
                       text-white py-3.5 rounded-xl font-semibold
                       shadow-md hover:shadow-lg transition">
                Masuk
            </button>

        </form>

        <!-- FOOTER -->
        <p class="text-sm text-center text-slate-500 mt-8">
            Belum punya akun?
            <a href="register"
               class="text-blue-600 hover:text-blue-700 font-semibold">
               Daftar sekarang
            </a>
        </p>
        <p class="text-sm text-center text-slate-500 mt-8">
            Lupa pasword?
            <a href="ubahpassword.php"
               class="text-blue-600 hover:text-blue-700 font-semibold">
               Ubah pasword
            </a>
        </p>

    </div>

    <!-- COPYRIGHT -->
    <p class="text-center text-xs text-slate-400 mt-6">
        © <?= date('Y') ?> <?= htmlspecialchars($_CONFIG['title']) ?>
    </p>

</div>

</body>
</html>