<?php
require '../connect.php';
require _DIR_('library/session/auth');
require _DIR_('library/components/userRegister');

$reg = new AuthRegister(
    $call, $_CONFIG, $curl, $FONNTE, $client_ip, $client_iploc, $dtme
);

if(isset($_POST['sendOTP'])){
    $reg->sendOTP($_POST, $result_csrf);
}

if(isset($_POST['confirm'])){
    $reg->confirmOTP($_POST, $result_csrf);
}

if(isset($_POST['cancel'])){
    unset($_SESSION['temp']);
    LannXit(['type'=>true,'message'=>'Canceled successfully.']);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($_CONFIG['title'], ENT_QUOTES, 'UTF-8') ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Logo -->
    <link rel="icon" href="<?= $_CONFIG['icon'] ?>">
    
    <style>
        body { background:#f1f5f9 }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center">

<div class="w-full max-w-md bg-white rounded-2xl shadow-lg p-6">

    <div class="text-center mb-6">
        <img src="<?= htmlspecialchars($_CONFIG['icon_nav'], ENT_QUOTES, 'UTF-8') ?>"
                 class="h-10 mx-auto mb-4 object-contain"
                 alt="logo">
        <h1 class="text-xl font-semibold">Daftar</h1>
        <p class="text-sm text-slate-500">Buat akun baru</p>
    </div>

    <form method="POST">
        <?php require _DIR_('library/session/result'); ?>
        <input type="hidden" name="csrf_token" id="csrf_token" value="<?= $csrf_string ?>">
        
        <?php if(!isset($_SESSION['temp'])) { ?>
        <div class="mb-4">
            <label class="text-sm font-medium">Username</label>
            <input type="text" name="name"
                   class="mt-2 w-full px-4 py-3 rounded-xl border outline-none
                          focus:ring-2 focus:ring-blue-500"
                   placeholder="username">
        </div>

        <div class="mb-4">
            <label class="text-sm font-medium">Email</label>
            <input type="text" name="mail"
                   class="mt-2 w-full px-4 py-3 rounded-xl border outline-none
                          focus:ring-2 focus:ring-blue-500"
                   placeholder="email">
        </div>
        
        <div class="mb-4">
            <label class="text-sm font-medium">Nomor HP</label>
            <input type="text" name="phone"
                   class="mt-2 w-full px-4 py-3 rounded-xl border outline-none
                          focus:ring-2 focus:ring-blue-500"
                   placeholder="nomor hp">
        </div>
        
        <div class="mb-4">
            <label class="text-sm font-medium">Password</label>
            <input type="password" name="pas1"
                   class="mt-2 w-full px-4 py-3 rounded-xl border outline-none
                          focus:ring-2 focus:ring-blue-500"
                   placeholder="password">
        </div>

        <div class="mb-5">
            <label class="text-sm font-medium">Konfirmasi Password</label>
            <input type="password" name="pas2"
                   class="mt-2 w-full px-4 py-3 rounded-xl border outline-none
                          focus:ring-2 focus:ring-blue-500"
                   placeholder="ulang password">
        </div>
        
        <button type="submit" name="sendOTP"
            class="w-full bg-blue-500 hover:bg-blue-600 text-white
                   py-3 rounded-xl font-semibold transition">
            Daftar
        </button>
        <? } else { ?>
        <div class="mb-4">
            <label class="text-sm font-medium">One-Time Password</label>
            <input type="number" name="otpwa"
                   class="mt-2 w-full px-4 py-3 rounded-xl border outline-none
                          focus:ring-2 focus:ring-blue-500"
                   placeholder="Enter One-Time Password">
        </div>
        <div class="grid grid-cols-2 gap-2">
            <button type="submit" name="cancel"
                class="w-full bg-red-500 hover:bg-red-600 text-white
                       py-3 rounded-xl font-semibold transition">
                Cancel
            </button>
            <button type="submit" name="confirm"
                class="w-full bg-blue-500 hover:bg-blue-600 text-white
                       py-3 rounded-xl font-semibold transition">
                Verifikasi
            </button>
        </div>
        <? } ?>
    </form>

    <p class="text-sm text-center text-slate-500 mt-5">
        Sudah punya akun?
        <a href="login" class="text-blue-500 font-semibold">Login</a>
    </p>

</div>

</body>
</html>
